import javax.swing.JPanel;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;



public class AddRoom extends JPanel {
	private JTextField txtRNumber;
	private JTextField txtRRate;
	private Connection con;
	private Statement stmt;
	private ResultSet rs;
	private JComboBox cbAcNonAc = new JComboBox();
	private JComboBox cbRType = new JComboBox();
	

	/**
	 * Create the panel.
	 */
	public AddRoom() {
		setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Add New Room");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel.setBounds(28, 26, 121, 29);
		add(lblNewLabel);
		
		JLabel lblRNumber = new JLabel("Room Number");
		lblRNumber.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblRNumber.setBounds(29, 82, 93, 29);
		add(lblRNumber);
		
		JLabel lblRType = new JLabel("RoomType");
		lblRType.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblRType.setBounds(28, 122, 82, 26);
		add(lblRType);
		
		JLabel lblRRate = new JLabel("Room Rate");
		lblRRate.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblRRate.setBounds(28, 196, 82, 29);
		add(lblRRate);
		
		txtRNumber = new JTextField();
		txtRNumber.setBounds(146, 82, 130, 26);
		add(txtRNumber);
		txtRNumber.setColumns(10);
		
		//JComboBox cbRType = new JComboBox();
		cbRType.setBounds(146, 122, 130, 29);
		cbRType.addItem("Single Bed");
		cbRType.addItem("Double Bed");
		cbRType.addItem("Deluxe");
		add(cbRType);
		
		
		//JComboBox cbAcNonAc = new JComboBox();
		cbAcNonAc.setBounds(146, 162, 130, 27);
		cbAcNonAc.addItem("AC");
		cbAcNonAc.addItem("Non-AC");
		add(cbAcNonAc);
		
		txtRRate = new JTextField();
		txtRRate.setBounds(146, 200, 130, 26);
		add(txtRRate);
		txtRRate.setColumns(10);
		
		JButton btnSaveRoom = new JButton("Save");
		btnSaveRoom.setHorizontalAlignment(SwingConstants.LEFT);
		btnSaveRoom.setIcon(new ImageIcon("./images\\ic_action_accept.png"));
		btnSaveRoom.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
					String rNumber = txtRNumber.getText();
					String rAcNonAc = (String)cbAcNonAc.getSelectedItem();
					String rType = (String)cbRType.getSelectedItem();
					String rRate = txtRRate.getText();
					String rStatus = "Available";
					if(txtRNumber.getText().trim().equals(""))
					{
						JOptionPane.showMessageDialog(null, "Please Insert Room Number");
					}
					else{
					try{
						con = DBConnection.getConnection();
						Statement stmt = con.createStatement();
						String sql = "insert into room (`r_number`,`r_ac_nonac`,`r_type`,`r_rate`,`r_status`)values('"+rNumber+"','"+rAcNonAc+"','"+rType+"','"+rRate+"','Available')";
						stmt.execute(sql);
						JOptionPane.showMessageDialog(null, "Room has been saved successfully");
						txtRNumber.setText("");
						cbAcNonAc.setSelectedItem("AC");
						cbRType.setSelectedItem("Single Bed");
						txtRRate.setText("");
						
						
					}
					catch(Exception exc){
						JOptionPane.showMessageDialog(null, exc.toString());
						exc.printStackTrace();
					}
				}
				
				
			}
		});
		btnSaveRoom.setBackground(Color.BLACK);
		btnSaveRoom.setForeground(Color.WHITE);
		btnSaveRoom.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnSaveRoom.setBounds(146, 233, 100, 35);
		add(btnSaveRoom);
		
		JButton btnUpdateRoom = new JButton("Update");
		btnUpdateRoom.setHorizontalAlignment(SwingConstants.LEFT);
		btnUpdateRoom.setIcon(new ImageIcon("./images\\ic_action_book.png"));
		btnUpdateRoom.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					con = DBConnection.getConnection();
					stmt = con.createStatement();
					String updateRoom = "update room set r_ac_nonac = '"+cbAcNonAc.getSelectedItem()+"',r_type = '"+cbRType.getSelectedItem()+"',r_rate = '"+txtRRate.getText()+"' where r_number = '"+txtRNumber.getText()+"'";
					PreparedStatement preparedStatement = con.prepareStatement(updateRoom);
					preparedStatement.executeUpdate();
				
				} catch (Exception e2) {
					JOptionPane.showMessageDialog(null, e2.toString());
				}
			}
		});
		btnUpdateRoom.setForeground(Color.WHITE);
		btnUpdateRoom.setBackground(Color.BLACK);
		btnUpdateRoom.setBounds(262, 233, 115, 35);
		add(btnUpdateRoom);
		
		JLabel lblNewLabel_1 = new JLabel("Ac/Non-AC");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_1.setBounds(28, 168, 82, 14);
		add(lblNewLabel_1);
		
		JButton btnFindRoom = new JButton("Find");
		btnFindRoom.setHorizontalAlignment(SwingConstants.LEFT);
		btnFindRoom.setIcon(new ImageIcon("./images\\ic_action_search.png"));
		btnFindRoom.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Connection con = DBConnection.getConnection();
					Statement stmt = con.createStatement();
					ResultSet rs = stmt.executeQuery("select * from room where r_number = '"+txtRNumber.getText()+"'");
					if(rs.next())
					{
						txtRNumber.setText(rs.getString("r_number"));
						cbRType.setSelectedItem(rs.getString("r_type"));
						cbAcNonAc.setSelectedItem(rs.getString("r_ac_nonac"));
						txtRRate.setText(rs.getString("r_rate"));
					}
					else
					{
						JOptionPane.showMessageDialog(null, "Room number doesn't exist !","Error Room Number", JOptionPane.ERROR_MESSAGE);
					}
				} catch (Exception e2) {
					JOptionPane.showMessageDialog(null, e2.toString());
					
				}
			}
		});
		btnFindRoom.setBackground(Color.BLACK);
		btnFindRoom.setForeground(Color.WHITE);
		btnFindRoom.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnFindRoom.setBounds(290, 82, 93, 29);
		add(btnFindRoom);
		
		

	}
}
