import javax.swing.JPanel;

import java.awt.Color;

import javax.swing.JLabel;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.LayoutManager;
import java.awt.SystemColor;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.UIManager;
import javax.swing.JTextField;

import java.awt.TextField;

import javax.swing.JButton;

import java.awt.Label;

import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import javax.swing.border.BevelBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.MatteBorder;
import javax.swing.table.DefaultTableCellRenderer;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Random;

import javax.swing.SwingConstants;


public class CheckOutFormRoom extends JPanel {
	JTextField txtCustID;
	private JTextField txtCustomerName;
	private JTextField txtRoomNo;
	private JTextField txtRoomType;
	//private JTextField txtCheckIn;
	private JTextField txtCheckIn;
	private JTextField txtCheckOut;
	private Label lblRoomTypeAC;
	private JTextField txtRoomRate;
	private JTextField txtTax;
	private JTextField txtTotal;
	private JTextField txtAdvPayment;
	private JTextField txtDues;
	private JTextField txtPayable;
	private JFrame fr = new JFrame();
	private JTable table = new JTable();
	JLabel lblAddress = new JLabel("Lbl Address");
	JLabel lblCity = new JLabel("lbl City");
	JLabel lblState = new JLabel("lbl State");
	JLabel lblPIN = new JLabel("lbl PIN");
	JLabel lblCountry = new JLabel("lbl country");
	JLabel lblPhone = new JLabel("lbl phone");
	JLabel lblEmail = new JLabel("lbl email");
	JLabel lblSubtotal = new JLabel("Subtotal");
	
	JTextField txtTotalPerson = new JTextField();
	//GregorianCalendar calendar = new GregorianCalendar();
	//Date date = new Date();
	//Date now = calendar.getTime();
	String date = new SimpleDateFormat("dd-MM-y  hh:mm a").format(new Date()); 

	Connection con;
	Statement stmt;
	ResultSet rs;
	String columnName[];
	String data[][];
	int col=0,row=0;
	int i,j, room_price,total_price,meal_time;
	int per_plate;
	//float sub1,sub2;
	Border a = BorderFactory.createLineBorder(Color.BLUE, 2);
	JButton btnSelectC = new JButton("Select Customer");
	private JTextField txtMealCharge;
	JLabel lblMealType = new JLabel("");
	
	private Label lblDay = new Label("");
	private Label lblTotalDays = new Label("");
	/**
	 * Create the panel.
	 */
	
	
	public CheckOutFormRoom() {
		setBackground(UIManager.getColor("Button.background"));
		setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Check out Form (Room Booking)");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel.setBounds(181, 9, 316, 22);
		add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("_______________________________________________");
		lblNewLabel_1.setBounds(170, 17, 351, 14);
		add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Cust. ID");
		lblNewLabel_2.setFont(new Font("Verdana", Font.BOLD, 13));
		lblNewLabel_2.setBounds(10, 52, 67, 14);
		add(lblNewLabel_2);
		
		txtCustID = new JTextField();
		txtCustID.setHorizontalAlignment(SwingConstants.CENTER);
		txtCustID.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtCustID.setEditable(false);
		txtCustID.setBounds(96, 48, 92, 24);
		add(txtCustID);
		
		JButton btnSelectCustomer = new JButton("....");
		
		btnSelectCustomer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				LayoutManager BorderLayout = null;
				fr.setTitle("Select Customer");
				fr.setBounds(500, 220, 550, 300);
				fr.setVisible(true);
				fr.getContentPane().setLayout(new BorderLayout(0, 0));
				table = new JTable();
				table.setBackground(Color.LIGHT_GRAY);
				fr.getContentPane().add(table);  
				try{
					con = DBConnection.getConnection();
					stmt = con.createStatement();
					rs = stmt.executeQuery("select c_id,c_fullname,r_no,check_in,check_out,total_day,no_of_person,meal_plan,meal_charge,r_type,c_address,c_state,c_city,c_country,c_pin,c_mobile,c_email,total,room,r_rate,tax,grand_total,advance,due from roombookingdetails");
					ResultSetMetaData rsm = rs.getMetaData();
					col = rsm.getColumnCount();
					
					columnName = new String[col];
					//for (i = 0; i < columnName.length; i++) {
						//columnName[i] = rsm.getColumnName(i+1);	
						columnName[0] = "<html><b>Cust. ID</b></html>";
						columnName[1] = "<html><b>Cust. Name</b></html>";
						columnName[2] = "<html><b>Room No.</b></html>";
						columnName[3] = "<html><b>Check In</b></html>";
						columnName[4] = "<html><b>Check Out</b></html>";
						columnName[5] = "<html><b>Total Day</b></html>";
						columnName[6] = "<html><b>No. of Person</b></html>";
						
						columnName[7] = "<html><b>Meal Type</b></html>";
						columnName[8] = "<html><b>Meal Charge</b></html>";
						columnName[9] = "<html><b>Room Type</b></html>";
						columnName[10] = "<html><b>Address</b></html>";
						columnName[11] = "<html><b>State</b></html>";
						columnName[12] = "<html><b>City</b></html>";
						columnName[13] = "<html><b>Country</b></html>";
						columnName[14] = "<html><b>PIN</b></html>";
						columnName[15] = "<html><b>Phone No.</b></html>";
						columnName[16] = "<html><b>Email</b></html>";
						columnName[17] = "<html><b>Cost</b></html>";
						columnName[18] = "<html><b>Room</b></html>";
						columnName[19] = "<html><b>Room Rate</b></html>";
						columnName[20] = "<html><b>Tax</b></html>";
						columnName[21] = "<html><b>Total</b></html>";
						columnName[22] = "<html><b>Adv. Payment</b></html>";
						columnName[23] = "<html><b>Payable</b></html>";
						//}
					while (rs.next())row++;
					rs = stmt.executeQuery("select c_id,c_fullname,r_no,check_in,check_out,total_day,no_of_person,meal_plan,meal_charge,r_type,c_address,c_state,c_city,c_country,c_pin,c_mobile,c_email,total,room,r_rate,tax,grand_total,advance,due from roombookingdetails");
					data = new String[row][col];
					for (i = 0; rs.next(); i++) 
					{
						for (j = 0; j<col; j++)
						{	
							data[i][j] = rs.getString(j+1);
						}
					}
					table = new JTable(data, columnName);
					
				}catch(Exception exc)
				{	
					JOptionPane.showMessageDialog(null, exc.toString());
				}
				JPanel p = new  JPanel();
				p.setBackground(Color.ORANGE);
				p.add(btnSelectC);
				fr.getContentPane().add(p,"South");
				
				JScrollPane tableContainer = new JScrollPane(table,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
				table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
				
				fr.getContentPane().add(tableContainer);
				fr.setVisible(true);
				fr.setResizable(false);
				DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
				centerRenderer.setHorizontalAlignment(JLabel.CENTER);
				for(int c = 0;c<col;c++)
				{
					table.getColumnModel().getColumn(c).setCellRenderer(centerRenderer);
				}
			}
		});
		
		btnSelectC.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				//JOptionPane.showMessageDialog(null,"Called");
			
				try{
					int row = table.getSelectedRow();
					int column = table.getColumnCount();
					for(int i = 0;i<column;i++)
					{
						Object dt = table.getValueAt(row, i);
						txtCustID.setText((String) table.getValueAt(row, 0));
						txtCustomerName.setText((String) table.getValueAt(row, 1));
						txtRoomNo.setText((String) table.getValueAt(row, 2));
						txtCheckIn.setText((String) table.getValueAt(row, 3));
						txtCheckOut.setText((String) table.getValueAt(row, 4));
						lblTotalDays.setText((String) table.getValueAt(row, 5));
						lblDay.setText("Days");
						txtTotalPerson.setText((String)table.getValueAt(row, 6));
						lblMealType.setText((String) table.getValueAt(row, 7));
						txtMealCharge.setText((String) table.getValueAt(row, 8));
						txtRoomType.setText((String) table.getValueAt(row, 9));
						lblAddress.setText((String)table.getValueAt(row, 10));
						lblState.setText((String)table.getValueAt(row, 11));
						lblCity.setText((String)table.getValueAt(row, 12));
						lblCountry.setText((String)table.getValueAt(row, 13));
						lblPIN.setText((String)table.getValueAt(row, 14));
						lblPhone.setText((String)table.getValueAt(row, 15));
						lblEmail.setText((String)table.getValueAt(row, 16));
						lblSubtotal.setText((String)table.getValueAt(row, 17));
						
						
						
						
						lblRoomTypeAC.setText((String) table.getValueAt(row, 18));
						txtRoomRate.setText((String) table.getValueAt(row, 19));
						txtTax.setText((String) table.getValueAt(row, 20));
						txtTotal.setText((String) table.getValueAt(row, 21));
						txtAdvPayment.setText((String) table.getValueAt(row, 22));
						//txtDues.setText((String) table.getValueAt(row, 13));
						txtPayable.setText((String) table.getValueAt(row, 23));
					}
					room_price = Integer.parseInt(lblTotalDays.getText()) * Integer.parseInt(txtRoomRate.getText());
					//subtotal = Integer.parseInt(txtTotal.getText()) - Integer.parseInt(txtTax.getText());
					if(txtMealCharge.getText().trim().equals("0"))
					{
						meal_time = 0;
						per_plate = 0;
					}
					else
					{
						meal_time = Integer.parseInt(lblTotalDays.getText())*2;
						per_plate = Integer.parseInt(txtMealCharge.getText()) / meal_time;
					} 
				}
				catch(Exception ex){
					JOptionPane.showMessageDialog(null, ex.toString());
				}
				fr.dispose();
			}		
		});
		
		
		
		btnSelectCustomer.setBounds(211, 49, 49, 23);
		add(btnSelectCustomer);
		
		Label label = new Label("Cust. Name");
		label.setFont(new Font("Verdana", Font.BOLD, 13));
		label.setBounds(382, 50, 79, 22);
		add(label);
		
		txtCustomerName = new JTextField();
		txtCustomerName.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtCustomerName.setHorizontalAlignment(SwingConstants.CENTER);
		txtCustomerName.setEditable(false);
		txtCustomerName.setBounds(480, 49, 154, 24);
		add(txtCustomerName);
		txtCustomerName.setColumns(10);
		
		Label label_1 = new Label("Room No.");
		label_1.setFont(new Font("Verdana", Font.BOLD, 12));
		label_1.setBounds(10, 87, 62, 22);
		add(label_1);
		
		Label label_3 = new Label("Room Type");
		label_3.setFont(new Font("Verdana", Font.BOLD, 12));
		label_3.setBounds(10, 125, 67, 22);
		add(label_3);
		
		txtRoomNo = new JTextField();
		txtRoomNo.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtRoomNo.setHorizontalAlignment(SwingConstants.CENTER);
		txtRoomNo.setEditable(false);
		txtRoomNo.setBounds(95, 88, 94, 24);
		add(txtRoomNo);
		txtRoomNo.setColumns(10);
		
		txtRoomType = new JTextField();
		txtRoomType.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtRoomType.setHorizontalAlignment(SwingConstants.CENTER);
		txtRoomType.setEditable(false);
		txtRoomType.setBounds(96, 126, 94, 24);
		add(txtRoomType);
		txtRoomType.setColumns(10);
		
		lblRoomTypeAC = new Label("");
		lblRoomTypeAC.setFont(new Font("Verdana", Font.BOLD, 12));
		lblRoomTypeAC.setBounds(194, 126, 62, 22);
		add(lblRoomTypeAC);
		
		Label label_4 = new Label("Check In ");
		label_4.setFont(new Font("Vani", Font.BOLD, 12));
		label_4.setBounds(10, 165, 62, 22);
		add(label_4);
		
		Label label_5 = new Label("Check Out");
		label_5.setFont(new Font("Verdana", Font.BOLD, 12));
		label_5.setBounds(10, 197, 67, 22);
		add(label_5);
		
		Label label_6 = new Label("Total Days");
		label_6.setFont(new Font("Vani", Font.BOLD, 12));
		label_6.setBounds(12, 237, 62, 22);
		add(label_6);
		
		txtCheckIn = new JTextField();
		txtCheckIn.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtCheckIn.setEditable(false);
		txtCheckIn.setBounds(96, 165, 174, 24);
		add(txtCheckIn);
		txtCheckIn.setColumns(10);
		
		txtCheckOut = new JTextField();
		txtCheckOut.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtCheckOut.setEditable(false);
		txtCheckOut.setBounds(96, 200, 174, 24);
		add(txtCheckOut);
		txtCheckOut.setColumns(10);
		
		//Label lblTotalDays = new Label("New label");
		lblTotalDays.setFont(new Font("Verdana", Font.BOLD, 13));
		lblTotalDays.setBounds(96, 238, 33, 22);
		add(lblTotalDays);
		
		//Label lblDay = new Label("");
		lblDay.setFont(new Font("Verdana", Font.BOLD, 13));
		lblDay.setBounds(130, 238, 49, 22);
		add(lblDay);
		
		Label label_2 = new Label("Room Rate");
		label_2.setFont(new Font("Vani", Font.BOLD, 12));
		label_2.setBounds(382, 87, 79, 22);
		add(label_2);
		
		txtRoomRate = new JTextField();
		txtRoomRate.setForeground(new Color(139, 0, 0));
		txtRoomRate.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtRoomRate.setHorizontalAlignment(SwingConstants.CENTER);
		txtRoomRate.setEditable(false);
		txtRoomRate.setBounds(480, 86, 116, 23);
		add(txtRoomRate);
		txtRoomRate.setColumns(10);
		
		Label label_7 = new Label("Tax (10%)");
		label_7.setFont(new Font("Vani", Font.BOLD, 12));
		label_7.setBounds(382, 161, 62, 22);
		add(label_7);
		
		txtTax = new JTextField();
		txtTax.setForeground(new Color(139, 0, 0));
		txtTax.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtTax.setHorizontalAlignment(SwingConstants.CENTER);
		txtTax.setEditable(false);
		txtTax.setBounds(480, 159, 116, 24);
		add(txtTax);
		txtTax.setColumns(10);
		
		Label label_8 = new Label("Total");
		label_8.setFont(new Font("Verdana", Font.BOLD, 12));
		label_8.setBounds(382, 202, 62, 22);
		add(label_8);
		
		JLabel lblNewLabel_3 = new JLabel("Adv. Payment");
		lblNewLabel_3.setFont(new Font("Verdana", Font.BOLD, 11));
		lblNewLabel_3.setBounds(382, 240, 90, 14);
		add(lblNewLabel_3);
		
		txtTotal = new JTextField();
		txtTotal.setForeground(new Color(139, 0, 0));
		txtTotal.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtTotal.setHorizontalAlignment(SwingConstants.CENTER);
		txtTotal.setEditable(false);
		txtTotal.setBounds(480, 200, 116, 24);
		add(txtTotal);
		txtTotal.setColumns(10);
		
		txtAdvPayment = new JTextField();
		txtAdvPayment.setForeground(new Color(139, 0, 0));
		txtAdvPayment.setFont(new Font("Tahoma", Font.BOLD, 13));
		txtAdvPayment.setHorizontalAlignment(SwingConstants.CENTER);
		txtAdvPayment.setEditable(false);
		txtAdvPayment.setBounds(480, 237, 116, 24);
		add(txtAdvPayment);
		txtAdvPayment.setColumns(10);
		
		JPanel panel = new JPanel();
		panel.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		panel.setBounds(45, 288, 583, 60);
		add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_5 = new JLabel("Total Payable");
		lblNewLabel_5.setFont(new Font("Verdana", Font.BOLD, 15));
		lblNewLabel_5.setBounds(25, 20, 126, 20);
		panel.add(lblNewLabel_5);
		
		txtPayable = new JTextField();
		txtPayable.setForeground(new Color(139, 0, 0));
		txtPayable.setFont(new Font("Segoe UI Emoji", Font.BOLD, 24));
		txtPayable.setHorizontalAlignment(SwingConstants.CENTER);
		txtPayable.setEditable(false);
		txtPayable.setBounds(161, 12, 141, 37);
		panel.add(txtPayable);
		txtPayable.setColumns(10);
		
	
		
		
		
		
		JButton btnNewButton = new JButton("CHECKOUT & PRINT BILL");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				if(txtCustID.getText().trim().equals("")){
					JOptionPane.showMessageDialog(null, "Pleas Select Customer ID");
				}
				else{
					//Room();
					try{
						con = DBConnection.getConnection();
						stmt = con.createStatement();
						String updateQuery = "update room set r_status = 'Available' where r_number = '"+txtRoomNo.getText()+"'";
						String deleteQuery = "delete from roombookingdetails where r_no = '"+txtRoomNo.getText()+"'";
						String copyQuery = "insert into all_checkout(cust_id,room_no,check_in,check_out,total_day,no_of_person,purpose_visit,meal_plan,room,r_type,c_fullname,c_son_of,c_address,c_state,c_city,c_country,c_pin,c_mobile,c_email,grand_total,payment_mode,identity)select c_id,r_no,check_in,check_out,total_day,no_of_person,purpose_visit,meal_plan,room,r_type,c_fullname,c_son_of,c_address,c_state,c_city,c_country,c_pin,c_mobile,c_email,grand_total,payment_mode,identity_image from roombookingdetails where r_no = '"+txtRoomNo.getText()+"'";
						//PreparedStatement copyStatement = con.prepareStatement(copyQuery);
						stmt.execute(copyQuery);
						PreparedStatement updateStatement = con.prepareStatement(updateQuery);
						PreparedStatement deleteStatement = con.prepareStatement(deleteQuery); 
						updateStatement.executeUpdate();
						deleteStatement.execute();
						//copyStatement.executeUpdate();
						
					}
					catch(Exception ex){JOptionPane.showMessageDialog(null, ex.toString());}
					//CheckOutBill cBill = new CheckOutBill();
					
					JPanel Billpanel = new JPanel();
					
					Billpanel.setBorder(new LineBorder(new Color(0, 0, 0)));
					Billpanel.setLayout(null);
					Billpanel.setBounds(0, 0, 859, 851);
					//JPanel panel = new JPanel();
					Billpanel.setBackground(Color.WHITE);
					Billpanel.setBounds(10, 11, 859, 959);
					add(Billpanel);
					
					JLabel lblNewLabel = new JLabel("Hotel Darpan");
					lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 30));
					lblNewLabel.setBounds(115, 12, 200, 50);
					Billpanel.add(lblNewLabel);
					
					JLabel lblNewLabel_1 = new JLabel("INVOICE");
					lblNewLabel_1.setForeground(SystemColor.textHighlight);
					lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 21));
					lblNewLabel_1.setBounds(636, 12, 103, 50);
					Billpanel.add(lblNewLabel_1);
					
					JLabel lblNewLabel_2 = new JLabel("");
					lblNewLabel_2.setIcon(new ImageIcon("./images\\info.png"));
					lblNewLabel_2.setBounds(26, 12, 76, 67);
					Billpanel.add(lblNewLabel_2);
					
					JLabel lblNewLabel_3 = new JLabel("______________________________________________________________________________________________");
					lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 13));
					lblNewLabel_3.setBounds(28, 124, 821, 31);
					Billpanel.add(lblNewLabel_3);
					
					JLabel lblNewLabel_4 = new JLabel("New Police Line");
					lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 13));
					lblNewLabel_4.setBounds(116, 61, 161, 14);
					Billpanel.add(lblNewLabel_4);
					
					JLabel lblNewLabel_5 = new JLabel("Lodipur, Buddha Marg");
					lblNewLabel_5.setFont(new Font("Tahoma", Font.PLAIN, 13));
					lblNewLabel_5.setBounds(116, 86, 163, 14);
					Billpanel.add(lblNewLabel_5);
					
					JLabel lblNewLabel_6 = new JLabel("9334447788, Patna - 800001");
					lblNewLabel_6.setFont(new Font("Tahoma", Font.PLAIN, 13));
					lblNewLabel_6.setBounds(115, 111, 165, 14);
					Billpanel.add(lblNewLabel_6);
					
					JLabel lblNewLabel_7 = new JLabel("DATE : ");
					lblNewLabel_7.setFont(new Font("Tahoma", Font.BOLD, 13));
					lblNewLabel_7.setBounds(536, 71, 57, 14);
					Billpanel.add(lblNewLabel_7);
					
					JLabel lblDate = new JLabel(date);
					lblDate.setFont(new Font("Tahoma", Font.BOLD, 13));
					lblDate.setBounds(596, 71, 147, 14);
					Billpanel.add(lblDate);
					
					JLabel lblNewLabel_8 = new JLabel("INVOICE NO. :");
					lblNewLabel_8.setFont(new Font("Tahoma", Font.BOLD, 13));
					lblNewLabel_8.setBounds(536, 90, 91, 14);
					Billpanel.add(lblNewLabel_8);
					
					JLabel lblInvoice = new JLabel("INV"+random(3));
					lblInvoice.setFont(new Font("Tahoma", Font.BOLD, 13));
					lblInvoice.setBounds(616, 90, 91, 14);
					Billpanel.add(lblInvoice);
					
					JLabel lblNewLabel_9 = new JLabel("BILL TO");
					lblNewLabel_9.setFont(new Font("Verdana", Font.BOLD, 18));
					lblNewLabel_9.setBounds(82, 174, 91, 23);
					Billpanel.add(lblNewLabel_9);
					
					JLabel lblNewLabel_10 = new JLabel("______________");
					lblNewLabel_10.setBounds(82, 183, 104, 14);
					Billpanel.add(lblNewLabel_10);
					
					JLabel lblNewLabel_11 = new JLabel("______________");
					lblNewLabel_11.setBounds(82, 185, 104, 14);
					Billpanel.add(lblNewLabel_11);
					
					JLabel lblNewLabel_12 = new JLabel("Customer ID:");
					lblNewLabel_12.setFont(new Font("Tahoma", Font.PLAIN, 14));
					lblNewLabel_12.setBounds(185, 182, 103, 14);
					Billpanel.add(lblNewLabel_12);
					
					JLabel lblNewLabel_13 = new JLabel("ROOM DETAILS");
					lblNewLabel_13.setFont(new Font("Verdana", Font.BOLD, 18));
					lblNewLabel_13.setBounds(525, 174, 161, 31);
					Billpanel.add(lblNewLabel_13);
					
					JLabel lblNewLabel_14 = new JLabel("__________________________");
					lblNewLabel_14.setBounds(525, 190, 188, 14);
					Billpanel.add(lblNewLabel_14);
					
					JLabel lblNewLabel_15 = new JLabel("__________________________");
					lblNewLabel_15.setBounds(525, 188, 188, 14);
					Billpanel.add(lblNewLabel_15);
					
					JLabel lblNewLabel_16 = new JLabel("Name :");
					lblNewLabel_16.setFont(new Font("Tahoma", Font.PLAIN, 13));
					lblNewLabel_16.setBounds(82, 215, 76, 14);
					Billpanel.add(lblNewLabel_16);
					
					JLabel lblNewLabel_17 = new JLabel("Address :");
					lblNewLabel_17.setFont(new Font("Tahoma", Font.PLAIN, 13));
					lblNewLabel_17.setBounds(82, 238, 77, 14);
					Billpanel.add(lblNewLabel_17);
					
					JLabel lblNewLabel_18 = new JLabel("City, State ZIP :");
					lblNewLabel_18.setFont(new Font("Tahoma", Font.PLAIN, 13));
					lblNewLabel_18.setBounds(82, 263, 103, 14);
					Billpanel.add(lblNewLabel_18);
					
					JLabel lblNewLabel_19 = new JLabel("Country :");
					lblNewLabel_19.setFont(new Font("Tahoma", Font.PLAIN, 13));
					lblNewLabel_19.setBounds(82, 287, 84, 14);
					Billpanel.add(lblNewLabel_19);
					
					JLabel lblNewLabel_20 = new JLabel("Phone :");
					lblNewLabel_20.setFont(new Font("Tahoma", Font.PLAIN, 13));
					lblNewLabel_20.setBounds(82, 313, 46, 14);
					Billpanel.add(lblNewLabel_20);
					
					JLabel lblNewLabel_21 = new JLabel("Email :");
					lblNewLabel_21.setFont(new Font("Tahoma", Font.PLAIN, 13));
					lblNewLabel_21.setBounds(82, 338, 57, 14);
					Billpanel.add(lblNewLabel_21);
					
					JLabel lblNewLabel_22 = new JLabel("Room ID :");
					lblNewLabel_22.setFont(new Font("Tahoma", Font.PLAIN, 13));
					lblNewLabel_22.setBounds(525, 216, 69, 14);
					Billpanel.add(lblNewLabel_22);
					
					JLabel lblNewLabel_23 = new JLabel("Room :");
					lblNewLabel_23.setFont(new Font("Tahoma", Font.PLAIN, 13));
					lblNewLabel_23.setBounds(525, 239, 46, 14);
					Billpanel.add(lblNewLabel_23);
					
					JLabel lblAC = new JLabel(lblRoomTypeAC.getText());
					lblAC.setFont(new Font("Tahoma", Font.BOLD, 13));
					lblAC.setBounds(682, 239, 86, 14);
					Billpanel.add(lblAC);
					
					JLabel lblNewLabel_24 = new JLabel("Room Rate :");
					lblNewLabel_24.setFont(new Font("Tahoma", Font.PLAIN, 13));
					lblNewLabel_24.setBounds(525, 264, 91, 14);
					Billpanel.add(lblNewLabel_24);
					
					JLabel lblPerson = new JLabel("");
					lblPerson.setIcon(new ImageIcon("./images\\persontable4.JPG"));
					lblPerson.setBounds(26, 356, 767, 73);
					Billpanel.add(lblPerson);
					
					
					JLabel lblCustomerID = new JLabel(txtCustID.getText());
					lblCustomerID.setBounds(280, 182, 97, 14);
					Billpanel.add(lblCustomerID);
					
					JLabel lblName = new JLabel(txtCustomerName.getText());
					lblName.setBounds(181, 215, 125, 14);
					Billpanel.add(lblName);
					
					
					lblAddress.setBounds(181, 238, 151, 14);
					Billpanel.add(lblAddress);
					
					lblCity.setBounds(181, 263, 56, 14);
					Billpanel.add(lblCity);
					
					
					lblState.setBounds(233, 263, 63, 14);
					Billpanel.add(lblState);
					
					
					lblPIN.setBounds(310, 263, 84, 14);
					Billpanel.add(lblPIN);
					
					
					lblCountry.setBounds(181, 287, 103, 14);
					Billpanel.add(lblCountry);
					
					
					lblPhone.setBounds(181, 313, 146, 14);
					Billpanel.add(lblPhone);
					
					
					lblEmail.setBounds(181, 338, 200, 14);
					Billpanel.add(lblEmail);
					
					
					JLabel lblRoomID = new JLabel(txtRoomNo.getText());
					lblRoomID.setBounds(611, 216, 97, 14);
					Billpanel.add(lblRoomID);
					
					JLabel lblRoom = new JLabel(txtRoomType.getText());
					lblRoom.setBounds(611, 239, 97, 14);
					Billpanel.add(lblRoom);
					
					JLabel lblRoomRate = new JLabel(txtRoomRate.getText());
					lblRoomRate.setBounds(611, 264, 46, 14);
					Billpanel.add(lblRoomRate);
					
					JPanel titlePanel = new JPanel();
					titlePanel.setLayout(null);
					titlePanel.setBounds(26, 370, 767, 35);
					titlePanel.setBackground(Color.DARK_GRAY);
					
					JLabel person = new JLabel("Total Person");
					person.setBounds(100, 0, 100, 40);
					person.setForeground(Color.WHITE);
					
					JLabel checkin = new JLabel("Check-In Date");
					checkin.setBounds(350, 0, 100, 40);
					checkin.setForeground(Color.WHITE);
					
					JLabel checkout = new JLabel("Check-Out Date");
					checkout.setBounds(580, 0, 100, 40);
					checkout.setForeground(Color.WHITE);
					
					
					titlePanel.add(checkin);
					titlePanel.add(checkout);
					titlePanel.add(person);
					Billpanel.add(titlePanel);
					
					
					
					JLabel lblTotalPerson = new JLabel();
					lblTotalPerson.setText(txtTotalPerson.getText());
					lblTotalPerson.setBackground(Color.WHITE);
					lblTotalPerson.setForeground(Color.BLACK);
					lblTotalPerson.setBounds(26, 405, 257, 35);
					lblTotalPerson.setHorizontalAlignment(SwingConstants.CENTER);
					lblTotalPerson.setBorder(a);
					//lblTotalPerson.setEditable(false);
					Billpanel.add(lblTotalPerson);
					
					
					
					JTextField txtCheckInBill = new JTextField();
					txtCheckInBill.setText(txtCheckIn.getText());
					txtCheckInBill.setBounds(278, 405, 261, 35);
					txtCheckInBill.setFont(new Font("Tahoma", Font.BOLD, 13));
					txtCheckInBill.setBackground(Color.WHITE);
					txtCheckInBill.setHorizontalAlignment(SwingConstants.CENTER);
					txtCheckInBill.setBorder(a);
					txtCheckInBill.setEditable(false);
					Billpanel.add(txtCheckInBill);
					txtCheckInBill.setColumns(10);
					
					JTextField txtCheckOutBill = new JTextField(txtCheckOut.getText());
					txtCheckOutBill.setBackground(Color.WHITE);
					txtCheckOutBill.setFont(new Font("Tahoma", Font.BOLD, 13));
					txtCheckOutBill.setBounds(535, 405, 258, 35);
					txtCheckOutBill.setHorizontalAlignment(SwingConstants.CENTER);
					txtCheckOutBill.setEditable(false);
					txtCheckOutBill.setBorder(a);
					Billpanel.add(txtCheckOutBill);
					
				
					
					JPanel descriptionPanel = new JPanel();
					descriptionPanel.setLayout(null);
					descriptionPanel.setBounds(26, 455, 767, 34);
					descriptionPanel.setBackground(Color.DARK_GRAY);
					
					
					JLabel slno = new JLabel("Sl. No.");
					slno.setBounds(25, 0, 100, 40);
					slno.setForeground(Color.WHITE);
					
					
					JLabel services = new JLabel("Services");
					services.setBounds(200, 0, 100, 40);
					services.setForeground(Color.WHITE);
					
					JLabel description = new JLabel("Description");
					description.setBounds(410, 0, 100, 40);
					description.setForeground(Color.WHITE);
					
					JLabel amount = new JLabel("Amt.");
					amount.setBounds(550, 0, 100, 40);
					amount.setForeground(Color.WHITE);
					
					JLabel totalAmount = new JLabel("Total Amt.");
					totalAmount.setBounds(660, 0, 100, 40);
					totalAmount.setForeground(Color.WHITE);
					
					
					
					descriptionPanel.add(slno);
					descriptionPanel.add(services);
					descriptionPanel.add(description);
					descriptionPanel.add(amount);
					descriptionPanel.add(totalAmount);
					
					
					Billpanel.add(descriptionPanel);
					
					
					JTextField txtS1 = new JTextField("1 .");
					//txtS1.setBounds(26, 487, 108, 35);
					txtS1.setBounds(26, 487, 85, 35);
					txtS1.setBackground(Color.WHITE);
					txtS1.setHorizontalAlignment(SwingConstants.CENTER);
					txtS1.setBorder(a);
					txtS1.setEditable(false);
					Billpanel.add(txtS1);
					
					JTextField txtDisc1 = new JTextField("Stay Charge ");
					//txtDisc1.setBounds(46, 490, 415, 35);
					txtDisc1.setBounds(46, 487, 354, 35);
					txtDisc1.setBackground(Color.WHITE);
					txtDisc1.setHorizontalAlignment(SwingConstants.CENTER);
					txtDisc1.setBorder(a);
					txtDisc1.setEditable(false);
					Billpanel.add(txtDisc1);
					
					JTextField txtCount1 = new JTextField(lblTotalDays.getText()+" Days");
					txtCount1.setBounds(386, 487, 150, 35);
					txtCount1.setBackground(Color.WHITE);
					txtCount1.setHorizontalAlignment(SwingConstants.CENTER);
					txtCount1.setBorder(a);
					txtCount1.setEditable(false);
					Billpanel.add(txtCount1);
					
					JTextField txtPrice1 = new JTextField(txtRoomRate.getText()+".0");
					txtPrice1.setBounds(532, 487, 130, 35);
					txtPrice1.setBackground(Color.WHITE);
					txtPrice1.setHorizontalAlignment(SwingConstants.CENTER);
					txtPrice1.setBorder(a);
					txtPrice1.setEditable(false);
					Billpanel.add(txtPrice1);
					
					JTextField txtTotalPrice1 = new JTextField(String.valueOf(room_price)+".0");
					txtTotalPrice1.setBounds(636, 487, 157, 35);
					txtTotalPrice1.setBackground(Color.WHITE);
					txtTotalPrice1.setHorizontalAlignment(SwingConstants.CENTER);
					txtTotalPrice1.setBorder(a);
					txtTotalPrice1.setEditable(false);
					Billpanel.add(txtTotalPrice1);
					
					JTextField txtS2 = new JTextField("2 .");
					//txtS2.setBounds(26, 500, 108, 35);
					txtS2.setBounds(26, 517, 85, 35);
					txtS2.setHorizontalAlignment(SwingConstants.CENTER);
					txtS2.setBorder(a);
					txtS2.setEditable(false);
					Billpanel.add(txtS2);
					
					JTextField txtDisc2 = new JTextField("Meal Charge "+ "("+lblMealType.getText()+")");
					txtDisc2.setBounds(46, 517, 354, 35);
					txtDisc2.setHorizontalAlignment(SwingConstants.CENTER);
					txtDisc2.setBorder(a);
					txtDisc2.setEditable(false);
					Billpanel.add(txtDisc2);
					
					JTextField txtCount2 = new JTextField(String.valueOf(meal_time)+" times x");
					txtCount2.setBounds(386, 517, 150, 35);
					txtCount2.setHorizontalAlignment(SwingConstants.CENTER);
					txtCount2.setBorder(a);
					txtCount2.setEditable(false);
					Billpanel.add(txtCount2);
					
					JTextField txtPrice2 = new JTextField(String.valueOf(per_plate)+".0");
					txtPrice2.setBounds(532, 517, 130, 35);
					txtPrice2.setHorizontalAlignment(SwingConstants.CENTER);
					txtPrice2.setBorder(a);
					txtPrice2.setEditable(false);
					Billpanel.add(txtPrice2);
					
					JTextField txtTotalPrice2 = new JTextField(txtMealCharge.getText()+".0");
					txtTotalPrice2.setBounds(636, 517, 157, 35);
					txtTotalPrice2.setHorizontalAlignment(SwingConstants.CENTER);
					txtTotalPrice2.setBorder(a);
					txtTotalPrice2.setEditable(false);
					Billpanel.add(txtTotalPrice2);
					
					JTextField txtS3 = new JTextField("3 .");
					txtS3.setBounds(26, 547, 85, 35);
					txtS3.setBackground(Color.WHITE);
					txtS3.setHorizontalAlignment(SwingConstants.CENTER);
					txtS3.setBorder(a);
					txtS3.setEditable(false);
					Billpanel.add(txtS3);
					
					JTextField txtDisc3 = new JTextField(" - ");
					txtDisc3.setBounds(46, 547, 354, 35);
					txtDisc3.setBackground(Color.WHITE);
					txtDisc3.setHorizontalAlignment(SwingConstants.CENTER);
					txtDisc3.setBorder(a);
					txtDisc3.setEditable(false);
					Billpanel.add(txtDisc3);
					
					JTextField txtCount3 = new JTextField(" - ");
					txtCount3.setBounds(386, 547, 150, 35);
					txtCount3.setBackground(Color.WHITE);
					txtCount3.setHorizontalAlignment(SwingConstants.CENTER);
					txtCount3.setBorder(a);
					txtCount3.setEditable(false);
					Billpanel.add(txtCount3);
					
					JTextField txtPrice3 = new JTextField(" - ");
					txtPrice3.setBounds(532, 547, 130, 35);
					txtPrice3.setBackground(Color.WHITE);
					txtPrice3.setHorizontalAlignment(SwingConstants.CENTER);
					txtPrice3.setBorder(a);
					txtPrice3.setEditable(false);
					Billpanel.add(txtPrice3);
					
					JTextField txtTotalPrice3 = new JTextField(" - ");
					txtTotalPrice3.setBounds(636, 547, 157, 35);
					txtTotalPrice3.setBackground(Color.WHITE);
					txtTotalPrice3.setHorizontalAlignment(SwingConstants.CENTER);
					txtTotalPrice3.setBorder(a);
					txtTotalPrice3.setEditable(false);
					Billpanel.add(txtTotalPrice3);
					
					
					JLabel NewlblSubtotal = new JLabel("SUBTOTAL");
					NewlblSubtotal.setBounds(532, 575, 130, 35);
					NewlblSubtotal.setHorizontalAlignment(SwingConstants.CENTER);
					Billpanel.add(NewlblSubtotal);
					
					JTextField txtSubTotal = new JTextField(lblSubtotal.getText());
					txtSubTotal.setBounds(659, 575, 134, 35);
					txtSubTotal.setHorizontalAlignment(SwingConstants.CENTER);
					txtSubTotal.setBorder(a);
					txtSubTotal.setEditable(false);
					Billpanel.add(txtSubTotal);
					
					JLabel NewlblTax = new JLabel("Tax 10%");
					NewlblTax.setBounds(532, 603, 130, 35);
					NewlblTax.setHorizontalAlignment(SwingConstants.CENTER);
					Billpanel.add(NewlblTax);
					
					JTextField txtBoxTax = new JTextField(txtTax.getText());
					txtBoxTax.setBounds(659, 603, 134, 35);
					txtBoxTax.setBackground(Color.WHITE);
					txtBoxTax.setHorizontalAlignment(SwingConstants.CENTER);
					txtBoxTax.setBorder(a);
					txtBoxTax.setEditable(false);
					Billpanel.add(txtBoxTax);
					
					JLabel NewlblTotal = new JLabel("TOTAL");
					NewlblTotal.setBounds(532, 631, 130, 35);
					NewlblTotal.setHorizontalAlignment(SwingConstants.CENTER);
					Billpanel.add(NewlblTotal);
					
					JTextField txtBoxTotal = new JTextField(txtTotal.getText());
					txtBoxTotal.setBounds(659, 631, 134, 35);
					txtBoxTotal.setHorizontalAlignment(SwingConstants.CENTER);
					txtBoxTotal.setBorder(a);
					txtBoxTotal.setEditable(false);
					Billpanel.add(txtBoxTotal);
					
					
					JLabel NewlblAdvPaid = new JLabel("ADVANCE PAID");
					NewlblAdvPaid.setBounds(532, 658, 130, 35);
					NewlblAdvPaid.setHorizontalAlignment(SwingConstants.CENTER);
					Billpanel.add(NewlblAdvPaid);
					
					JTextField txtBoxAdvPaid = new JTextField(txtAdvPayment.getText()+".0");
					txtBoxAdvPaid.setBounds(659, 658, 134, 35);
					txtBoxAdvPaid.setBackground(Color.WHITE);
					txtBoxAdvPaid.setHorizontalAlignment(SwingConstants.CENTER);
					txtBoxAdvPaid.setBorder(a);
					txtBoxAdvPaid.setEditable(false);
					Billpanel.add(txtBoxAdvPaid);
					
					JLabel NewlblDue = new JLabel("TOTAL DUE");
					NewlblDue.setBounds(532, 682, 130, 35);
					NewlblDue.setHorizontalAlignment(SwingConstants.CENTER);
					Billpanel.add(NewlblDue);
					
					JTextField txtBoxTotalDue = new JTextField(txtPayable.getText());
					txtBoxTotalDue.setBounds(659, 682, 134, 35);
					txtBoxTotalDue.setHorizontalAlignment(SwingConstants.CENTER);
					txtBoxTotalDue.setBorder(a);
					txtBoxTotalDue.setFont(new Font("Times New Roman", Font.BOLD, 14));
					txtBoxTotalDue.setEditable(false);
					Billpanel.add(txtBoxTotalDue);
					
					
					JLabel NewlblStamp = new JLabel("Stamp/Signature");
					NewlblStamp.setBounds(40, 658, 130, 35);
					NewlblStamp.setHorizontalAlignment(SwingConstants.CENTER);
					Billpanel.add(NewlblStamp);
					
					JFrame billFrame = new JFrame();
					billFrame.setBounds(400, 0, 820, 800);
					//setBounds(x, y, width, height);
					billFrame.setVisible(true);
					//billFrame.getContentPane().add(cBill);
					billFrame.getContentPane().add(Billpanel);
					PrintBill p = new PrintBill();
					p.printReport(billFrame);
					JScrollPane scr = new JScrollPane(billFrame);
				}
			}
		});
		
		btnNewButton.setBackground(new Color(0, 0, 0));
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setFont(new Font("Traditional Arabic", Font.BOLD, 12));
		btnNewButton.setBounds(334, 13, 207, 39);
		panel.add(btnNewButton);
		
		JLabel lblNewLabel_25 = new JLabel("Meal Charge");
		lblNewLabel_25.setFont(new Font("Vani", Font.BOLD, 12));
		lblNewLabel_25.setBounds(384, 129, 92, 14);
		add(lblNewLabel_25);
		
		txtMealCharge = new JTextField();
		txtMealCharge.setForeground(new Color(139, 0, 0));
		txtMealCharge.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtMealCharge.setHorizontalAlignment(SwingConstants.CENTER);
		txtMealCharge.setEditable(false);
		txtMealCharge.setBounds(480, 125, 116, 20);
		add(txtMealCharge);
		txtMealCharge.setColumns(10);
		
		
		lblMealType.setBounds(285, 54, 46, 14);
		add(lblMealType);
		lblMealType.setVisible(false);
		
		JLabel lblAddress = new JLabel("Address");
		lblAddress.setBounds(285, 87, 46, 14);
		lblAddress.setVisible(false);
		add(lblAddress);
		
		JLabel lblCity = new JLabel("City");
		lblCity.setBounds(285, 112, 46, 14);
		lblCity.setVisible(false);
		add(lblCity);
		
		JLabel lblState = new JLabel("State");
		lblState.setBounds(285, 133, 46, 14);
		lblState.setVisible(false);
		add(lblState);
		
		JLabel lblPIN = new JLabel("pin");
		lblPIN.setBounds(285, 165, 46, 14);
		lblPIN.setVisible(false);
		add(lblPIN);
		
		JLabel lblCountry = new JLabel("country");
		lblCountry.setBounds(285, 205, 46, 14);
		lblCountry.setVisible(false);
		add(lblCountry);
		
		JLabel lblPhone = new JLabel("Phone");
		lblPhone.setBounds(285, 238, 46, 14);
		lblPhone.setVisible(false);
		add(lblPhone);
		
		JLabel lblEmail = new JLabel("email");
		lblEmail.setBounds(283, 263, 46, 14);
		lblEmail.setVisible(false);
		add(lblEmail);
		
		lblSubtotal.setBounds(382, 263, 46, 14);
		lblSubtotal.setVisible(false);
		add(lblSubtotal);
	}
	
	public static String random(int length)
	{
		String alpha = new String("0123456789XYZ");
		int n = alpha.length();
		String result = new String();
		Random r = new Random();
		for(int i=0;i<length;i++)
			result = result+alpha.charAt(r.nextInt(n));
		return result;
	}
}
