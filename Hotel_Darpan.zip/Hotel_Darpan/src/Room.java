
public class Room {
	private int no, rate;
	private String ac, type, status;
	
	public Room(int no, int rate, String ac, String type, String status)
	{
		this.no = no;
		this.rate = rate;
		this.ac=ac;
		this.type=type;
		this.status=status;
	}
	
	public int getRno()
	{
		return no;
	}
	public int getRate(){
		return rate;
	}
	public String getAc(){
		return ac;
	}
	public String getType(){
		return type;
	}
	public String getStatus(){
		return status;
	}
}
