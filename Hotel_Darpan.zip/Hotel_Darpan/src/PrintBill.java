import java.awt.Component;
import java.awt.PageAttributes.PrintQualityType;
import java.awt.print.PageFormat;
import java.awt.print.Paper;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;

import javax.print.attribute.standard.PrintQuality;
import javax.print.attribute.standard.PrinterInfo;
import javax.print.attribute.standard.PrinterResolution;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class PrintBill extends Printer {
	public void printReport(Component centerPanel) {
		comp = centerPanel;
		PrinterJob job = PrinterJob.getPrinterJob();
	     
	     job.setCopies(1);
	     PageFormat p = new PageFormat();
	     p.setOrientation(PageFormat.PORTRAIT);
	     job.setPrintable(this, p);
	     
	     boolean ok = job.printDialog();
	         if (ok)
	        {
	            try
	            {
	              job.print();
	            }
	            catch (PrinterException ex)
	            {
	            
	            }
	        }
	}
}
