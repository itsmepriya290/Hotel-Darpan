import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.EventQueue;
import java.awt.Graphics;
import java.awt.Insets;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;

import java.awt.Window.Type;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Color;

import javax.swing.JLabel;

import java.awt.Font;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;

import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JTabbedPane;


public class MyAccount extends JFrame {

	private JPanel contentPane;
	private JTextField textFieldRoomId;
	private JTextField textFieldRoomCost;
	JTable table;
	String columnName[];
	String data[][];
	int col = 0, row = 0;
	Connection con;
	ResultSet rs;
	private JTextField txtRoomNo;
	private JTextField txtRRate;
	
	private CheckOutFormRoom checkOutForm = new CheckOutFormRoom();
	
	JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
	JTabbedPane tabbedPane2 = new JTabbedPane(JTabbedPane.TOP);
	
	
	JPanel baseForEmpRoom = new JPanel();
	
	///For tabbed pane
	CheckedOutList checkedOutList = new CheckedOutList();
	CheckedInList checkedInList = new CheckedInList();
	AddRoom addRoom = new AddRoom();
	RoomList roomList = new RoomList();
	EmployeeList employeeList = new EmployeeList();	
	AddEmployee addEmployee = new AddEmployee();
	RoomStatus2 roomStatus = new RoomStatus2();
	CheckOutFormHall checkOutFormHall = new CheckOutFormHall();
	
	//Add_Employee add_Employee = new Add_Employee();
	
	/**
	 * Launch the application.
	 
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MyAccount frame = new MyAccount();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MyAccount() {
		setResizable(false);
		setTitle("Admin Control");
		setBounds(100, 100, 725, 532);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setLocation(370, 140);
		setContentPane(contentPane);
		contentPane.setLayout(null);
		tabbedPane.setBounds(0, 0, 675, 380);
		tabbedPane.setBackground(Color.cyan);
		tabbedPane2.setBounds(0, 0, 675, 383);
		
		tabbedPane2.setBackground(Color.cyan);

		JPanel MainPanel = new JPanel();
		MainPanel.setBackground(Color.ORANGE);
		MainPanel.setBounds(-1, 74, 720, 434);
		contentPane.add(MainPanel);
		MainPanel.setLayout(null);
		
		baseForEmpRoom.setBounds(23, 21, 675, 383);
		MainPanel.add(baseForEmpRoom);
		baseForEmpRoom.setLayout(null);
		baseForEmpRoom.add(tabbedPane);
		
		
		tabbedPane.addTab("Check Out Customer", checkOutForm);
		
		//JPanel panelCheckoutCustomer = new JPanel();
		//tabbedPane.addTab("Check Out Customer", null, panelCheckoutCustomer, null);
		
		baseForEmpRoom.add(tabbedPane2);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.DARK_GRAY);
		panel.setForeground(Color.WHITE);
		panel.setBounds(0, 20, 719, 54);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Admin Controls");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel.setBounds(22, 0, 135, 50);
		panel.add(lblNewLabel);
		
		JLabel lblgetDetailsOf = new JLabel("Welcome Admin");
		lblgetDetailsOf.setForeground(Color.WHITE);
		lblgetDetailsOf.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblgetDetailsOf.setBounds(161, 0, 135, 50);
		panel.add(lblgetDetailsOf);
		
		
		
		
		
		
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBackground(Color.LIGHT_GRAY);
		menuBar.setBounds(0, 0, 719, 21);
		contentPane.add(menuBar);
		
		JMenu mnFile = new JMenu("File");
		menuBar.add(mnFile);
		
		JMenuItem mCheckoutRoom = new JMenuItem("Check Out Customer (Room)");
		JMenuItem mExit = new JMenuItem("Exit");
		mnFile.add(mCheckoutRoom);
		
		JMenuItem mCheckOutHall = new JMenuItem("Check Out Customer (Hall)");
		mnFile.add(mCheckOutHall);
		mnFile.addSeparator();
		mnFile.add(mExit);
		
		JMenu mnMonitoring = new JMenu("Monitoring");
		menuBar.add(mnMonitoring);
		
		JMenuItem mCheckedInList = new JMenuItem("Checked In List");
		JMenuItem mCheckedOutList = new JMenuItem("Checked Out List");
		JMenuItem mRoomStatus = new JMenuItem("Room Status");
		mnMonitoring.add(mCheckedInList);
		mnMonitoring.add(mCheckedOutList);
		mnMonitoring.addSeparator();
		mnMonitoring.add(mRoomStatus);
		
		JMenu mnSettings = new JMenu("Settings");
		menuBar.add(mnSettings);
		
		JMenuItem mRoom = new JMenuItem("Add Room");
		JMenuItem mEmployee = new JMenuItem("Add Employees");
		mnSettings.add(mRoom);
		mnSettings.add(mEmployee);
		
		
		
		
		
		
		
		/*mCheckedInList.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "Hello");
				try {
					con = DBConnection.getConnection();
					Statement stmt = con.createStatement();
					rs = stmt.executeQuery("select * from roombooking");
					ResultSetMetaData rsm = rs.getMetaData();
					col = rsm.getColumnCount();
					columnName = new String[col];
					for(int i=0;i<columnName.length;i++){
						columnName[i]=rsm.getColumnName(i+1);
					}
					while(rs.next())row++;
					rs = stmt.executeQuery("select * from roombooking");
					data = new String[row][col];
					for(int i=0;rs.next();i++){
						for(int j=0;j<col;j++)
						{
							data[i][j] = rs.getString(j+1);
						}
						System.out.println();
					}
					table = new JTable(data,columnName);
					getContentPane().add(new JScrollPane(table));
					//System.out.println(table);
					
				} catch (Exception e2) {
					// TODO: handle exception
					JOptionPane.showMessageDialog(null, e2.toString());
				}
				CheckedInList CheckIn = new CheckedInList();
				JPanel chkp = new JPanel();
				JScrollPane tableContainer = new JScrollPane(table);
				chkp.add(tableContainer);
				chkp.setSize(500, 500);
				chkp.setBounds(20, 20, 500, 500);
				chkp.setVisible(true);
				chkp.setBackground(Color.BLACK);
				add(chkp);
				setVisible(true);
				
				
				/*JFrame jp = new JFrame();
				contentPane.add(new JScrollPane(table));
				setSize(400, 200);
				setVisible(true);
				add(jp);*
			}
				
				
		});*/
		
		mCheckedInList.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
						
				tabbedPane.add("Checked In List", checkedInList);
				tabbedPane.remove(employeeList);
				tabbedPane.remove(checkedOutList);
				//tabbedPane.remove(addEmployee);
				tabbedPane.remove(addRoom);
				tabbedPane.remove(roomList);
				tabbedPane.remove(roomStatus);
				tabbedPane.remove(checkOutForm);
				tabbedPane.remove(checkOutFormHall);
			}
		});
		
		
		mCheckedOutList.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				tabbedPane.add("Checked Out List", checkedOutList);
				tabbedPane.remove(employeeList);
				tabbedPane.remove(checkedInList);
				//tabbedPane.remove(addEmployee);
				tabbedPane.remove(addRoom);
				tabbedPane.remove(roomList);
				tabbedPane.remove(roomStatus);
				tabbedPane.remove(checkOutForm);
				tabbedPane.remove(checkOutFormHall);
			}
		});
		
		mRoomStatus.addActionListener(new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e) {
				tabbedPane.add("Room Status",roomStatus);
				tabbedPane.remove(checkOutForm);
				tabbedPane.remove(checkedInList);
				tabbedPane.remove(checkedOutList);
				tabbedPane.remove(addEmployee);
				tabbedPane.remove(employeeList);
				tabbedPane.remove(employeeList);
				tabbedPane.remove(addRoom);
				tabbedPane.remove(roomList);
			}
		});
		
		mRoom.addActionListener(new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e) {
				
				tabbedPane.add("Add New Room", addRoom);
				tabbedPane.add("Room List", roomList);
				tabbedPane.remove(roomStatus);
				tabbedPane.remove(employeeList);
				tabbedPane.remove(addEmployee);
				tabbedPane.remove(checkedOutList);
				tabbedPane.remove(checkedInList);
				//tabbedPane.show();
				//tabbedPane2.hide();
				tabbedPane.remove(checkOutForm);
				tabbedPane.remove(checkOutFormHall);
			}
		});
		
		mCheckoutRoom.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				tabbedPane.add("Check out Customer", checkOutForm);
				
				//tabbedPane.show();
				tabbedPane.remove(checkOutFormHall);
				tabbedPane.remove(addRoom);
				//tabbedPane.remove(addEmployee);
				tabbedPane.remove(roomList);
				tabbedPane.remove(employeeList);
				tabbedPane.remove(roomStatus);
				tabbedPane.remove(checkedOutList);
				tabbedPane.remove(checkedInList);
			}
		});
		
		mCheckOutHall.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				tabbedPane.add("Check out Customer", checkOutFormHall);
				//tabbedPane.show();
				tabbedPane.remove(addRoom);
				tabbedPane.remove(checkOutForm);
				//tabbedPane.remove(addEmployee);
				tabbedPane.remove(roomList);
				tabbedPane.remove(employeeList);
				tabbedPane.remove(roomStatus);
				tabbedPane.remove(checkedOutList);
				tabbedPane.remove(checkedInList);
			}
		});
		
		mEmployee.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				tabbedPane.add("Add Employee", addEmployee);
				tabbedPane.add("Employee List", employeeList);
				//tabbedPane.add("New window", add_Employee);
				tabbedPane.remove(addRoom);
				tabbedPane.remove(roomList);
				tabbedPane.remove(checkedOutList);
				tabbedPane.remove(checkedInList);
				tabbedPane.remove(checkOutForm);
				tabbedPane.remove(checkOutFormHall);
				tabbedPane.remove(roomStatus);
			}
		});
		
		mExit.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
	}
}
