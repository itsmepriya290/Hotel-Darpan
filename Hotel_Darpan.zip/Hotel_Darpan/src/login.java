import java.awt.BorderLayout;
import java.awt.Cursor;
import java.awt.EventQueue;

import javax.swing.Icon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Color;

import javax.swing.JLabel;
import javax.swing.ImageIcon;

import java.awt.SystemColor;

import javax.swing.JTextField;
import javax.swing.JPasswordField;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JButton;

import java.awt.Toolkit;
import java.awt.Window.Type;


public class login extends JFrame implements ActionListener{

	private JPanel contentPane;
	private final JTextField txtUsername = new JTextField();
	private JPasswordField txtPassword;
	private JButton btnLogin;
	private JLabel lblNewLabel_1;
	private JButton btnGoToRegister;
	private JLabel lblForgotPassword;
	//private JButton btnForgotPassword;
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					login frame = new login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public login() {
		setResizable(false);
		setType(Type.POPUP);
		setTitle("Login");
		setIconImage(Toolkit.getDefaultToolkit().getImage("./images\\lock.PNG"));
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(450, 200, 529, 288);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		txtUsername.setToolTipText("Enter your username");
		txtUsername.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtUsername.setBounds(251, 98, 177, 20);
		contentPane.add(txtUsername);
		txtUsername.setColumns(10);
		
		txtPassword = new JPasswordField();
		txtPassword.setToolTipText("Enter your password");
		txtPassword.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtPassword.setBounds(252, 126, 177, 20);
		contentPane.add(txtPassword);
		
		btnLogin = new JButton("Log On");
		btnLogin.setToolTipText("Click to login");
		btnLogin.setForeground(SystemColor.inactiveCaptionBorder);
		btnLogin.setBackground(SystemColor.activeCaptionText);
		btnLogin.setBounds(356, 157, 75, 23);
		contentPane.add(btnLogin);
		
		btnGoToRegister = new JButton("Go to register page");
		btnGoToRegister.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnGoToRegister.setBounds(292, 185, 145, 25);
		btnGoToRegister.setForeground(SystemColor.inactiveCaptionBorder);
		btnGoToRegister.setBackground(SystemColor.activeCaptionText);
		btnGoToRegister.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnGoToRegister.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				Register register = new Register();
				register.setVisible(true);
				dispose();
			}
		});
		
		
		contentPane.add(btnGoToRegister);
		
		/*lblForgotPassword = new JLabel("Forgot password");
		lblForgotPassword.setBounds(361, 157, 83, 23);
		lblForgotPassword.setCursor(new Cursor(Cursor.HAND_CURSOR));
		contentPane.add(lblForgotPassword);
		*/
		
		/*btnForgotPassword = new JButton("Forgot password");
		btnForgotPassword.setForeground(new Color(255, 255, 255));
		btnForgotPassword.setBackground(new Color(0, 0, 0));
		btnForgotPassword.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnForgotPassword.setBounds(215, 157, 136, 25);
		//btnNewButton.setOpaque(false);
		btnForgotPassword.setBorder(null);
		btnForgotPassword.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnForgotPassword.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				ForgotPassword forgotPassword = new ForgotPassword();
				forgotPassword.setVisible(true);
				dispose();  
			}
		});*/
		
		
		//contentPane.add(btnForgotPassword);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("./images\\login_2.gif"));
		lblNewLabel.setBounds(0, 0, 525, 262);
		contentPane.add(lblNewLabel);
		
		lblNewLabel_1 = new JLabel("Register new admin?");
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_1.setBounds(251, 189, 118, 20);
		contentPane.add(lblNewLabel_1);
		btnLogin.addActionListener(this);
	
	}

	public void actionPerformed(ActionEvent e) {
			loginProcess();
		}

	private void loginProcess() {
		String name = txtUsername.getText();
		char[] pass = txtPassword.getPassword();
		
		String pwd = new String(pass);
		
		if(name.equals("")||pwd.equals(""))
		{
			JOptionPane.showMessageDialog(null, "You can't leave any field empty !", "Login Failed", JOptionPane.ERROR_MESSAGE);
		
		}
		
		else
		{
			try {
				Connection con = DBConnection.getConnection();
				Statement stmt = con.createStatement();
				Statement stmt2 = con.createStatement();
				ResultSet rs = stmt.executeQuery("select * from admin where username = '"+name+"' and password = '"+pwd+"' ");
				ResultSet rs2 = stmt2.executeQuery("select * from roombookingdetails where c_id = '"+name+"' and password = '"+pwd+"' ");
				if(rs.next())
				{
					mainPage mp = new mainPage();
					mp.setVisible(true);
					JLabel p = new JLabel("Welcome:"+name);
					mp.getContentPane().add(p);
					this.setVisible(false);
				}
				else if(rs2.next())
				{
					CustomerScreenFrame CSF = new CustomerScreenFrame();
					CSF.setVisible(true);
					JLabel p2 = new JLabel("Welcome:"+name);
					CSF.getContentPane().add(p2);
					this.setVisible(false);
				}
				
				else
				{
					JOptionPane.showMessageDialog(null, "Wrong Username or password combination !", "Login Failed", JOptionPane.ERROR_MESSAGE);
					txtUsername.setText("");
					txtPassword.setText("");
					txtUsername.requestFocus();
					
				}
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, e);
				}
			
		}
		
	}
}