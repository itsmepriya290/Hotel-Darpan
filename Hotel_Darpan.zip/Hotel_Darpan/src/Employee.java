public class Employee
{
		  
	 private int sl;
     private String eid;
     private String ename; 
     private String eage;
     private String esalary;
     private String eaddress; 
     private String epost;
     
           public Employee(int sl,String eno,String name,String age, String salary, String address,String post) {
        	   	  this.sl = sl;
        	   	  this.eid = eno;
                  this.ename = name;
                  this.eage = age;
                  this.esalary = salary; 
                  this.eaddress = address;
                  this.epost = post;
           }
           
   		public int getEmpSl() {
			// TODO Auto-generated method stub
			return sl;
		}
           
		public String getEmpId() {
			// TODO Auto-generated method stub
			return eid;
		}

		public String getEmpName() {
			// TODO Auto-generated method stub
			return ename;
		}

		public String getEmpAge() {
			// TODO Auto-generated method stub
			return eage;
		}

		public String  getEmpSalary() {
			// TODO Auto-generated method stub
			return esalary;
		}
		
		public String getEmpAddress() {
			// TODO Auto-generated method stub
			return eaddress;
		}



		public String getPost() {
			// TODO Auto-generated method stub
			return epost;
		} 
}