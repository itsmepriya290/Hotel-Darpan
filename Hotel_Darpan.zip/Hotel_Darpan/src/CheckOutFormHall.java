/*import javax.swing.JPanel;

import java.awt.Color;

import javax.swing.JLabel;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.LayoutManager;
import java.awt.SystemColor;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.UIManager;
import javax.swing.JTextField;

import java.awt.TextField;

import javax.swing.JButton;

import java.awt.Label;

import javax.swing.border.LineBorder;
import javax.swing.border.BevelBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.MatteBorder;
import javax.swing.table.DefaultTableCellRenderer;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;

import javax.swing.SwingConstants;


public class CheckOutFormHall extends JPanel {
	JTextField txtCustID;
	private JTextField txtCustomerName;
	private JTextField txtHallNo;
	private JTextField txtHallType;
	private JTextField txtCheckIn;
	private JTextField txtCheckOut;
	private JTextField txtHallRate;
	private JTextField txtTax;
	private JTextField txtTotal;
	private JTextField txtAdvPayment;
	private JTextField txtDues;
	private JTextField txtPayable;
	private JFrame fr = new JFrame();
	private JTable table = new JTable();
	private Label lblTotalDays = new Label("New label");
	private Label lblDay = new Label("");

	Connection con;
	Statement stmt;
	ResultSet rs;
	String columnName[];
	String data[][];
	int col=0,row=0;
	int i,j;
	JButton btnSelectC = new JButton("Select Customer");
	
	 * Create the panel.
	 
	 	public CheckOutFormHall() {
		setBackground(UIManager.getColor("Button.background"));
		setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Check out Form (Function Booking)");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel.setBounds(189, 9, 316, 22);
		add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("_______________________________________________");
		lblNewLabel_1.setBounds(170, 17, 351, 14);
		add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Cust. ID");
		lblNewLabel_2.setFont(new Font("Verdana", Font.BOLD, 13));
		lblNewLabel_2.setBounds(10, 52, 67, 14);
		add(lblNewLabel_2);
		
		txtCustID = new JTextField();
		txtCustID.setHorizontalAlignment(SwingConstants.CENTER);
		txtCustID.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtCustID.setEditable(false);
		txtCustID.setBounds(96, 48, 92, 24);
		add(txtCustID);
		
		JButton btnSelectCustomer = new JButton("....");
		btnSelectCustomer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				LayoutManager BorderLayout = null;
				fr.setTitle("Select Customer");
				fr.setBounds(500, 220, 550, 300);
				fr.setVisible(true);
				fr.getContentPane().setLayout(new BorderLayout(0, 0));
				table = new JTable();
				table.setBackground(Color.LIGHT_GRAY);
				fr.getContentPane().add(table);  
				try{
					con = DBConnection.getConnection();
					stmt = con.createStatement();
					rs = stmt.executeQuery("select c_id,c_fullname,h_no,check_in,check_out,total_days,h_type,h_rate,tax,grand_total,advance,due from func_booking");
					ResultSetMetaData rsm = rs.getMetaData();
					col = rsm.getColumnCount();
					
					columnName = new String[col];
					//for (i = 0; i < columnName.length; i++) {
						//columnName[i] = rsm.getColumnName(i+1);	
						columnName[0] = "<html><b>Cust. ID</b></html>";
						columnName[1] = "<html><b>Cust. Name</b></html>";
						columnName[2] = "<html><b>Hall No.</b></html>";
						columnName[3] = "<html><b>Check In</b></html>";
						columnName[4] = "<html><b>Check Out</b></html>";
						columnName[5] = "<html><b>Total Day</b></html>";
						columnName[6] = "<html><b>Hall Type</b></html>";
						columnName[7] = "<html><b>Hall Rate</b></html>";
						columnName[8] = "<html><b>Tax</b></html>";
						columnName[9] = "<html><b>Total</b></html>";
						columnName[10] = "<html><b>Adv. Payment</b></html>";
						columnName[11] = "<html><b>Payable</b></html>";
						//}
					while (rs.next())row++;
					rs = stmt.executeQuery("select c_id,c_fullname,h_no,check_in,check_out,total_days,h_type,h_rate,tax,grand_total,advance,due from func_booking");
					data = new String[row][col];
					for (i = 0; rs.next(); i++) 
					{
						for (j = 0; j<col; j++)
						{	
							data[i][j] = rs.getString(j+1);
						}
					}
					table = new JTable(data, columnName);
					
				}catch(Exception exc)
				{	
					JOptionPane.showMessageDialog(null, exc.toString());
				}
				JPanel p = new  JPanel();
				p.setBackground(Color.ORANGE);
				p.add(btnSelectC);
				fr.getContentPane().add(p,"South");
				
				JScrollPane tableContainer = new JScrollPane(table,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
				table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
				
				fr.getContentPane().add(tableContainer);
				fr.setVisible(true);
				fr.setResizable(false);
				DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
				centerRenderer.setHorizontalAlignment(JLabel.CENTER);
				for(int c = 0;c<col;c++)
				{
					table.getColumnModel().getColumn(c).setCellRenderer(centerRenderer);
				}
			}
		});
		
		
		
		
		btnSelectCustomer.setBounds(211, 49, 49, 23);
		add(btnSelectCustomer);
		
		Label label = new Label("Cust. Name");
		label.setFont(new Font("Verdana", Font.BOLD, 13));
		label.setBounds(382, 50, 79, 22);
		add(label);
		
		txtCustomerName = new JTextField();
		txtCustomerName.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtCustomerName.setHorizontalAlignment(SwingConstants.CENTER);
		txtCustomerName.setEditable(false);
		txtCustomerName.setBounds(480, 49, 154, 24);
		add(txtCustomerName);
		txtCustomerName.setColumns(10);
		
		Label label_1 = new Label("Hall No.");
		label_1.setFont(new Font("Verdana", Font.BOLD, 12));
		label_1.setBounds(10, 87, 62, 22);
		add(label_1);
		
		Label label_3 = new Label("Hall Type");
		label_3.setFont(new Font("Verdana", Font.BOLD, 12));
		label_3.setBounds(10, 125, 67, 22);
		add(label_3);
		
		txtHallNo = new JTextField();
		txtHallNo.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtHallNo.setHorizontalAlignment(SwingConstants.CENTER);
		txtHallNo.setEditable(false);
		txtHallNo.setBounds(95, 88, 94, 24);
		add(txtHallNo);
		txtHallNo.setColumns(10);
		
		txtHallType = new JTextField();
		txtHallType.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtHallType.setHorizontalAlignment(SwingConstants.CENTER);
		txtHallType.setEditable(false);
		txtHallType.setBounds(96, 126, 94, 24);
		add(txtHallType);
		txtHallType.setColumns(10);
		
		Label label_4 = new Label("Check In ");
		label_4.setFont(new Font("Vani", Font.BOLD, 12));
		label_4.setBounds(10, 165, 62, 22);
		add(label_4);
		
		Label label_5 = new Label("Check Out");
		label_5.setFont(new Font("Verdana", Font.BOLD, 12));
		label_5.setBounds(10, 197, 67, 22);
		add(label_5);
		
		Label label_6 = new Label("Total Days");
		label_6.setFont(new Font("Vani", Font.BOLD, 12));
		label_6.setBounds(12, 237, 62, 22);
		add(label_6);
		
		txtCheckIn = new JTextField();
		txtCheckIn.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtCheckIn.setEditable(false);
		txtCheckIn.setBounds(96, 165, 174, 24);
		add(txtCheckIn);
		txtCheckIn.setColumns(10);
		
		txtCheckOut = new JTextField();
		txtCheckOut.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtCheckOut.setEditable(false);
		txtCheckOut.setBounds(96, 200, 174, 24);
		add(txtCheckOut);
		txtCheckOut.setColumns(10);
		
		//Label lblTotalDays = new Label("New label");
		lblTotalDays.setFont(new Font("Verdana", Font.BOLD, 13));
		lblTotalDays.setBounds(96, 238, 33, 22);
		add(lblTotalDays);
		
		//Label lblDay = new Label("");
		lblDay.setFont(new Font("Verdana", Font.BOLD, 13));
		lblDay.setBounds(130, 238, 49, 22);
		add(lblDay);
		
		Label label_2 = new Label("Hall Rate");
		label_2.setFont(new Font("Vani", Font.BOLD, 12));
		label_2.setBounds(382, 87, 79, 22);
		add(label_2);
		
		txtHallRate = new JTextField();
		txtHallRate.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtHallRate.setHorizontalAlignment(SwingConstants.CENTER);
		txtHallRate.setEditable(false);
		txtHallRate.setBounds(480, 86, 116, 23);
		add(txtHallRate);
		txtHallRate.setColumns(10);
		
		Label label_7 = new Label("Tax (10%)");
		label_7.setFont(new Font("Vani", Font.BOLD, 12));
		label_7.setBounds(382, 125, 62, 22);
		add(label_7);
		
		txtTax = new JTextField();
		txtTax.setForeground(new Color(139, 0, 0));
		txtTax.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtTax.setHorizontalAlignment(SwingConstants.CENTER);
		txtTax.setEditable(false);
		txtTax.setBounds(480, 123, 116, 24);
		add(txtTax);
		txtTax.setColumns(10);
		
		Label label_8 = new Label("Total");
		label_8.setFont(new Font("Verdana", Font.BOLD, 12));
		label_8.setBounds(382, 166, 62, 22);
		add(label_8);
		
		JLabel lblNewLabel_3 = new JLabel("Adv. Payment");
		lblNewLabel_3.setFont(new Font("Verdana", Font.BOLD, 11));
		lblNewLabel_3.setBounds(382, 204, 90, 14);
		add(lblNewLabel_3);
		
		txtTotal = new JTextField();
		txtTotal.setForeground(new Color(139, 0, 0));
		txtTotal.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtTotal.setHorizontalAlignment(SwingConstants.CENTER);
		txtTotal.setEditable(false);
		txtTotal.setBounds(480, 164, 116, 24);
		add(txtTotal);
		txtTotal.setColumns(10);
		
		txtAdvPayment = new JTextField();
		txtAdvPayment.setForeground(new Color(139, 0, 0));
		txtAdvPayment.setFont(new Font("Tahoma", Font.BOLD, 13));
		txtAdvPayment.setHorizontalAlignment(SwingConstants.CENTER);
		txtAdvPayment.setEditable(false);
		txtAdvPayment.setBounds(480, 201, 116, 24);
		add(txtAdvPayment);
		txtAdvPayment.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("Dues");
		lblNewLabel_4.setFont(new Font("Verdana", Font.BOLD, 11));
		lblNewLabel_4.setBounds(382, 247, 90, 14);
		add(lblNewLabel_4);
		
		txtDues = new JTextField();
		txtDues.setForeground(new Color(139, 0, 0));
		txtDues.setFont(new Font("Tahoma", Font.BOLD, 13));
		txtDues.setHorizontalAlignment(SwingConstants.CENTER);
		txtDues.setEditable(false);
		txtDues.setBounds(480, 236, 116, 36);
		add(txtDues);
		txtDues.setColumns(10);
		
		JPanel panel = new JPanel();
		panel.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		panel.setBounds(45, 288, 583, 60);
		add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_5 = new JLabel("Total Payable");
		lblNewLabel_5.setFont(new Font("Verdana", Font.BOLD, 15));
		lblNewLabel_5.setBounds(25, 20, 126, 20);
		panel.add(lblNewLabel_5);
		
		txtPayable = new JTextField();
		txtPayable.setForeground(new Color(139, 0, 0));
		txtPayable.setFont(new Font("Segoe UI Emoji", Font.BOLD, 24));
		txtPayable.setHorizontalAlignment(SwingConstants.CENTER);
		txtPayable.setEditable(false);
		txtPayable.setBounds(161, 12, 141, 37);
		panel.add(txtPayable);
		txtPayable.setColumns(10);
		
		JButton btnNewButton = new JButton("CHECKOUT & PRINT BILL");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				if(txtCustID.getText().trim().equals("")){
					JOptionPane.showMessageDialog(null, "Pleas Select Customer ID");
				}
				else{
					//Room();
					try{
						con = DBConnection.getConnection();
						stmt = con.createStatement();
						
						String updateQuery = "update hall set h_status = 'Available' where h_number = '"+txtHallNo.getText()+"'";
						String deleteQuery = "delete from func_booking where h_no = '"+txtHallNo.getText()+"'";
						
						String copyQuery = "insert into all_checkout(cust_id,room_no,check_in,check_out,total_day,no_of_person,purpose_visit,room,c_fullname,c_son_of,c_address,c_state,c_city,c_country,c_pin,c_mobile,c_email,grand_total,payment_mode,identity,meal_plan,r_type)select c_id,h_no,check_in,check_out,total_days,no_of_person,purpose_booking,h_type,c_fullname,c_son_of,c_address,c_state,c_city,c_country,c_pin,c_mobile,c_email,grand_total,payment_mode,identity_image,meal_plan,r_type from func_booking where h_no = '"+txtHallNo.getText()+"'";
						stmt.execute(copyQuery);
						
						PreparedStatement updateStatement = con.prepareStatement(updateQuery);
						PreparedStatement deleteStatement = con.prepareStatement(deleteQuery); 
						updateStatement.executeUpdate();
						deleteStatement.execute();
						
					}
					catch(Exception ex){JOptionPane.showMessageDialog(null, ex.toString());}
					//CheckOutBill cBill = new CheckOutBill();
					CheckOutBill cBill = null;
					try {
						cBill = new CheckOutBill();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					JFrame billFrame = new JFrame();
					billFrame.setBounds(400, 0, 700, 990);
					billFrame.setVisible(true);
					//billFrame.getContentPane().add(cBill);
					billFrame.getContentPane().add(cBill);
					PrintBill p = new PrintBill();
					p.printReport(billFrame);
					JScrollPane scr = new JScrollPane(billFrame);
				}
			}

		});
		btnNewButton.setBackground(new Color(0, 0, 0));
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setFont(new Font("Traditional Arabic", Font.BOLD, 12));
		btnNewButton.setBounds(334, 13, 207, 39);
		panel.add(btnNewButton);
		
		
		btnSelectC.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
			
				try{
					int row = table.getSelectedRow();
					int column = table.getColumnCount();
					for(int i = 0;i<column;i++)
					{
						Object dt = table.getValueAt(row, i);
						txtCustID.setText((String) table.getValueAt(row, 0));
						txtCustomerName.setText((String) table.getValueAt(row, 1));
						txtHallNo.setText((String) table.getValueAt(row, 2));
						txtCheckIn.setText((String) table.getValueAt(row, 3));
						txtCheckOut.setText((String) table.getValueAt(row, 4));
						lblTotalDays.setText((String) table.getValueAt(row, 5));
						lblDay.setText("Days");
						txtHallType.setText((String) table.getValueAt(row, 6));
						txtHallRate.setText((String) table.getValueAt(row, 7));
						txtTax.setText((String) table.getValueAt(row, 8));
						txtTotal.setText((String) table.getValueAt(row, 9));
						txtAdvPayment.setText((String) table.getValueAt(row, 10));
						txtDues.setText((String) table.getValueAt(row, 11));
						txtPayable.setText((String) table.getValueAt(row, 11));
					}
				}
				catch(Exception ex){
					JOptionPane.showMessageDialog(null, ex.toString());
				}
				fr.dispose();	
			}		
		});
	}
	
}*/


import javax.swing.JPanel;

import java.awt.Color;

import javax.swing.JLabel;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.LayoutManager;
import java.awt.SystemColor;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.UIManager;
import javax.swing.JTextField;

import java.awt.TextField;

import javax.swing.JButton;

import java.awt.Label;

import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import javax.swing.border.BevelBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.MatteBorder;
import javax.swing.table.DefaultTableCellRenderer;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import javax.swing.SwingConstants;


public class CheckOutFormHall extends JPanel {
	JTextField txtCustID;
	private JTextField txtCustomerName;
	private JTextField txtHallNo;
	private JTextField txtHallType;
	private JTextField txtCheckIn;
	private JTextField txtCheckOut;
	private JTextField txtHallRate;
	private JTextField txtTax;
	private JTextField txtTotal;
	private JTextField txtAdvPayment;
	private JTextField txtDues;
	private JTextField txtPayable;
	private JTextField txtRoomNo;
	private JTextField txtRoomType;
	private Label lblRoomTypeAC;
	
	private JFrame fr = new JFrame();
	private JTable table = new JTable();
	
	JLabel lblAddress = new JLabel("Lbl Address");
	JLabel lblCity = new JLabel("lbl City");
	JLabel lblState = new JLabel("lbl State");
	JLabel lblPIN = new JLabel("lbl PIN");
	JLabel lblCountry = new JLabel("lbl country");
	JLabel lblPhone = new JLabel("lbl phone");
	JLabel lblEmail = new JLabel("lbl email");
	JLabel lblSubtotal = new JLabel("Subtotal");
	Label lblTotalDays = new Label();
	Label lblDay = new Label("");
	Label lblTotalPers = new Label();
	

	Connection con;
	Statement stmt;
	ResultSet rs;
	String columnName[];
	String data[][];
	int col=0,row=0;
	int i,j, hall_price;
	JButton btnSelectC = new JButton("Select Customer");
	String date = new SimpleDateFormat("dd-MM-y  hh:mm a").format(new Date()); 
	Border a = BorderFactory.createLineBorder(Color.BLUE, 2);
	/**
	 * Create the panel.
	 */
	public CheckOutFormHall() {
		setBackground(UIManager.getColor("Button.background"));
		setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Check out Form (Function Booking)");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel.setBounds(189, 9, 316, 22);
		add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("_______________________________________________");
		lblNewLabel_1.setBounds(170, 17, 351, 14);
		add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Cust. ID");
		lblNewLabel_2.setFont(new Font("Verdana", Font.BOLD, 13));
		lblNewLabel_2.setBounds(10, 52, 67, 14);
		add(lblNewLabel_2);
		
		txtCustID = new JTextField();
		txtCustID.setHorizontalAlignment(SwingConstants.CENTER);
		txtCustID.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtCustID.setEditable(false);
		txtCustID.setBounds(96, 48, 92, 24);
		add(txtCustID);
		
		JButton btnSelectCustomer = new JButton("....");
		btnSelectCustomer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				LayoutManager BorderLayout = null;
				fr.setTitle("Select Customer");
				fr.setBounds(500, 220, 550, 300);
				fr.setVisible(true);
				fr.getContentPane().setLayout(new BorderLayout(0, 0));
				table = new JTable();
				table.setBackground(Color.LIGHT_GRAY);
				fr.getContentPane().add(table);  
				try{
					con = DBConnection.getConnection();
					stmt = con.createStatement();
					rs = stmt.executeQuery("select c_id,c_fullname,h_no,check_in,check_out,total_days,no_of_person,h_type,h_rate,tax,grand_total,advance,due from func_booking");
					ResultSetMetaData rsm = rs.getMetaData();
					col = rsm.getColumnCount();
					
					columnName = new String[col];
					//for (i = 0; i < columnName.length; i++) {
						//columnName[i] = rsm.getColumnName(i+1);	
						columnName[0] = "<html><b>Cust. ID</b></html>";
						columnName[1] = "<html><b>Cust. Name</b></html>";
						columnName[2] = "<html><b>Hall No.</b></html>";
						columnName[3] = "<html><b>Check In</b></html>";
						columnName[4] = "<html><b>Check Out</b></html>";
						columnName[5] = "<html><b>Total Day</b></html>";
						
						columnName[6] = "<html><b>No. of Person</b></html>";
						columnName[7] = "<html><b>Hall Type</b></html>";
						columnName[8] = "<html><b>Hall Rate</b></html>";
						columnName[9] = "<html><b>Tax</b></html>";
						columnName[10] = "<html><b>Total</b></html>";
						columnName[11] = "<html><b>Adv. Payment</b></html>";
						//columnName[12] = "<html><b>Dues</b></html>";
						columnName[12] = "<html><b>Payable</b></html>";
						
						//}
					while (rs.next())row++;
					rs = stmt.executeQuery("select c_id,c_fullname,h_no,check_in,check_out,total_days,no_of_person,h_type,h_rate,tax,grand_total,advance,due from func_booking");
					data = new String[row][col];
					for (i = 0; rs.next(); i++) 
					{
						for (j = 0; j<col; j++)
						{	
							data[i][j] = rs.getString(j+1);
						}
					}
					table = new JTable(data, columnName);
					
				}catch(Exception exc)
				{	
					JOptionPane.showMessageDialog(null, exc.toString());
				}
				JPanel p = new  JPanel();
				p.setBackground(Color.ORANGE);
				p.add(btnSelectC);
				fr.getContentPane().add(p,"South");
				
				JScrollPane tableContainer = new JScrollPane(table,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
				table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
				
				fr.getContentPane().add(tableContainer);
				fr.setVisible(true);
				fr.setResizable(false);
				DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
				centerRenderer.setHorizontalAlignment(JLabel.CENTER);
				for(int c = 0;c<col;c++)
				{
					table.getColumnModel().getColumn(c).setCellRenderer(centerRenderer);
				}
			}
		});
		
		
		
		btnSelectC.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
			
				try{
					int row = table.getSelectedRow();
					int column = table.getColumnCount();
					for(int i = 0;i<column;i++)
					{
						Object dt = table.getValueAt(row, i);
						txtCustID.setText((String) table.getValueAt(row, 0));
						txtCustomerName.setText((String) table.getValueAt(row, 1));
						txtHallNo.setText((String) table.getValueAt(row, 2));
						txtCheckIn.setText((String) table.getValueAt(row, 3));
						txtCheckOut.setText((String) table.getValueAt(row, 4));
						lblTotalDays.setText((String) table.getValueAt(row, 5));
						lblDay.setText("Days");
						lblTotalPers.setText((String)table.getValueAt(row, 6));
						
						txtHallType.setText((String) table.getValueAt(row, 7));
						txtHallRate.setText((String) table.getValueAt(row, 8));
						txtTax.setText((String) table.getValueAt(row, 9));
						txtTotal.setText((String) table.getValueAt(row, 10));
						txtAdvPayment.setText((String) table.getValueAt(row, 11));
						txtDues.setText((String) table.getValueAt(row, 12));
						txtPayable.setText((String) table.getValueAt(row, 12));
					}
					hall_price = Integer.parseInt(lblTotalDays.getText()) * Integer.parseInt(txtHallRate.getText());
				}
				catch(Exception ex){
					JOptionPane.showMessageDialog(null, ex.toString());
				}
				fr.dispose();	
			}		
		});
		
		
		
		
		btnSelectCustomer.setBounds(211, 49, 49, 23);
		add(btnSelectCustomer);
		
		Label label = new Label("Cust. Name");
		label.setFont(new Font("Verdana", Font.BOLD, 13));
		label.setBounds(382, 50, 79, 22);
		add(label);
		
		txtCustomerName = new JTextField();
		txtCustomerName.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtCustomerName.setHorizontalAlignment(SwingConstants.CENTER);
		txtCustomerName.setEditable(false);
		txtCustomerName.setBounds(480, 49, 154, 24);
		add(txtCustomerName);
		txtCustomerName.setColumns(10);
		
		Label label_1 = new Label("Hall No.");
		label_1.setFont(new Font("Verdana", Font.BOLD, 12));
		label_1.setBounds(10, 87, 62, 22);
		add(label_1);
		
		Label label_3 = new Label("Hall Type");
		label_3.setFont(new Font("Verdana", Font.BOLD, 12));
		label_3.setBounds(10, 125, 67, 22);
		add(label_3);
		
		txtHallNo = new JTextField();
		txtHallNo.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtHallNo.setHorizontalAlignment(SwingConstants.CENTER);
		txtHallNo.setEditable(false);
		txtHallNo.setBounds(95, 88, 94, 24);
		add(txtHallNo);
		txtHallNo.setColumns(10);
		
		txtHallType = new JTextField();
		txtHallType.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtHallType.setHorizontalAlignment(SwingConstants.CENTER);
		txtHallType.setEditable(false);
		txtHallType.setBounds(96, 126, 94, 24);
		add(txtHallType);
		txtHallType.setColumns(10);
		
		
		txtRoomNo = new JTextField();
		txtRoomNo.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtRoomNo.setHorizontalAlignment(SwingConstants.CENTER);
		txtRoomNo.setEditable(false);
		txtRoomNo.setBounds(95, 88, 94, 24);
		add(txtRoomNo);
		txtRoomNo.setColumns(10);
		
		txtRoomType = new JTextField();
		txtRoomType.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtRoomType.setHorizontalAlignment(SwingConstants.CENTER);
		txtRoomType.setEditable(false);
		txtRoomType.setBounds(96, 126, 94, 24);
		add(txtRoomType);
		txtRoomType.setColumns(10);
		
		lblRoomTypeAC = new Label("New label");
		lblRoomTypeAC.setFont(new Font("Verdana", Font.BOLD, 12));
		lblRoomTypeAC.setBounds(194, 126, 62, 22);
		add(lblRoomTypeAC);
		
		Label label_4 = new Label("Check In ");
		label_4.setFont(new Font("Vani", Font.BOLD, 12));
		label_4.setBounds(10, 165, 62, 22);
		add(label_4);
		
		Label label_5 = new Label("Check Out");
		label_5.setFont(new Font("Verdana", Font.BOLD, 12));
		label_5.setBounds(10, 197, 67, 22);
		add(label_5);
		
		Label label_6 = new Label("Total Days");
		label_6.setFont(new Font("Vani", Font.BOLD, 12));
		label_6.setBounds(12, 237, 62, 22);
		add(label_6);
		
		txtCheckIn = new JTextField();
		txtCheckIn.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtCheckIn.setEditable(false);
		txtCheckIn.setBounds(96, 165, 174, 24);
		add(txtCheckIn);
		txtCheckIn.setColumns(10);
		
		txtCheckOut = new JTextField();
		txtCheckOut.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtCheckOut.setEditable(false);
		txtCheckOut.setBounds(96, 200, 174, 24);
		add(txtCheckOut);
		txtCheckOut.setColumns(10);
		
		
		lblTotalDays.setFont(new Font("Verdana", Font.BOLD, 13));
		lblTotalDays.setBounds(96, 238, 33, 22);
		add(lblTotalDays);
		
		
		lblDay.setFont(new Font("Verdana", Font.BOLD, 13));
		lblDay.setBounds(130, 238, 49, 22);
		add(lblDay);
		
		Label label_2 = new Label("Hall Rate");
		label_2.setFont(new Font("Vani", Font.BOLD, 12));
		label_2.setBounds(382, 87, 79, 22);
		add(label_2);
		
		txtHallRate = new JTextField();
		txtHallRate.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtHallRate.setHorizontalAlignment(SwingConstants.CENTER);
		txtHallRate.setEditable(false);
		txtHallRate.setBounds(480, 86, 116, 23);
		add(txtHallRate);
		txtHallRate.setColumns(10);
		
		Label label_7 = new Label("Tax (10%)");
		label_7.setFont(new Font("Vani", Font.BOLD, 12));
		label_7.setBounds(382, 125, 62, 22);
		add(label_7);
		
		txtTax = new JTextField();
		txtTax.setForeground(new Color(139, 0, 0));
		txtTax.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtTax.setHorizontalAlignment(SwingConstants.CENTER);
		txtTax.setEditable(false);
		txtTax.setBounds(480, 123, 116, 24);
		add(txtTax);
		txtTax.setColumns(10);
		
		Label label_8 = new Label("Total");
		label_8.setFont(new Font("Verdana", Font.BOLD, 12));
		label_8.setBounds(382, 166, 62, 22);
		add(label_8);
		
		JLabel lblNewLabel_3 = new JLabel("Adv. Payment");
		lblNewLabel_3.setFont(new Font("Verdana", Font.BOLD, 11));
		lblNewLabel_3.setBounds(382, 204, 90, 14);
		add(lblNewLabel_3);
		
		txtTotal = new JTextField();
		txtTotal.setForeground(new Color(139, 0, 0));
		txtTotal.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtTotal.setHorizontalAlignment(SwingConstants.CENTER);
		txtTotal.setEditable(false);
		txtTotal.setBounds(480, 164, 116, 24);
		add(txtTotal);
		txtTotal.setColumns(10);
		
		txtAdvPayment = new JTextField();
		txtAdvPayment.setForeground(new Color(139, 0, 0));
		txtAdvPayment.setFont(new Font("Tahoma", Font.BOLD, 13));
		txtAdvPayment.setHorizontalAlignment(SwingConstants.CENTER);
		txtAdvPayment.setEditable(false);
		txtAdvPayment.setBounds(480, 201, 116, 24);
		add(txtAdvPayment);
		txtAdvPayment.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("Dues");
		lblNewLabel_4.setFont(new Font("Verdana", Font.BOLD, 11));
		lblNewLabel_4.setBounds(382, 247, 90, 14);
		add(lblNewLabel_4);
		
		txtDues = new JTextField();
		txtDues.setForeground(new Color(139, 0, 0));
		txtDues.setFont(new Font("Tahoma", Font.BOLD, 13));
		txtDues.setHorizontalAlignment(SwingConstants.CENTER);
		txtDues.setEditable(false);
		txtDues.setBounds(480, 236, 116, 36);
		add(txtDues);
		txtDues.setColumns(10);
		
		JPanel panel = new JPanel();
		panel.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		panel.setBounds(45, 288, 583, 60);
		add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_5 = new JLabel("Total Payable");
		lblNewLabel_5.setFont(new Font("Verdana", Font.BOLD, 15));
		lblNewLabel_5.setBounds(25, 20, 126, 20);
		panel.add(lblNewLabel_5);
		
		txtPayable = new JTextField();
		txtPayable.setForeground(new Color(139, 0, 0));
		txtPayable.setFont(new Font("Segoe UI Emoji", Font.BOLD, 24));
		txtPayable.setHorizontalAlignment(SwingConstants.CENTER);
		txtPayable.setEditable(false);
		txtPayable.setBounds(161, 12, 141, 37);
		panel.add(txtPayable);
		txtPayable.setColumns(10);
		
		JButton btnNewButton = new JButton("CHECKOUT & PRINT BILL");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				if(txtCustID.getText().trim().equals("")){
					JOptionPane.showMessageDialog(null, "Pleas Select Customer ID");
				}
				else{
					try{
						con = DBConnection.getConnection();
						stmt = con.createStatement();
						
						String updateQuery = "update hall set h_status = 'Available' where h_number = '"+txtHallNo.getText()+"'";
						String deleteQuery = "delete from func_booking where h_no = '"+txtHallNo.getText()+"'";
						
						String copyQuery = "insert into all_checkout(cust_id,room_no,check_in,check_out,total_day,no_of_person,purpose_visit,room,c_fullname,c_son_of,c_address,c_state,c_city,c_country,c_pin,c_mobile,c_email,grand_total,payment_mode,identity,meal_plan,r_type)select c_id,h_no,check_in,check_out,total_days,no_of_person,purpose_booking,h_type,c_fullname,c_son_of,c_address,c_state,c_city,c_country,c_pin,c_mobile,c_email,grand_total,payment_mode,identity_image,meal_plan,r_type from func_booking where h_no = '"+txtHallNo.getText()+"'";
						stmt.execute(copyQuery);
						
						PreparedStatement updateStatement = con.prepareStatement(updateQuery);
						PreparedStatement deleteStatement = con.prepareStatement(deleteQuery); 
						updateStatement.executeUpdate();
						deleteStatement.execute();
						
					}
					catch(Exception ex){JOptionPane.showMessageDialog(null, ex.toString());}
					
					//CheckOutBill cBill = new CheckOutBill();
					
					JPanel Billpanel = new JPanel();
					
					Billpanel.setBorder(new LineBorder(new Color(0, 0, 0)));
					Billpanel.setLayout(null);
					Billpanel.setBounds(0, 0, 859, 851);
					//JPanel panel = new JPanel();
					Billpanel.setBackground(Color.WHITE);
					Billpanel.setBounds(10, 11, 859, 959);
					add(Billpanel);
					
					JLabel lblNewLabel = new JLabel("Hotel Darpan");
					lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 30));
					lblNewLabel.setBounds(115, 12, 200, 50);
					Billpanel.add(lblNewLabel);
					
					JLabel lblNewLabel_1 = new JLabel("INVOICE");
					lblNewLabel_1.setForeground(SystemColor.textHighlight);
					lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 21));
					lblNewLabel_1.setBounds(636, 12, 103, 50);
					Billpanel.add(lblNewLabel_1);
					
					JLabel lblNewLabel_2 = new JLabel("");
					lblNewLabel_2.setIcon(new ImageIcon("./images\\info.png"));
					lblNewLabel_2.setBounds(26, 12, 76, 67);
					Billpanel.add(lblNewLabel_2);
					
					JLabel lblNewLabel_3 = new JLabel("______________________________________________________________________________________________");
					lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 13));
					lblNewLabel_3.setBounds(28, 124, 821, 31);
					Billpanel.add(lblNewLabel_3);
					
					JLabel lblNewLabel_4 = new JLabel("New Police Line");
					lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 13));
					lblNewLabel_4.setBounds(116, 61, 161, 14);
					Billpanel.add(lblNewLabel_4);
					
					JLabel lblNewLabel_5 = new JLabel("Lodipur, Buddha Marg");
					lblNewLabel_5.setFont(new Font("Tahoma", Font.PLAIN, 13));
					lblNewLabel_5.setBounds(116, 86, 163, 14);
					Billpanel.add(lblNewLabel_5);
					
					JLabel lblNewLabel_6 = new JLabel("9334447788, Patna - 1");
					lblNewLabel_6.setFont(new Font("Tahoma", Font.PLAIN, 13));
					lblNewLabel_6.setBounds(115, 111, 165, 14);
					Billpanel.add(lblNewLabel_6);
					
					JLabel lblNewLabel_7 = new JLabel("DATE : ");
					lblNewLabel_7.setFont(new Font("Tahoma", Font.BOLD, 13));
					lblNewLabel_7.setBounds(536, 71, 57, 14);
					Billpanel.add(lblNewLabel_7);
					
					JLabel lblDate = new JLabel(date);
					lblDate.setFont(new Font("Tahoma", Font.BOLD, 13));
					lblDate.setBounds(596, 71, 147, 14);
					Billpanel.add(lblDate);
					
					JLabel lblNewLabel_8 = new JLabel("INVOICE NO. :");
					lblNewLabel_8.setFont(new Font("Tahoma", Font.BOLD, 13));
					lblNewLabel_8.setBounds(494, 90, 91, 14);
					Billpanel.add(lblNewLabel_8);
					
					JLabel lblInvoice = new JLabel("INV"+random(3));
					lblInvoice.setFont(new Font("Tahoma", Font.BOLD, 13));
					lblInvoice.setBounds(596, 90, 91, 14);
					Billpanel.add(lblInvoice);
					
					JLabel lblNewLabel_9 = new JLabel("BILL TO");
					lblNewLabel_9.setFont(new Font("Verdana", Font.BOLD, 18));
					lblNewLabel_9.setBounds(121, 174, 91, 23);
					Billpanel.add(lblNewLabel_9);
					
					JLabel lblNewLabel_10 = new JLabel("______________");
					lblNewLabel_10.setBounds(120, 183, 104, 14);
					Billpanel.add(lblNewLabel_10);
					
					JLabel lblNewLabel_11 = new JLabel("______________");
					lblNewLabel_11.setBounds(120, 185, 104, 14);
					Billpanel.add(lblNewLabel_11);
					
					JLabel lblNewLabel_12 = new JLabel("Coustomer ID:");
					lblNewLabel_12.setFont(new Font("Tahoma", Font.PLAIN, 14));
					lblNewLabel_12.setBounds(226, 182, 103, 14);
					Billpanel.add(lblNewLabel_12);
					
					JLabel lblNewLabel_13 = new JLabel("ROOM DETAILS");
					lblNewLabel_13.setFont(new Font("Verdana", Font.BOLD, 18));
					lblNewLabel_13.setBounds(560, 174, 161, 31);
					Billpanel.add(lblNewLabel_13);
					
					JLabel lblNewLabel_14 = new JLabel("__________________________");
					lblNewLabel_14.setBounds(555, 190, 188, 14);
					Billpanel.add(lblNewLabel_14);
					
					JLabel lblNewLabel_15 = new JLabel("__________________________");
					lblNewLabel_15.setBounds(555, 188, 188, 14);
					Billpanel.add(lblNewLabel_15);
					
					JLabel lblNewLabel_16 = new JLabel("Name :");
					lblNewLabel_16.setFont(new Font("Tahoma", Font.PLAIN, 13));
					lblNewLabel_16.setBounds(82, 215, 76, 14);
					Billpanel.add(lblNewLabel_16);
					
					JLabel lblNewLabel_17 = new JLabel("Address :");
					lblNewLabel_17.setFont(new Font("Tahoma", Font.PLAIN, 13));
					lblNewLabel_17.setBounds(82, 238, 77, 14);
					Billpanel.add(lblNewLabel_17);
					
					JLabel lblNewLabel_18 = new JLabel("City, State ZIP :");
					lblNewLabel_18.setFont(new Font("Tahoma", Font.PLAIN, 13));
					lblNewLabel_18.setBounds(82, 263, 103, 14);
					Billpanel.add(lblNewLabel_18);
					
					JLabel lblNewLabel_19 = new JLabel("Country :");
					lblNewLabel_19.setFont(new Font("Tahoma", Font.PLAIN, 13));
					lblNewLabel_19.setBounds(82, 287, 84, 14);
					Billpanel.add(lblNewLabel_19);
					
					JLabel lblNewLabel_20 = new JLabel("Phone :");
					lblNewLabel_20.setFont(new Font("Tahoma", Font.PLAIN, 13));
					lblNewLabel_20.setBounds(82, 313, 46, 14);
					Billpanel.add(lblNewLabel_20);
					
					JLabel lblNewLabel_21 = new JLabel("Email :");
					lblNewLabel_21.setFont(new Font("Tahoma", Font.PLAIN, 13));
					lblNewLabel_21.setBounds(82, 338, 57, 14);
					Billpanel.add(lblNewLabel_21);
					
					JLabel lblNewLabel_22 = new JLabel("Hall ID :");
					lblNewLabel_22.setFont(new Font("Tahoma", Font.PLAIN, 13));
					lblNewLabel_22.setBounds(525, 216, 69, 14);
					Billpanel.add(lblNewLabel_22);
					
					JLabel lblNewLabel_23 = new JLabel(lblRoomTypeAC.getText());
					lblNewLabel_23.setFont(new Font("Tahoma", Font.PLAIN, 13));
					lblNewLabel_23.setBounds(525, 239, 46, 14);
					Billpanel.add(lblNewLabel_23);
					
					/*JLabel lblAC = new JLabel(lblRoomTypeAC.getText());
					lblAC.setFont(new Font("Tahoma", Font.BOLD, 13));
					lblAC.setBounds(682, 239, 86, 14);
					Billpanel.add(lblAC);
					*/
					
					JLabel lblNewLabel_24 = new JLabel("Room Rate :");
					lblNewLabel_24.setFont(new Font("Tahoma", Font.PLAIN, 13));
					lblNewLabel_24.setBounds(525, 264, 91, 14);
					Billpanel.add(lblNewLabel_24);
					
					JLabel lblPerson = new JLabel("");
					lblPerson.setIcon(new ImageIcon("./images\\persontable4.JPG"));
					lblPerson.setBounds(26, 356, 767, 73);
					Billpanel.add(lblPerson);
					
					
					JLabel lblCustomerID = new JLabel(txtCustID.getText());
					lblCustomerID.setBounds(329, 182, 97, 14);
					Billpanel.add(lblCustomerID);
					
					JLabel lblName = new JLabel(txtCustomerName.getText());
					lblName.setBounds(181, 215, 81, 14);
					Billpanel.add(lblName);
					
					
					lblAddress.setBounds(181, 238, 101, 14);
					Billpanel.add(lblAddress);
					
					lblCity.setBounds(181, 263, 46, 14);
					Billpanel.add(lblCity);
					
					
					lblState.setBounds(233, 263, 63, 14);
					Billpanel.add(lblState);
					
					
					lblPIN.setBounds(290, 263, 84, 14);
					Billpanel.add(lblPIN);
					
					
					lblCountry.setBounds(181, 287, 103, 14);
					Billpanel.add(lblCountry);
					
					
					lblPhone.setBounds(181, 313, 146, 14);
					Billpanel.add(lblPhone);
					
					
					lblEmail.setBounds(181, 338, 200, 14);
					Billpanel.add(lblEmail);
					
					
					JLabel lblRoomID = new JLabel(txtHallNo.getText());
					lblRoomID.setBounds(611, 216, 97, 14);
					Billpanel.add(lblRoomID);
					
					JLabel lblRoom = new JLabel(txtHallType.getText());
					lblRoom.setBounds(611, 239, 97, 14);
					Billpanel.add(lblRoom);
					
					JLabel lblRoomRate = new JLabel(txtHallRate.getText());
					lblRoomRate.setBounds(611, 264, 46, 14);
					Billpanel.add(lblRoomRate);
					
					
					JPanel titlePanel = new JPanel();
					titlePanel.setLayout(null);
					titlePanel.setBounds(26, 370, 767, 35);
					titlePanel.setBackground(Color.DARK_GRAY);
					
					JLabel person = new JLabel("Total Person");
					person.setBounds(100, 0, 100, 40);
					person.setForeground(Color.WHITE);
					
					JLabel checkin = new JLabel("Check-In Date");
					checkin.setBounds(350, 0, 100, 40);
					checkin.setForeground(Color.WHITE);
					
					JLabel checkout = new JLabel("Check-Out Date");
					checkout.setBounds(580, 0, 100, 40);
					checkout.setForeground(Color.WHITE);
					
					
					titlePanel.add(checkin);
					titlePanel.add(checkout);
					titlePanel.add(person);
					Billpanel.add(titlePanel);
					
					
					
					/*JTextField txtTotalPerson = new JTextField("1");
					txtTotalPerson.setBackground(Color.WHITE);
					txtTotalPerson.setForeground(Color.BLACK);
					txtTotalPerson.setBounds(26, 405, 257, 35);
					txtTotalPerson.setHorizontalAlignment(SwingConstants.CENTER);
					txtTotalPerson.setBorder(a);
					txtTotalPerson.setEditable(false);
					Billpanel.add(txtTotalPerson);*/
					JLabel lblTotalPerson = new JLabel();
					lblTotalPerson.setText(lblTotalPers.getText());
					lblTotalPerson.setBackground(Color.WHITE);
					lblTotalPerson.setForeground(Color.BLACK);
					lblTotalPerson.setBounds(26, 405, 257, 35);
					lblTotalPerson.setHorizontalAlignment(SwingConstants.CENTER);
					lblTotalPerson.setBorder(a);
					//lblTotalPerson.setEditable(false);
					Billpanel.add(lblTotalPerson);
					
					
					JTextField txtCheckInBill = new JTextField();
					txtCheckInBill.setText(txtCheckIn.getText());
					txtCheckInBill.setBounds(278, 405, 261, 35);
					txtCheckInBill.setFont(new Font("Tahoma", Font.BOLD, 13));
					txtCheckInBill.setBackground(Color.WHITE);
					txtCheckInBill.setHorizontalAlignment(SwingConstants.CENTER);
					txtCheckInBill.setBorder(a);
					Billpanel.add(txtCheckInBill);
					txtCheckInBill.setColumns(10);
					
					JTextField txtCheckOutBill = new JTextField(txtCheckOut.getText());
					txtCheckOutBill.setBackground(Color.WHITE);
					txtCheckOutBill.setFont(new Font("Tahoma", Font.BOLD, 13));
					txtCheckOutBill.setBounds(535, 405, 258, 35);
					txtCheckOutBill.setHorizontalAlignment(SwingConstants.CENTER);
					txtCheckOutBill.setBorder(a);
					Billpanel.add(txtCheckOutBill);
					
					
					/*JLabel lblDescription = new JLabel("New label");
					lblDescription.setIcon(new ImageIcon("./images\\description4.JPG"));
					lblDescription.setBounds(26, 415, 767, 118);
					Billpanel.add(lblDescription);
					*/
					
					JPanel descriptionPanel = new JPanel();
					descriptionPanel.setLayout(null);
					descriptionPanel.setBounds(26, 455, 767, 34);
					descriptionPanel.setBackground(Color.DARK_GRAY);
					
					
					JLabel slno = new JLabel("Sl. No.");
					slno.setBounds(25, 0, 100, 40);
					slno.setForeground(Color.WHITE);
					
					
					JLabel services = new JLabel("Services");
					services.setBounds(200, 0, 100, 40);
					services.setForeground(Color.WHITE);
					
					JLabel description = new JLabel("Description");
					description.setBounds(410, 0, 100, 40);
					description.setForeground(Color.WHITE);
					
					JLabel amount = new JLabel("Amt.");
					amount.setBounds(550, 0, 100, 40);
					amount.setForeground(Color.WHITE);
					
					JLabel totalAmount = new JLabel("Total Amt.");
					totalAmount.setBounds(660, 0, 100, 40);
					totalAmount.setForeground(Color.WHITE);
					
					
					
					descriptionPanel.add(slno);
					descriptionPanel.add(services);
					descriptionPanel.add(description);
					descriptionPanel.add(amount);
					descriptionPanel.add(totalAmount);
					Billpanel.add(descriptionPanel);
					
					
					JTextField txtS1 = new JTextField("1 .");
					//txtS1.setBounds(26, 487, 108, 35);
					txtS1.setBounds(26, 487, 85, 35);
					txtS1.setBackground(Color.WHITE);
					txtS1.setHorizontalAlignment(SwingConstants.CENTER);
					txtS1.setBorder(a);
					txtS1.setEditable(false);
					Billpanel.add(txtS1);
					
					JTextField txtDisc1 = new JTextField("Stay Charge ");
					//txtDisc1.setBounds(46, 490, 415, 35);
					txtDisc1.setBounds(46, 487, 354, 35);
					txtDisc1.setBackground(Color.WHITE);
					txtDisc1.setHorizontalAlignment(SwingConstants.CENTER);
					txtDisc1.setBorder(a);
					txtDisc1.setEditable(false);
					Billpanel.add(txtDisc1);
					
					JTextField txtCount1 = new JTextField(lblTotalDays.getText()+" Days");
					txtCount1.setBounds(386, 487, 150, 35);
					txtCount1.setBackground(Color.WHITE);
					txtCount1.setHorizontalAlignment(SwingConstants.CENTER);
					txtCount1.setBorder(a);
					txtCount1.setEditable(false);
					Billpanel.add(txtCount1);
					
					JTextField txtPrice1 = new JTextField(txtHallRate.getText()+".0");
					txtPrice1.setBounds(532, 487, 130, 35);
					txtPrice1.setBackground(Color.WHITE);
					txtPrice1.setHorizontalAlignment(SwingConstants.CENTER);
					txtPrice1.setBorder(a);
					txtPrice1.setEditable(false);
					Billpanel.add(txtPrice1);
					
					JTextField txtTotalPrice1 = new JTextField(String.valueOf(hall_price)+".0");
					txtTotalPrice1.setBounds(636, 487, 157, 35);
					txtTotalPrice1.setBackground(Color.WHITE);
					txtTotalPrice1.setHorizontalAlignment(SwingConstants.CENTER);
					txtTotalPrice1.setBorder(a);
					txtTotalPrice1.setEditable(false);
					Billpanel.add(txtTotalPrice1);
					
					JTextField txtS2 = new JTextField("2 .");
					//txtS2.setBounds(26, 500, 108, 35);
					txtS2.setBounds(26, 517, 85, 35);
					txtS2.setHorizontalAlignment(SwingConstants.CENTER);
					txtS2.setBorder(a);
					txtS2.setEditable(false);
					Billpanel.add(txtS2);
					
					//JTextField txtDisc2 = new JTextField("Meal Charge "+ "("+lblMealType.getText()+")");
					JTextField txtDisc2 = new JTextField("Meal Charge "+ "(NONE)");
					txtDisc2.setBounds(46, 517, 354, 35);
					txtDisc2.setHorizontalAlignment(SwingConstants.CENTER);
					txtDisc2.setBorder(a);
					txtDisc2.setEditable(false);
					Billpanel.add(txtDisc2);
					
					//JTextField txtCount2 = new JTextField(String.valueOf(meal_time)+" times x");
					JTextField txtCount2 = new JTextField(" - ");
					txtCount2.setBounds(386, 517, 150, 35);
					txtCount2.setHorizontalAlignment(SwingConstants.CENTER);
					txtCount2.setBorder(a);
					txtCount2.setEditable(false);
					Billpanel.add(txtCount2);
					
					JTextField txtPrice2 = new JTextField(" - ");
					txtPrice2.setBounds(532, 517, 130, 35);
					txtPrice2.setHorizontalAlignment(SwingConstants.CENTER);
					txtPrice2.setBorder(a);
					txtPrice2.setEditable(false);
					Billpanel.add(txtPrice2);
					
					//JTextField txtTotalPrice2 = new JTextField(txtMealCharge.getText()+".0");
					JTextField txtTotalPrice2 = new JTextField(" - ");
					txtTotalPrice2.setBounds(636, 517, 157, 35);
					txtTotalPrice2.setHorizontalAlignment(SwingConstants.CENTER);
					txtTotalPrice2.setBorder(a);
					txtTotalPrice2.setEditable(false);
					Billpanel.add(txtTotalPrice2);
					
					JTextField txtS3 = new JTextField("3 .");
					txtS3.setBounds(26, 547, 85, 35);
					txtS3.setBackground(Color.WHITE);
					txtS3.setHorizontalAlignment(SwingConstants.CENTER);
					txtS3.setBorder(a);
					txtS3.setEditable(false);
					Billpanel.add(txtS3);
					
					JTextField txtDisc3 = new JTextField(" - ");
					txtDisc3.setBounds(46, 547, 354, 35);
					txtDisc3.setBackground(Color.WHITE);
					txtDisc3.setHorizontalAlignment(SwingConstants.CENTER);
					txtDisc3.setBorder(a);
					txtDisc3.setEditable(false);
					Billpanel.add(txtDisc3);
					
					JTextField txtCount3 = new JTextField(" - ");
					txtCount3.setBounds(386, 547, 150, 35);
					txtCount3.setBackground(Color.WHITE);
					txtCount3.setHorizontalAlignment(SwingConstants.CENTER);
					txtCount3.setBorder(a);
					txtCount3.setEditable(false);
					Billpanel.add(txtCount3);
					
					JTextField txtPrice3 = new JTextField(" - ");
					txtPrice3.setBounds(532, 547, 130, 35);
					txtPrice3.setBackground(Color.WHITE);
					txtPrice3.setHorizontalAlignment(SwingConstants.CENTER);
					txtPrice3.setBorder(a);
					txtPrice3.setEditable(false);
					Billpanel.add(txtPrice3);
					
					JTextField txtTotalPrice3 = new JTextField(" - ");
					txtTotalPrice3.setBounds(636, 547, 157, 35);
					txtTotalPrice3.setBackground(Color.WHITE);
					txtTotalPrice3.setHorizontalAlignment(SwingConstants.CENTER);
					txtTotalPrice3.setBorder(a);
					txtTotalPrice3.setEditable(false);
					Billpanel.add(txtTotalPrice3);
					
					
					JLabel NewlblSubtotal = new JLabel("SUBTOTAL");
					NewlblSubtotal.setBounds(532, 575, 130, 35);
					NewlblSubtotal.setHorizontalAlignment(SwingConstants.CENTER);
					Billpanel.add(NewlblSubtotal);
					
					JTextField txtSubTotal = new JTextField(String.valueOf(hall_price)+".0");
					txtSubTotal.setBounds(659, 575, 134, 35);
					txtSubTotal.setHorizontalAlignment(SwingConstants.CENTER);
					txtSubTotal.setBorder(a);
					txtSubTotal.setEditable(false);
					Billpanel.add(txtSubTotal);
					
					
					
					JLabel NewlblTax = new JLabel("Tax 10%");
					NewlblTax.setBounds(532, 603, 130, 35);
					NewlblTax.setHorizontalAlignment(SwingConstants.CENTER);
					Billpanel.add(NewlblTax);
					
					JTextField txtBoxTax = new JTextField(txtTax.getText());
					txtBoxTax.setBounds(659, 603, 134, 35);
					txtBoxTax.setBackground(Color.WHITE);
					txtBoxTax.setHorizontalAlignment(SwingConstants.CENTER);
					txtBoxTax.setBorder(a);
					txtBoxTax.setEditable(false);
					Billpanel.add(txtBoxTax);
					
					JLabel NewlblTotal = new JLabel("TOTAL");
					NewlblTotal.setBounds(532, 631, 130, 35);
					NewlblTotal.setHorizontalAlignment(SwingConstants.CENTER);
					Billpanel.add(NewlblTotal);
					
					JTextField txtBoxTotal = new JTextField(txtTotal.getText());
					txtBoxTotal.setBounds(659, 631, 134, 35);
					txtBoxTotal.setHorizontalAlignment(SwingConstants.CENTER);
					txtBoxTotal.setBorder(a);
					txtBoxTotal.setEditable(false);
					Billpanel.add(txtBoxTotal);
					
					
					JLabel NewlblAdvPaid = new JLabel("ADVANCE PAID");
					NewlblAdvPaid.setBounds(532, 658, 130, 35);
					NewlblAdvPaid.setHorizontalAlignment(SwingConstants.CENTER);
					Billpanel.add(NewlblAdvPaid);
					
					JTextField txtBoxAdvPaid = new JTextField(txtAdvPayment.getText()+".0");
					txtBoxAdvPaid.setBounds(659, 658, 134, 35);
					txtBoxAdvPaid.setBackground(Color.WHITE);
					txtBoxAdvPaid.setHorizontalAlignment(SwingConstants.CENTER);
					txtBoxAdvPaid.setBorder(a);
					txtBoxAdvPaid.setEditable(false);
					Billpanel.add(txtBoxAdvPaid);
					
					JLabel NewlblDue = new JLabel("TOTAL DUE");
					NewlblDue.setBounds(532, 682, 130, 35);
					NewlblDue.setHorizontalAlignment(SwingConstants.CENTER);
					Billpanel.add(NewlblDue);
					
					JTextField txtBoxTotalDue = new JTextField(txtPayable.getText());
					txtBoxTotalDue.setBounds(659, 682, 134, 35);
					txtBoxTotalDue.setHorizontalAlignment(SwingConstants.CENTER);
					txtBoxTotalDue.setBorder(a);
					txtBoxTotalDue.setFont(new Font("Times New Roman", Font.BOLD, 14));
					txtBoxTotalDue.setEditable(false);
					Billpanel.add(txtBoxTotalDue);
					
					
					JLabel NewlblStamp = new JLabel("Stamp/Signature");
					NewlblStamp.setBounds(40, 658, 130, 35);
					NewlblStamp.setHorizontalAlignment(SwingConstants.CENTER);
					Billpanel.add(NewlblStamp);
					
					JFrame billFrame = new JFrame();
					billFrame.setBounds(400, 0, 820, 800);
					billFrame.setVisible(true);
					billFrame.getContentPane().add(Billpanel);
					PrintBill p = new PrintBill();
					p.printReport(billFrame);
					JScrollPane scr = new JScrollPane(billFrame);
				}
			}

		});
		btnNewButton.setBackground(new Color(0, 0, 0));
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setFont(new Font("Traditional Arabic", Font.BOLD, 12));
		btnNewButton.setBounds(334, 13, 207, 39);
		panel.add(btnNewButton);
}
	
	public static String random(int length)
	{
		String alpha = new String("0123456789XYZ");
		int n = alpha.length();
		String result = new String();
		Random r = new Random();
		for(int i=0;i<length;i++)
			result = result+alpha.charAt(r.nextInt(n));
		return result;
	}
	
}
