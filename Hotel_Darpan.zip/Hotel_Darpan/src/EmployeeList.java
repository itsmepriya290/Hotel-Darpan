import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.Dialog.ModalExclusionType;
import java.awt.LayoutManager;
import java.awt.Window.Type;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import org.omg.PortableInterceptor.SUCCESSFUL;

import java.awt.Color;

import javax.swing.ImageIcon;


public class EmployeeList extends JPanel {
	private static final LayoutManager BorderLayout = null;
	private JTable table;
	Connection con;
	ResultSet rs;
	String columnName[];
	String data[][];
	int col=0,row=0;
	private JComboBox cbDeleteEmp = new JComboBox();

	JButton btnDeleteEmp = new JButton("Delete");
	
	/**
	 * Create the panel.
	 */
	public EmployeeList() {
		setLayout(BorderLayout);
		setLayout(new BorderLayout(0, 0));
		
		table = new JTable();
		table.setBackground(Color.LIGHT_GRAY);
		table.setBounds(63, 243, 250, -160);
		add(table);
		
		try{
			con = DBConnection.getConnection();
			Statement stmt = con.createStatement();
			rs = stmt.executeQuery("select e_id,e_name,e_age,e_address,e_salary,e_post from employee");
			ResultSetMetaData rsm = rs.getMetaData();
			col = rsm.getColumnCount();
			columnName = new String[col];
			int id = 1;
			for (int i = 0; i < columnName.length; i++) {
				//columnName[i] = rsm.getColumnName(i+1);	
				//columnName[0] = "<html><b>Serial No.</b></html>";
				columnName[0] = "<html><b>Emp. ID</b></html>";
				columnName[1] = "<html><b>Name</b></html>";
				columnName[2] = "<html><b>Age</b></html>";
				columnName[3] = "<html><b>Address</b></html>";
				columnName[4] = "<html><b>Salary</b></html>";
				columnName[5] = "<html><b>Designation</b></html>";
				
			}
			while (rs.next())row++;
			rs = stmt.executeQuery("select e_id,e_name,e_age,e_address,e_salary,e_post from employee");
			data = new String[row][col];
			for (int i = 0; rs.next(); i++) {
				for (int j = 0; j<col; j++)
				{
					data[i][j] = "<html><span style='text-align:centre;'>"+rs.getString(j+1)+"</span></html>";
					
				}
			}
			table = new JTable(data, columnName);
		}catch(Exception e)
		{	
			JOptionPane.showMessageDialog(null, e.toString());
		}
		
		JPanel deletePanel = new  JPanel();
		
		JLabel lblDeleteEmployee = new JLabel("Delete Employee");
		lblDeleteEmployee.setFont(new Font("Tahoma", Font.BOLD, 12));
		deletePanel.add(lblDeleteEmployee);
		//JComboBox cbDeleteEmp = new JComboBox();
		deletePanel.add(cbDeleteEmp);
		getEmpIdForDelete(cbDeleteEmp);
		btnDeleteEmp.setBackground(Color.BLACK);
		btnDeleteEmp.setForeground(Color.WHITE);
		btnDeleteEmp.setIcon(new ImageIcon("./images\\ic_action_delete.png"));
		deletePanel.add(btnDeleteEmp);
		btnDeleteEmp.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				try {
					String str = null;
					Connection con = DBConnection.getConnection();
					String sql = "delete from employee where e_id = '"+cbDeleteEmp.getSelectedItem()+"'";
					PreparedStatement pstmt = con.prepareStatement(sql);
					pstmt.execute();
					//table.repaint();
					JOptionPane.showMessageDialog(null, "Selected employee has been deleted successfully.");
					table.repaint();
				} 
				
				catch (Exception e2) {
					// TODO: handle exception
					JOptionPane.showMessageDialog(null, e2.toString());
				}
			}
		});
		
		
		add(deletePanel,"South");
		
		JButton btnRefresh = new JButton("Refresh");
		btnRefresh.setForeground(Color.WHITE);
		btnRefresh.setBackground(Color.BLACK);
		deletePanel.add(btnRefresh);
		
		btnRefresh.addActionListener(new ActionListener() {
			
			@Override
			
					public void actionPerformed(ActionEvent arg0) 
					{
						
						
						try{
							Connection con = DBConnection.getConnection();
							Statement stmt = con.createStatement();
							ResultSet rs = stmt.executeQuery("select e_id,e_name,e_age,e_address,e_salary,e_post from employee");
							ResultSetMetaData rsm = rs.getMetaData();
							col = rsm.getColumnCount();
							
							String columnName[] = {"Emp. ID","Name","Age","Address","Salary","Designation"};
							DefaultTableModel tableModel = new DefaultTableModel(columnName,0);
							
							columnName = new String[col];
							int id = 1;
							
							while (rs.next())
							{
								String e_id = rs.getString("e_id");
							    String e_name = rs.getString("e_name");
							    String e_age = rs.getString("e_age");
							    String e_address = rs.getString("e_address");
							    String e_salary = rs.getString("e_salary");
							    String e_post = rs.getString("e_post");
							    String[] data = {e_id,e_name,e_age,e_address,e_salary,e_post} ;
							    tableModel.addRow(data);
						}
							table.setModel(tableModel);
							table.setEnabled(false);
						}catch(Exception exc)
						{	
							JOptionPane.showMessageDialog(null, exc.toString());
						}
					}
				
		});
		
		JScrollPane tableContainer = new JScrollPane(table);
		add(tableContainer);
		setVisible(true);
		
		DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
		centerRenderer.setHorizontalAlignment(JLabel.CENTER);
		for(int c = 0;c<col;c++)
		{
			table.getColumnModel().getColumn(c).setCellRenderer(centerRenderer);
			
		}
		
		
	}

	private void getEmpIdForDelete(JComboBox cbDeleteEmp) {
		// TODO Auto-generated method stub
		try {
			Connection con = DBConnection.getConnection();
			Statement stmt = con.createStatement();
			
			ResultSet rs = stmt.executeQuery("select * from employee");
			cbDeleteEmp.addItem("Please Select Employee ID");
			while(rs.next())
			{
				cbDeleteEmp.addItem(rs.getString(2));
			}
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
		
	}
}
