import java.awt.BorderLayout;
import java.awt.Dialog.ModalExclusionType;
import java.awt.LayoutManager;
import java.awt.Window.Type;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;

import javax.swing.JComboBox;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.ImageIcon;


public class RoomList extends JPanel {
	private static final LayoutManager BorderLayout = null;
	private JTable table;
	Connection con;
	ResultSet rs;
	String columnName[];
	String data[][];
	int col=0,row=0;
	
	private JButton btnDeleteRoom = new JButton("Delete");
	private JComboBox cbDeleteRoom = new JComboBox();

	/**
	 * Create the panel.
	 * @return 
	 */
	
	public Component tableDesign()
	{
		int col=0,row=0;
		Connection con;
		ResultSet rs;
		//Object[] columnNames = {"One","Type", "Company", "Shares", "Price", "Boolean"};
		Object[] columnNames = {"Room No","AC/Non-AC","Room Type","Room Price","Availability"};
		Object[][] data = null;
		try{
			con = (Connection) DBConnection.getConnection();
			Statement stmt = con.createStatement();
			//rs = stmt.executeQuery("select * from room");
			rs = stmt.executeQuery("select r_number,r_ac_nonac,r_type,r_rate,r_status from room");
			ResultSetMetaData rsm = rs.getMetaData();
			col = rsm.getColumnCount();
			while(rs.next())row++;
			rs = stmt.executeQuery("select r_number,r_ac_nonac,r_type,r_rate,r_status from room");
			data = new Object[row][col];
			
			for (int i = 0; rs.next(); i++) {
				for (int j = 0; j<col; j++)
				{
					data[i][j] = rs.getString(j+1);
					
				}
			}
			table = new JTable(data, columnNames);
			
			
		}catch(Exception e)
		{	
			JOptionPane.showMessageDialog(null, e.toString());
			
		}
		
		DefaultTableModel model = new DefaultTableModel(data, columnNames)
		{
			public Class getColumnClass(int column)
			{
				return getValueAt(0, column).getClass();
			}
		};
		JTabbedPane tabbedPane = new JTabbedPane();
		
		tabbedPane.addTab("Data", createData(model));
		return add( tabbedPane );
	}
	
	public RoomList() {
		setLayout(BorderLayout);
		setLayout(new BorderLayout(0, 0));
		
		table = new JTable();
		table.setBackground(Color.LIGHT_GRAY);
		table.setBounds(63, 243, 250, -160);
		add(table);
		JFrame frame = new JFrame("Test");
		frame.getContentPane().add(tableDesign());
		
		
		JPanel p = new  JPanel();
		
		JLabel lblDeleteRoom = new JLabel("Delete Room ");
		lblDeleteRoom.setFont(new Font("Tahoma", Font.BOLD, 12));
		p.add(lblDeleteRoom);
		
		//JComboBox cbDeleteRoom = new JComboBox();
		p.add(cbDeleteRoom);
		getRoomIdForDelete(cbDeleteRoom);
		btnDeleteRoom.setBackground(Color.BLACK);
		btnDeleteRoom.setForeground(Color.WHITE);
		btnDeleteRoom.setIcon(new ImageIcon("D:\\Java Workspace\\Hotel_Darpan\\images\\ic_action_delete.png"));
		btnDeleteRoom.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String str = null;
					Connection con = DBConnection.getConnection();
					String sql = "delete from room where r_number = '"+cbDeleteRoom.getSelectedItem()+"'";
					PreparedStatement pstmt = con.prepareStatement(sql);
					
					//int dialog = JOptionPane.YES_NO_OPTION; 
					int dialog = JOptionPane.showConfirmDialog(null, "Do you want to delete this room ?","Warning", JOptionPane.YES_NO_OPTION);
					if(dialog == JOptionPane.YES_OPTION)
					{
						pstmt.execute();
						JOptionPane.showMessageDialog(null, "Deleted Successfully !", "Success", JOptionPane.INFORMATION_MESSAGE);
						
					}
					else
					{
						JOptionPane.showMessageDialog(null, "Error");
					}
				
				} 
				
				catch (Exception e2) {
					// TODO: handle exception
					JOptionPane.showMessageDialog(null, e2.toString());
				}
			}
		});
		p.add(btnDeleteRoom);
		add(p,"South");
		
		JButton btnRefresh = new JButton("Refresh");
		btnRefresh.setForeground(Color.WHITE);
		btnRefresh.setBackground(Color.BLACK);
		p.add(btnRefresh);
		
		btnRefresh.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				try{
					Connection con = DBConnection.getConnection();
					Statement stmt = con.createStatement();
					ResultSet rs = stmt.executeQuery("select r_number,r_ac_nonac,r_type,r_rate,r_status from room");
					ResultSetMetaData rsm = rs.getMetaData();
					col = rsm.getColumnCount();
					
					//String columnName[] = {"Emp. ID","Name","Age","Address","Salary","Designation"};
					String columnName[] = {"Room No","AC/Non-AC","Room Type","Room Price","Availability"};
					DefaultTableModel tableModel = new DefaultTableModel(columnName,0);
					
					columnName = new String[col];
					int id = 1;
					
					while (rs.next())
					{
						String r_no = rs.getString("r_number");
					    String r_ac = rs.getString("r_ac_nonac");
					    String r_type = rs.getString("r_type");
					    String r_price = rs.getString("r_rate");
					    String r_status = rs.getString("r_status");
					    //String e_post = rs.getString("e_post");
					    String[] data = {r_no,r_ac,r_type,r_price,r_status} ;
					    tableModel.addRow(data);
				}
					table.setModel(tableModel);
					table.setEnabled(false);
				}catch(Exception exc)
				{	
					JOptionPane.showMessageDialog(null, exc.toString());
				}
			}
		});
		
		JScrollPane tableContainer = new JScrollPane(table);
		add(tableContainer);
		
		DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
		centerRenderer.setHorizontalAlignment(JLabel.CENTER);
		for(int c = 0;c<col;c++)
		{
			table.getColumnModel().getColumn(c).setCellRenderer(centerRenderer);
			
		}
	}
	
	private JComponent createData(DefaultTableModel model)
	{
		JTable table = new JTable( model )
		{
			public Component prepareRenderer(TableCellRenderer renderer, int row, int column)
			{
				Component c = super.prepareRenderer(renderer, row, column);

				//  Color row based on a cell value

				if (!isRowSelected(row))
				{
					c.setBackground(getBackground());
					int modelRow = convertRowIndexToModel(row);
					String type = (String)getModel().getValueAt(modelRow, 5);
					if ("Available".equals(type)) c.setBackground(Color.GREEN);
					if ("Booked".equals(type)) c.setBackground(Color.RED);
				}

				return c;
			}
		};

	
		return new JScrollPane( table );
	}

	private void getRoomIdForDelete(JComboBox cbDeleteRoom) {
		// TODO Auto-generated method stub
		try {
			Connection con = DBConnection.getConnection();
			Statement stmt = con.createStatement();
			
			ResultSet rs = stmt.executeQuery("select * from room");
			cbDeleteRoom.addItem("Please Select a Room Number");
			while(rs.next())
			{
				cbDeleteRoom.addItem(rs.getString(2));
			}
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
		
	}
	
	public void getTable()
	{
		try{
			con = DBConnection.getConnection();
			Statement stmt = con.createStatement();
			rs = stmt.executeQuery("select r_number,r_type,r_ac_nonac,r_rate from room");
			ResultSetMetaData rsm = rs.getMetaData();
			col = rsm.getColumnCount();
			columnName = new String[col];
			int id = 1;
			for (int i = 0; i < columnName.length; i++) {
				//columnName[i] = rsm.getColumnName(i+1);	
				//columnName[0] = "<html><b>Serial No.</b></html>";
				columnName[0] = "<html><b>Room Number</b></html>";
				columnName[1] = "<html><b>Room Type</b></html>";
				columnName[2] = "<html><b>AC / Non-AC</b></html>";
				columnName[3] = "<html><b>Room Rate</b></html>";
				//columnName[4] = "Status";
			}
			while (rs.next())row++;
			rs = stmt.executeQuery("select r_number,r_type,r_ac_nonac,r_rate from room");
			data = new String[row][col];
			for (int i = 0; rs.next(); i++) {
				for (int j = 0; j<col; j++)
				{
					data[i][j] = rs.getString(j+1);
					
				}
			}
			table = new JTable(data, columnName);
		}catch(Exception e)
		{	
			
		}
	}
}
