import javax.swing.JPanel;
import javax.swing.JLabel;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Insets;

import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.DefaultComboBoxModel;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableModel;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;



public class AddEmployee extends JPanel {
	private JTextField txtEmpId;
	private JTextArea txtEmpAddress;
	Connection con;
	Statement stmt;
	ResultSet rs;
	private JTextField txtEmpAge;
	private JTextField txtEmpName;
	private JTextField txtEmpSalary;
	private JComboBox cbEmpPost;
	
	

	/**
	 * Create the panel.
	 */
	public AddEmployee() {
		setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Add New Employee");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel.setBounds(28, 26, 154, 29);
		add(lblNewLabel);
		
		JLabel lblRNumber = new JLabel("Emp. ID");
		lblRNumber.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblRNumber.setBounds(29, 64, 93, 29);
		add(lblRNumber);
		
		JLabel lblRType = new JLabel("Emp. Name");
		lblRType.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblRType.setBounds(28, 103, 82, 26);
		add(lblRType);
		
		JLabel lblRRate = new JLabel("Emp. Address");
		lblRRate.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblRRate.setBounds(28, 169, 94, 29);
		add(lblRRate);
		
		txtEmpId = new JTextField();
		txtEmpId.setBounds(137, 66, 123, 27);
		add(txtEmpId);
		txtEmpId.setColumns(10);
		
		txtEmpAddress = new JTextArea();
		txtEmpAddress.setBounds(137, 173, 346, 84);
		add(txtEmpAddress);
		
		
		
		JButton btnSaveEmployee = new JButton("Save");
		btnSaveEmployee.setHorizontalAlignment(SwingConstants.LEFT);
		btnSaveEmployee.setIcon(new ImageIcon("./images\\ic_action_accept.png"));
		btnSaveEmployee.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
					String empId = txtEmpId.getText();
					String empName = txtEmpName.getText();
					String empAge = txtEmpAge.getText();
					String empAddress = txtEmpAddress.getText();
					String empSalary = txtEmpSalary.getText();
					String empPost = (String)cbEmpPost.getSelectedItem();
					
					
				if(empId.trim().equals(""))
				{
					JOptionPane.showMessageDialog(null, "Please Insert Employee ID");
				}
				else{
					try{
						con = DBConnection.getConnection();
						Statement stmt = con.createStatement();
						String sql = "insert into employee (`e_id`,`e_name`,`e_age`,`e_address`,`e_salary`,`e_post`)values('"+empId+"','"+empName+"','"+empAge+"','"+empAddress+"','"+empSalary+"','"+empPost+"')";
						stmt.execute(sql);
						//DefaultTableModel model = (DefaultTableModel)
						JOptionPane.showMessageDialog(null, "Employee record has been added.");
						
						txtEmpId.setText("");
						txtEmpName.setText("");
						txtEmpAge.setText("");
						txtEmpAddress.setText("");
						txtEmpSalary.setText("");
						cbEmpPost.setSelectedItem("Select Designation");
						txtEmpId.requestFocus();
					}
					catch(Exception exc){
						JOptionPane.showMessageDialog(null, exc.toString());
						exc.printStackTrace();
					}
				}
				
				
			}
		});
		btnSaveEmployee.setBackground(Color.BLACK);
		btnSaveEmployee.setForeground(Color.WHITE);
		btnSaveEmployee.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnSaveEmployee.setBounds(138, 278, 102, 35);
		add(btnSaveEmployee);
		
		JLabel lblNewLabel_1 = new JLabel("Emp. Age");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_1.setBounds(28, 135, 82, 23);
		add(lblNewLabel_1);
		
		txtEmpAge = new JTextField();
		txtEmpAge.setBounds(137, 139, 123, 24);
		add(txtEmpAge);
		txtEmpAge.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Salary");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_2.setBounds(269, 108, 69, 20);
		add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Designation");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_3.setBounds(269, 138, 82, 18);
		add(lblNewLabel_3);
		
		txtEmpName = new JTextField();
		txtEmpName.setBounds(137, 106, 123, 26);
		add(txtEmpName);
		txtEmpName.setColumns(10);
		
		txtEmpSalary = new JTextField();
		txtEmpSalary.setBounds(345, 105, 138, 27);
		add(txtEmpSalary);
		txtEmpSalary.setColumns(10);
		
		cbEmpPost = new JComboBox();
		//cbEmpPost.setModel(new DefaultComboBoxModel(new String[] {"Staff", "Receptionist", "Dustcleaner", "Cooker"}));
		cbEmpPost.addItem("Select Designation");
		cbEmpPost.addItem("Staff");
		cbEmpPost.addItem("Receptionist");
		cbEmpPost.addItem("Dustcleaner");
		cbEmpPost.addItem("Cooker");
		cbEmpPost.setBounds(345, 139, 138, 23);
		add(cbEmpPost);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(txtEmpId.getText().trim().equals(""))
				{
					JOptionPane.showMessageDialog(null, "Please Select Emp. ID");
				}
				else{
					try {
						con = DBConnection.getConnection();
						stmt = con.createStatement();
						String updateRoom = "update employee set e_name = '"+txtEmpName.getText()+"',e_age = '"+txtEmpAge.getText()+"',e_address = '"+txtEmpAddress.getText()+"',e_salary = '"+txtEmpSalary.getText()+"',e_post = '"+cbEmpPost.getSelectedItem()+"' where e_id = '"+txtEmpId.getText()+"'";
						PreparedStatement preparedStatement = con.prepareStatement(updateRoom);
						preparedStatement.executeUpdate();
						JOptionPane.showMessageDialog(null, "Employee details has been updated successfully.");
						txtEmpId.setText("");
						txtEmpName.setText("");
						txtEmpAge.setText("");
						txtEmpSalary.setText("");
						txtEmpAddress.setText("");
						cbEmpPost.setSelectedItem("Select Designation");
					} catch (Exception e2) {
						JOptionPane.showMessageDialog(null, e2.toString());
					}
				}
			}
		});
		btnUpdate.setIcon(new ImageIcon("./images\\ic_action_book.png"));
		btnUpdate.setHorizontalAlignment(SwingConstants.LEFT);
		btnUpdate.setForeground(Color.WHITE);
		btnUpdate.setBackground(Color.BLACK);
		btnUpdate.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnUpdate.setBounds(250, 276, 112, 37);
		add(btnUpdate);
		
		JButton btnFindEmployee = new JButton("Find");
		btnFindEmployee.setHorizontalAlignment(SwingConstants.LEFT);
		btnFindEmployee.setIcon(new ImageIcon("D:\\Java Workspace\\Hotel_Darpan\\images\\ic_action_search.png"));
		btnFindEmployee.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					con = DBConnection.getConnection();
					stmt = con.createStatement();
					String sql = "select * from employee where e_id = '"+txtEmpId.getText()+"'";
					rs = stmt.executeQuery(sql);
					if(rs.next())
					{
						txtEmpName.setText(rs.getString("e_name"));
						txtEmpAge.setText(rs.getString("e_age"));
						txtEmpSalary.setText(rs.getString("e_salary"));
						cbEmpPost.setSelectedItem(rs.getString("e_post"));
						txtEmpAddress.setText(rs.getString("e_address"));
					}
					else
					{
						JOptionPane.showMessageDialog(null, "Employee ID doesn't exist !","Error Employee ID",JOptionPane.ERROR_MESSAGE);
						
					}
					
				} catch (Exception e2) {
					JOptionPane.showMessageDialog(null, e2.toString());
				}
			}
		});
		btnFindEmployee.setBackground(Color.BLACK);
		btnFindEmployee.setForeground(Color.WHITE);
		btnFindEmployee.setBounds(294, 66, 93, 29);
		add(btnFindEmployee);
		
		

	}
}
