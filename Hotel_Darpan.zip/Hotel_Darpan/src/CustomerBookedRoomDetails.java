import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.DataLine;
import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.JLabel;
import javax.swing.JSeparator;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Frame;
import java.awt.LayoutManager;

import javax.swing.SwingConstants;

import java.awt.Font;

import javax.swing.JButton;
import javax.swing.ButtonGroup;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.border.TitledBorder;
import javax.swing.event.AncestorEvent;
import javax.swing.event.AncestorListener;

import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.awt.event.FocusListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.time.chrono.JapaneseDate;
import java.util.Calendar;
import java.util.Random;
import java.util.Vector;
import java.util.concurrent.TimeUnit;

import javax.swing.JTable;

import com.toedter.calendar.JCalendar;
import com.toedter.calendar.JDateChooser;
import com.toedter.components.JTitlePanel;

import javax.swing.Icon;
import javax.swing.JComponent;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.AbstractDocument;
import javax.swing.text.Caret;

import com.toedter.calendar.JDateChooserCellEditor;

import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

import javax.swing.ImageIcon;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JToggleButton;


@SuppressWarnings("serial")
public class CustomerBookedRoomDetails extends JPanel {
	JDateChooser dateBookFrom = new JDateChooser();
	JDateChooser dateBookTo = new JDateChooser();
	int monthDay[] = { 31, -1, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
    int ageDays;int ageMonths;int ageYear;
    Calendar fromDate;Calendar toDate;
    int inc;
    int meal;
	
	private JTextField txtTotalDays;
	private JTextField txtFullName;
	private JTextField txtSonDaughter;
	private JTextField txtState;
	private JTextField txtCity;
	private JTextField txtCountry;
	private JTextField txtPIN;
	private JTextField txtMobile;
	private JTextField txtEmail;
	private JTextField txtMealCharge;
	private JTextField txtRoomRate;
	private JTextField txtTax;
	private JTextField txtGrandTotal;
	private JTextField txtAdvance;
	private JTextField txtDue;
	private JTextField txtNoOfPerson;
	private JTextField txtPurposeVisit;
	private JTextField txtTotal;
	private JTextField txtCustomerId;
	private JTextField txtRoomNo;
	JLabel lblNoOfDay = new JLabel("");
	JLabel lblMealCharge = new JLabel("");
	int food_charge;
	
	Connection con;
	ResultSet rs;
	String columnName[];
	String data[][];
	int col=0,row=0;
	int i,j;
	JLabel lblUrl;
	JFrame fr = new JFrame();
	JButton btnSelectR = new JButton("Select Room");
	JFileChooser chooser = new JFileChooser();
	private JTextField txtRoom;
	private JTextField txtRoomType;
	@SuppressWarnings("rawtypes")
	private JComboBox cbMealPlan = new JComboBox();
	
	private JTextArea txtAddress = new JTextArea();
	private JRadioButton RadioCreditCard = new JRadioButton("Credit Card");
	private JRadioButton RadioCash = new JRadioButton("Cash");
	
	/**
	 * Create the panel.
	 */
	@SuppressWarnings("unchecked")
	public CustomerBookedRoomDetails() {
		
		super(true);
		setBackground(Color.LIGHT_GRAY);
		
		dateBookFrom.setDateFormatString("dd-MM-yyyy");
		dateBookTo.setDateFormatString("dd-MM-yyyy");
		dateBookFrom.setDate(Calendar.getInstance().getTime());
		dateBookTo.setDate(Calendar.getInstance().getTime());
		
		/*String columnName[];
		String data[][];
		int col=0,row=0;
		*/
		JLabel lbl = new JLabel();
		add(lbl);
		setLayout(null);
		new JLabel();
		
		JPanel BookingPanel = new JPanel();
		BookingPanel.setBackground(SystemColor.control);
		Border a = BorderFactory.createTitledBorder(null, "<html><font color='blue'><i><u>Your Room Details</u></i></font></html>");
		Border b = BorderFactory.createTitledBorder(null, "<html><font color='blue'><i><u>Customer Details</u></i></font></html>");
		Border c = BorderFactory.createTitledBorder(null, "<html><font color='blue'><i><u>Teriff Calculation</u></i></font></html>");
		Border d = BorderFactory.createTitledBorder(null, "<html><font color='blue'><i><u>Payments</u></i></font></html>");
		Border e = BorderFactory.createTitledBorder(null, "<html><font color='blue'><i><u>Payment Mode</u></i></font></html>");
		BorderFactory.createTitledBorder(null, "<html><font color='blue'><i><u>Additional Note, If any</u></i></font></html>");
		Border g = BorderFactory.createTitledBorder(null, "<html><font color='blue'><i><u>Room Option</u></i></font></html>");
		
	
		
		
		
		
		BookingPanel.setBorder(a);
		BookingPanel.setBounds(0, 72, 361, 390);
		add(BookingPanel);
		BookingPanel.setLayout(null);
		JLabel lblCheckIn = new JLabel("Check In : *");
		lblCheckIn.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblCheckIn.setBounds(26, 54, 85, 14);
		BookingPanel.add(lblCheckIn);
	
		JLabel lblCheckOut = new JLabel("Estd. Check Out : *");
		lblCheckOut.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblCheckOut.setBounds(26, 84, 117, 14);
		BookingPanel.add(lblCheckOut);
		
		JLabel lblTotalDays = new JLabel("Total Days : *");
		lblTotalDays.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblTotalDays.setBounds(25, 113, 85, 14);
		BookingPanel.add(lblTotalDays);
		
		JLabel lblRoom = new JLabel("Room : *");
		lblRoom.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblRoom.setBounds(27, 237, 85, 14);
		BookingPanel.add(lblRoom);
		
		JLabel lblBookingStatus = new JLabel("No. of Person : *");
		lblBookingStatus.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblBookingStatus.setBounds(26, 146, 102, 14);
		BookingPanel.add(lblBookingStatus);
		
		JLabel lblAvailaibility = new JLabel("<html><font color='blue'><i><u>Availability</u></i>____________________________________________</font></html>");
		lblAvailaibility.setBounds(10, 309, 317, 14);
		BookingPanel.add(lblAvailaibility);
		
		JLabel lblNewLabel = new JLabel("You can find booked as well as available rooms from");
		lblNewLabel.setForeground(new Color(128, 0, 0));
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel.setVerticalAlignment(SwingConstants.TOP);
		lblNewLabel.setBounds(9, 330, 354, 14);
		BookingPanel.add(lblNewLabel);
		
		JLabel lblnBetweenThe = new JLabel("the table which is given below.");
		lblnBetweenThe.setForeground(new Color(128, 0, 0));
		lblnBetweenThe.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblnBetweenThe.setBounds(9, 347, 244, 14);
		BookingPanel.add(lblnBetweenThe);
		
		JLabel lblRoomType = new JLabel("Room Type : *");
		lblRoomType.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblRoomType.setBounds(28, 268, 84, 14);
		BookingPanel.add(lblRoomType);
		
		
		txtTotalDays = new JTextField();
		txtTotalDays.setFont(new Font("Tahoma", Font.PLAIN, 12));
		txtTotalDays.setEditable(false);
		txtTotalDays.setBounds(153, 111, 133, 20);
		BookingPanel.add(txtTotalDays);
		txtTotalDays.setColumns(10);
		
		dateBookFrom.setBounds(153, 49, 133, 20);
		BookingPanel.add(dateBookFrom);
		
		dateBookTo.setBounds(153, 78, 133, 20);
		BookingPanel.add(dateBookTo);
		
		dateBookTo.getCalendarButton().addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				dayCount();
			}
		});
		
		JLabel lblMealPlan = new JLabel("Meal Plan : *");
		lblMealPlan.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblMealPlan.setBounds(27, 205, 76, 17);
		BookingPanel.add(lblMealPlan);
		
		
		cbMealPlan.setBounds(153, 204, 134, 20);
		cbMealPlan.addItem("Select Meal Plan");
		cbMealPlan.addItem("NONE");
		cbMealPlan.addItem("Indian");
		cbMealPlan.addItem("Chinease");
		cbMealPlan.addItem("South Indian");
		BookingPanel.add(cbMealPlan);
		
		cbMealPlan.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				if(cbMealPlan.getSelectedItem().equals("NONE"))
					txtMealCharge.setText("0");
				else if(cbMealPlan.getSelectedItem().equals("Indian"))
					txtMealCharge.setText("80");
				else if(cbMealPlan.getSelectedItem().equals("Chinease"))
					txtMealCharge.setText("100");
				else if(cbMealPlan.getSelectedItem().equals("South Indian"))
					txtMealCharge.setText("120");
			}
		});
		
		txtNoOfPerson = new JTextField();
		txtNoOfPerson.setBackground(Color.WHITE);
		txtNoOfPerson.setBounds(154, 144, 133, 20);
		BookingPanel.add(txtNoOfPerson);
		txtNoOfPerson.setColumns(10);
		
		/*txtNoOfPerson.addFocusListener(new FocusListener() {
			
			@Override
			public void focusLost(FocusEvent e) {
				txtNoOfPerson.setBackground(SystemColor.inactiveCaption);
			}
			
			@Override
			public void focusGained(FocusEvent e) {
				txtNoOfPerson.setBackground(SystemColor.inactiveCaptionBorder);
			}
		});
		
		addFocusListener(new FocusListener() {
			
			@Override
			public void focusLost(FocusEvent e) {
				// TODO Auto-generated method stub
				txtNoOfPerson.setBackground(SystemColor.inactiveCaption);
				txtPurposeVisit.setBackground(SystemColor.inactiveCaption);
				txtCountry.setBackground(SystemColor.inactiveCaption);
			}
			
			@Override
			public void focusGained(FocusEvent e) {
				// TODO Auto-generated method stub
				txtNoOfPerson.setBackground(SystemColor.inactiveCaptionBorder);
				txtPurposeVisit.setBackground(SystemColor.inactiveCaptionBorder);
		c		txtCountry.setBackground(SystemColor.inactiveCaptionBorder);
			}
		});*/
		
		//MyTextField;
		
		
		JLabel lblPurposeOfVisit = new JLabel("Purpose of Visit : *");
		lblPurposeOfVisit.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblPurposeOfVisit.setBounds(27, 178, 116, 14);
		BookingPanel.add(lblPurposeOfVisit);
		
		txtPurposeVisit = new JTextField();
		txtPurposeVisit.setBounds(154, 175, 133, 20);
		BookingPanel.add(txtPurposeVisit);
		txtPurposeVisit.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Room No. :");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_3.setBounds(26, 23, 77, 14);
		BookingPanel.add(lblNewLabel_3);
		
		txtRoomNo = new JTextField();
		txtRoomNo.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtRoomNo.setEditable(false);
		txtRoomNo.setBounds(154, 19, 67, 20);
		BookingPanel.add(txtRoomNo);
		txtRoomNo.setColumns(10);
		txtRoomNo.setDisabledTextColor(Color.BLACK);
		
		
		/*JButton btnSelectRoom = new JButton("Add Room");
		btnSelectRoom.setHorizontalAlignment(SwingConstants.LEFT);
		btnSelectRoom.setIcon(new ImageIcon("./images\\ic_action_new.png"));
		btnSelectRoom.setBackground(Color.BLACK);
		btnSelectRoom.setForeground(Color.WHITE);
		
		btnSelectRoom.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				LayoutManager BorderLayout = null;
				
				fr.setTitle("Select Room");
				fr.setBounds(500, 220, 480, 300);
				//fr.getContentPane().setLayout(BorderLayout);
				fr.getContentPane().setLayout(new BorderLayout(0, 0));
				table = new JTable();
				table.setBackground(Color.LIGHT_GRAY);
				
				
				fr.getContentPane().add(table);  
				
				try{
					con = DBConnection.getConnection();
					Statement stmt = con.createStatement();
					rs = stmt.executeQuery("select r_number,r_ac_nonac,r_type,r_rate,r_status from room");
					ResultSetMetaData rsm = rs.getMetaData();
					col = rsm.getColumnCount();
					columnName = new String[col];
					//for (i = 0; i < columnName.length; i++) {
						//columnName[i] = rsm.getColumnName(i+1);	
						columnName[0] = "<html><b>Room No.</b></html>";
						columnName[1] = "<html><b>AC or Non-AC</b></html>";
						columnName[2] = "<html><b>Room Type</b></html>";
						columnName[3] = "<html><b>Room Rate</b></html>";
						columnName[4] = "<html><b>Status</b></html>";
					
					//}
					while (rs.next())row++;
					rs = stmt.executeQuery("select r_number,r_ac_nonac,r_type,r_rate,r_status from room");
					data = new String[row][col];
					for (i = 0; rs.next(); i++) {
						for (j = 0; j<col; j++)
						{
							data[i][j] = rs.getString(j+1);
						}
					}
					table = new JTable(data, columnName);
				}catch(Exception exc)
				{	
					JOptionPane.showMessageDialog(null, exc.toString());
				}
				JPanel p = new  JPanel();
				p.setBackground(Color.ORANGE);
				p.add(btnSelectR);
				fr.getContentPane().add(p,"South");
				JScrollPane tableContainer = new JScrollPane(table);
				fr.getContentPane().add(tableContainer);
				fr.setVisible(true);
				fr.setResizable(false);
				DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
				centerRenderer.setHorizontalAlignment(JLabel.CENTER);
				for(int c = 0;c<col;c++)
				{
					table.getColumnModel().getColumn(c).setCellRenderer(centerRenderer);
					
				}
				
			}
			
			
		});
		
		btnSelectR.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				try{
					int row = table.getSelectedRow();
					int column = table.getColumnCount();
					for(int i = 0;i<4;i++)
					{
						//Object dt = table.getValueAt(row, i);
						txtRoomNo.setText((String) table.getValueAt(row, 0));
						txtRoom.setText((String) table.getValueAt(row, 1));
						txtRoomType.setText((String) table.getValueAt(row, 2));
						txtRoomRate.setText((String) table.getValueAt(row, 3));
					}
				}
				catch(Exception ex){
					JOptionPane.showMessageDialog(null, ex.toString());
				}
				fr.dispose();
			}
		});
		
		
		btnSelectRoom.setBounds(227, 11, 136, 30);
		BookingPanel.add(btnSelectRoom);
		
		JButton btnCountDay = new JButton("");
		btnCountDay.setIcon(new ImageIcon("./images\\ic_action_accept.png"));
		btnCountDay.setBackground(Color.BLACK);
		btnCountDay.setForeground(Color.WHITE);
		btnCountDay.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dayCount();
			}
		});
		btnCountDay.setBounds(291, 79, 52, 23);
		BookingPanel.add(btnCountDay);
		*/
		txtRoom = new JTextField();
		txtRoom.setEditable(false);
		txtRoom.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtRoom.setBounds(154, 234, 133, 20);
		BookingPanel.add(txtRoom);
		txtRoom.setDisabledTextColor(Color.BLACK);
		txtRoom.setColumns(10);
		
		txtRoomType = new JTextField();
		txtRoomType.setEditable(false);
		txtRoomType.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtRoomType.setBounds(154, 265, 133, 20);
		BookingPanel.add(txtRoomType);
		txtRoomType.setDisabledTextColor(Color.BLACK);
		txtRoomType.setColumns(10);
		
		
		try {
			Connection con = DBConnection.getConnection();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from roombookingdetails where  c_id = 'CZ82'");
			//ResultSet rs_hall = stmt.executeQuery("select * from func_booking where h_no = "+rNumber+"");
			
				if(rs.next())
				{
					txtRoomNo.setText(rs.getString("c_id"));
					/*lblCustomerName.setText(rs.getString("c_fullname"));
					lblRType.setText(rs.getString("r_type"));
					lblRmNo.setText(rs.getString("r_no"));
					lblACNON.setText(rs.getString("room"));
					lblRoomRate.setText("Rs. "+rs.getString("r_rate"));
					lblCheckIn.setText(rs.getString("check_in"));
					lblCheckOut.setText(rs.getString("check_out"));
					lblNoOfDays.setText(rs.getString("total_day"));
					lblNoOfPerson.setText(rs.getString("no_of_person"));
					lblPurposeOfVisit.setText(rs.getString("purpose_visit"));
					lblMeal.setText(rs.getString("meal_plan"));
					lblTotal.setText("Rs. "+rs.getString("grand_total"));
					lblAdvPay.setText("Rs. "+rs.getString("advance"));
					
					lblDues.setText("Rs. "+rs.getString("due"));
					lblIdentity.setIcon(new ImageIcon(rs.getBytes("identity_image")));*/
				}
				else
				{
					JOptionPane.showMessageDialog(null, "Room has not been booked yet");
				}
				
				
			} catch (Exception ex) {
				JOptionPane.showMessageDialog(null, e.toString());
			}
		
		
		
		
		JPanel CustomerPanel = new JPanel();
		CustomerPanel.setBackground(SystemColor.control);
		CustomerPanel.setBorder(b);
		CustomerPanel.setBounds(374, 72, 358, 390);
		add(CustomerPanel);
		CustomerPanel.setLayout(null);
		
		JLabel lblFirstName = new JLabel("Full Name :*");
		lblFirstName.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblFirstName.setBounds(14, 80, 83, 14);
		CustomerPanel.add(lblFirstName);
		
		JLabel lblLastName = new JLabel("Son/Daughter of :*");
		lblLastName.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblLastName.setBounds(14, 112, 107, 14);
		CustomerPanel.add(lblLastName);
		
		JLabel lblAddress = new JLabel("Address :*");
		lblAddress.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblAddress.setBounds(14, 169, 83, 14);
		CustomerPanel.add(lblAddress);
		
		txtFullName = new JTextField();
		txtFullName.setBounds(123, 78, 216, 20);
		CustomerPanel.add(txtFullName);
		txtFullName.setColumns(10);
		
		txtSonDaughter = new JTextField();
		txtSonDaughter.setBounds(123, 110, 216, 20);
		CustomerPanel.add(txtSonDaughter);
		txtSonDaughter.setColumns(10);
		
		
		txtAddress.setBounds(125, 144, 214, 50);
		CustomerPanel.add(txtAddress);
		
		JLabel lblCity = new JLabel("State : *");
		lblCity.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblCity.setBounds(14, 210, 61, 14);
		CustomerPanel.add(lblCity);
		
		txtState = new JTextField();
		txtState.setBounds(125, 206, 86, 20);
		CustomerPanel.add(txtState);
		txtState.setColumns(10);
		
		JLabel lblCity_1 = new JLabel("City :*");
		lblCity_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblCity_1.setBounds(216, 208, 41, 14);
		CustomerPanel.add(lblCity_1);
		
		txtCity = new JTextField();
		txtCity.setBounds(257, 205, 86, 20);
		CustomerPanel.add(txtCity);
		txtCity.setColumns(10);
		
		JLabel lblCountry = new JLabel("Country :*");
		lblCountry.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblCountry.setBounds(14, 241, 61, 14);
		CustomerPanel.add(lblCountry);
		
		txtCountry = new JTextField();
		txtCountry.setBounds(126, 239, 86, 20);
		CustomerPanel.add(txtCountry);
		txtCountry.setColumns(10);
		
		JLabel lblPin = new JLabel("PIN :*");
		lblPin.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblPin.setBounds(217, 240, 34, 14);
		CustomerPanel.add(lblPin);
		
		txtPIN = new JTextField();
		txtPIN.setBounds(255, 239, 86, 20);
		CustomerPanel.add(txtPIN);
		txtPIN.setColumns(10);
		
		JLabel lblMobileNumber = new JLabel("Mobile No :*");
		lblMobileNumber.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblMobileNumber.setBounds(14, 277, 72, 14);
		CustomerPanel.add(lblMobileNumber);
		
		txtMobile = new JTextField();
		txtMobile.setBounds(126, 275, 217, 20);
		CustomerPanel.add(txtMobile);
		txtMobile.setColumns(10);
		
		JLabel lblEmailAddress = new JLabel("Email ID :");
		lblEmailAddress.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblEmailAddress.setBounds(14, 306, 61, 14);
		CustomerPanel.add(lblEmailAddress);
		
		txtEmail = new JTextField();
		txtEmail.setBounds(126, 304, 217, 20);
		CustomerPanel.add(txtEmail);
		txtEmail.setColumns(10);
		
		JLabel lblRequiredFields = new JLabel("* required fields (cannot be left blank)");
		lblRequiredFields.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblRequiredFields.setForeground(new Color(128, 0, 0));
		lblRequiredFields.setBounds(61, 17, 222, 14);
			CustomerPanel.add(lblRequiredFields);
			
			JLabel lblIdentityType = new JLabel("Identity Type :*");
		lblIdentityType.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblIdentityType.setBounds(14, 346, 90, 14);
		CustomerPanel.add(lblIdentityType);
		
		lblUrl = new JLabel("");
		lblUrl.setBounds(19, 371, 320, 14);
		CustomerPanel.add(lblUrl);
		
		JButton btnBrowse = new JButton("Browse");
		btnBrowse.setBackground(Color.BLACK);
		btnBrowse.setForeground(Color.WHITE);
		btnBrowse.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnBrowse.setHorizontalAlignment(SwingConstants.LEFT);
		btnBrowse.setIcon(new ImageIcon("./images\\ic_action_picture.png"));
		btnBrowse.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try{
					
					chooser.setMultiSelectionEnabled(false);
					chooser.setVisible(true);
					chooser.getSelectedFile();
					chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
					chooser.setAcceptAllFileFilterUsed(false);
					int rVal = chooser.showOpenDialog(null);
					if(rVal == JFileChooser.APPROVE_OPTION)
					{
						lblUrl.setText(chooser.getSelectedFile().toString());
					}
				}
				catch(Exception ex){
					JOptionPane.showMessageDialog(null, ex.toString());
				}
			
			}
		});
		btnBrowse.setBounds(126, 336, 131, 31);
		CustomerPanel.add(btnBrowse);
		
		JLabel lblNewLabel_2 = new JLabel("Customer Id : *");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_2.setBounds(10, 43, 104, 24);
		CustomerPanel.add(lblNewLabel_2);
		
		txtCustomerId = new JTextField();
		txtCustomerId.setForeground(new Color(128, 0, 0));
		txtCustomerId.setFont(new Font("Tahoma", Font.BOLD, 14));
		txtCustomerId.setEditable(false);
		txtCustomerId.setBounds(123, 45, 216, 20);
		CustomerPanel.add(txtCustomerId);
		txtCustomerId.setColumns(10);
		
		txtCustomerId.setText("C"+random(3));
		
		
		
		JPanel CalculationPanel = new JPanel();
		CalculationPanel.setBackground(SystemColor.control);
		CalculationPanel.setBounds(734, 72, 275, 211);
		CalculationPanel.setBorder(c);
		add(CalculationPanel);
		CalculationPanel.setLayout(null);
		
		JLabel labelDay = new JLabel("Meal Charge:");
		labelDay.setFont(new Font("Tahoma", Font.BOLD, 11));
		labelDay.setBounds(10, 27, 88, 14);
		CalculationPanel.add(labelDay);
		
		JLabel lblNewLabel_1 = new JLabel("Room Rate :");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_1.setBounds(10, 64, 71, 14);
		CalculationPanel.add(lblNewLabel_1);
		
		JLabel lblTax = new JLabel("Tax :");
		lblTax.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblTax.setBounds(10, 126, 46, 14);
		CalculationPanel.add(lblTax);
		
		JLabel lblGrandTotal = new JLabel("Grand Total :");
		lblGrandTotal.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblGrandTotal.setBounds(10, 158, 88, 14);
		CalculationPanel.add(lblGrandTotal);
		
		txtMealCharge = new JTextField();
		txtMealCharge.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtMealCharge.setEditable(false);
		txtMealCharge.setBounds(102, 25, 72, 20);
		CalculationPanel.add(txtMealCharge);
		txtMealCharge.setColumns(10);
		
		txtRoomRate = new JTextField();
		txtRoomRate.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtRoomRate.setEditable(false);
		txtRoomRate.setBounds(103, 62, 71, 20);
		CalculationPanel.add(txtRoomRate);
		txtRoomRate.setColumns(10);
		
		txtTax = new JTextField();
		txtTax.setEditable(false);
		txtTax.setHorizontalAlignment(SwingConstants.CENTER);
		txtTax.setFont(new Font("Tahoma", Font.BOLD, 13));
		txtTax.setBounds(102, 124, 71, 20);
		CalculationPanel.add(txtTax);
		txtTax.setColumns(10);
		txtTax.setDisabledTextColor(Color.BLACK);
		
		JLabel lblTax_1 = new JLabel("10% Tax");
		lblTax_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblTax_1.setBounds(182, 128, 58, 14);
		CalculationPanel.add(lblTax_1);
		
		txtGrandTotal = new JTextField();
		txtGrandTotal.setEditable(false);
		
		txtGrandTotal.setHorizontalAlignment(SwingConstants.CENTER);
		txtGrandTotal.setForeground(Color.BLACK);
		txtGrandTotal.setFont(new Font("Tahoma", Font.BOLD, 14));
		txtGrandTotal.setBounds(102, 154, 150, 38);
		CalculationPanel.add(txtGrandTotal);
		txtGrandTotal.setColumns(10);
		txtGrandTotal.setDisabledTextColor(Color.BLACK);
		
		JLabel lblTotal = new JLabel("Total :");
		lblTotal.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblTotal.setBounds(10, 99, 58, 14);
		CalculationPanel.add(lblTotal);
		
		txtTotal = new JTextField();
		txtTotal.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtTotal.setEditable(false);
		txtTotal.setBounds(102, 96, 150, 20);
		CalculationPanel.add(txtTotal);
		txtTotal.setColumns(10);
		
		
		lblNoOfDay.setBounds(183, 64, 68, 14);
		CalculationPanel.add(lblNoOfDay);
		
		
		lblMealCharge.setBounds(184, 27, 71, 14);
		CalculationPanel.add(lblMealCharge);
		
		JPanel PaymentsPanel = new JPanel();
		PaymentsPanel.setBackground(SystemColor.control);
		PaymentsPanel.setBorder(d);
		PaymentsPanel.setForeground(new Color(0, 0, 0));
		PaymentsPanel.setBounds(734, 284, 275, 178);
		add(PaymentsPanel);
		PaymentsPanel.setLayout(null);
		
		JLabel lblAdvance = new JLabel("Advance : *");
		lblAdvance.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblAdvance.setBounds(10, 31, 81, 14);
		PaymentsPanel.add(lblAdvance);
		
		JLabel lblDue = new JLabel("Due :");
		lblDue.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblDue.setBounds(10, 67, 53, 14);
		PaymentsPanel.add(lblDue);
		
		txtAdvance = new JTextField();
		txtAdvance.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtAdvance.setBounds(104, 28, 148, 20);
		PaymentsPanel.add(txtAdvance);
		txtAdvance.setColumns(10);
		
		txtDue = new JTextField();
		txtDue.setEditable(false);
		txtDue.setHorizontalAlignment(SwingConstants.CENTER);
		txtDue.setFont(new Font("Tahoma", Font.BOLD, 13));
		txtDue.setBounds(104, 59, 148, 33);
		txtDue.setDisabledTextColor(Color.BLACK);
		PaymentsPanel.add(txtDue);
		txtDue.setColumns(10);
		
		
		JButton btnCalculate = new JButton("Calculate");
		btnCalculate.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnCalculate.setHorizontalAlignment(SwingConstants.LEFT);
		btnCalculate.setIcon(new ImageIcon("./images\\ic_action_add_to_queue.png"));
		btnCalculate.setEnabled(true);
		
		btnCalculate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					if(txtAdvance.getText().trim().length()==0)
					{
						JOptionPane.showMessageDialog(null, "Advance Payment Must !");
						txtAdvance.requestFocus();
					}
					else
					{
						txtDue.getText();
						//int d = Integer.parseInt(txtMealCharge.getText());
						int d = Integer.parseInt(txtTotalDays.getText());
						double r = Integer.parseInt(txtRoomRate.getText());
						int meal_time = d*2;
						food_charge = meal_time * Integer.parseInt(txtMealCharge.getText());
						double ad = Integer.parseInt(txtAdvance.getText());
						double tt = d * r + food_charge;
						double total=tt;
						double tax = total/10;
						
						txtTax.setText(""+tax);
						txtGrandTotal.setText(""+(tt+tax));
						txtDue.setText(""+((tt+tax)-ad));
						txtTotal.setText(""+total);
						
					}
				} catch (Exception e2) {
					JOptionPane.showMessageDialog(null, e2.toString());
				}
				
					
			}
		});
		btnCalculate.setForeground(Color.WHITE);
		btnCalculate.setBackground(Color.BLACK);
		btnCalculate.setBounds(20, 136, 125, 34);
		PaymentsPanel.add(btnCalculate);
		
	
		ButtonGroup pay = new ButtonGroup();
		
		RadioCash.setFont(new Font("Tahoma", Font.PLAIN, 11));
		RadioCash.setBounds(118, 101, 53, 23);
		PaymentsPanel.add(RadioCash);
		
		
		RadioCreditCard.setFont(new Font("Tahoma", Font.PLAIN, 11));
		RadioCreditCard.setBounds(171, 101, 81, 23);
		PaymentsPanel.add(RadioCreditCard);
		pay.add(RadioCash);
		pay.add(RadioCreditCard);
	
		JPanel RoomOptionPanel = new JPanel();
		RoomOptionPanel.setBorder(g);
		RoomOptionPanel.setBackground(SystemColor.control);
		RoomOptionPanel.setBounds(0, 462, 1009, 142);
		add(RoomOptionPanel);
		RoomOptionPanel.setLayout(new BorderLayout(0, 0));
		
		JTable table = new JTable();
		table.setBackground(Color.LIGHT_GRAY);
		table.setBounds(63, 243, 250, -160);
		RoomOptionPanel.add(table);
		try{
			Connection con = DBConnection.getConnection();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select r_number,r_ac_nonac,r_type,r_rate,r_status from room");
			ResultSetMetaData rsm = rs.getMetaData();
			col = rsm.getColumnCount();
			columnName = new String[col];
			for (int i = 0; i < columnName.length; i++) {
				columnName[i] = rsm.getColumnName(i+1);	
				//columnName[0] = "<html><b>Serial No.</b></html>";
				columnName[0] = "<html><b>Room Number</b></html>";
				columnName[1] = "<html><b>AC or Non-AC</b></html>";
				columnName[2] = "<html><b>Room Type</b></html>";
				columnName[3] = "<html><b>Room Rate</b></html>";
				columnName[4] = "<html><b>Status</b></html>";
			}
			while (rs.next())row++;
			rs = stmt.executeQuery("select r_number,r_ac_nonac,r_type,r_rate,r_status from room");
			data = new String[row][col];
			for (int i = 0; rs.next(); i++) {
				for (int j = 0; j<col; j++)
				{
					new DefaultTableCellRenderer();
					String st = rs.getString(5);
					if(st.equals("Booked")){
						data[i][j] = "<html><div style='background-color:red; color:white; width:150px; text-align:center;'><b>"+rs.getString(j+1)+"</div></b></html>";
					}
					else{
						data[i][j] = "<html><div style='background-color:green; width:150px; color:white; text-align:center;'><b>"+rs.getString(j+1)+"</div></b></html>";
					}
										
				}
			}
			table = new JTable(data, columnName);
		}catch(Exception exc)
		{	
			JOptionPane.showMessageDialog(null, exc.toString());
		}
		JScrollPane tableContainer = new JScrollPane(table);
		RoomOptionPanel.add(tableContainer);
		setVisible(true);
		DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
		centerRenderer.setHorizontalAlignment(JLabel.CENTER);
		for(int m = 0;m<col;m++)
		{
			table.getColumnModel().getColumn(m).setCellRenderer(centerRenderer);
			
		}
		
		
		
		
		JButton btnBook = new JButton("Book");
		btnBook.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnBook.setHorizontalAlignment(SwingConstants.LEFT);
		btnBook.setIcon(new ImageIcon("./images\\ic_action_book.png"));
		btnBook.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(txtRoomNo.getText().trim().length()==0)
				{
					JOptionPane.showMessageDialog(null, "Please Enter Room Number","Invalid Room Number",JOptionPane.ERROR_MESSAGE);
				}
				
				else if(txtTotalDays.getText().trim().length()==0)
				{
					JOptionPane.showMessageDialog(null, "Please Enter Total Days","Invalid Days Count",JOptionPane.ERROR_MESSAGE);
					txtTotalDays.requestFocus();	
				}
				
				else if(txtNoOfPerson.getText().trim().length()==0)
				{
					JOptionPane.showMessageDialog(null, "Please Enter No. Of Person","Invalid Person Count",JOptionPane.ERROR_MESSAGE);
					txtNoOfPerson.requestFocus();
					
				}
				else if(txtPurposeVisit.getText().trim().length()==0)
				{
					JOptionPane.showMessageDialog(null, "Please Enter Purpose Of Visit","Invalid Visiting Detail",JOptionPane.ERROR_MESSAGE);
					txtPurposeVisit.requestFocus();
				}
				else if(cbMealPlan.getSelectedItem().equals("Select Meal Plan"))
				{
					JOptionPane.showMessageDialog(null, "Please Select Meal Plan","Invalid Meal Plan",JOptionPane.ERROR_MESSAGE);
					cbMealPlan.requestFocus();
				}
				else if(txtRoom.getText().equals("Select AC or Non-AC"))
				{
					JOptionPane.showMessageDialog(null, "Please Select Room","Invalid Room",JOptionPane.ERROR_MESSAGE);
					txtRoom.requestFocus();
				}
				else if(txtRoomType.getText().equals("Select Room Type"))
				{
					JOptionPane.showMessageDialog(null, "Please Select Room Type","Invalid Room Type",JOptionPane.ERROR_MESSAGE);
					txtRoomType.requestFocus();
				}
				else if(txtCustomerId.getText().trim().length()==0)
				{
					JOptionPane.showMessageDialog(null, "Please Enter Customer-ID","Invalid Customer ID",JOptionPane.ERROR_MESSAGE);
					txtCustomerId.requestFocus();
				}
				else if(txtFullName.getText().trim().length()==0)
				{
					JOptionPane.showMessageDialog(null, "Please Enter Customer Fullname","Invalid Customer Name",JOptionPane.ERROR_MESSAGE);
					txtFullName.requestFocus();
				}
				else if(txtSonDaughter.getText().trim().length()==0)
				{
					JOptionPane.showMessageDialog(null, "Please Enter Son/Daughter Of","Invalid",JOptionPane.ERROR_MESSAGE);
					txtSonDaughter.requestFocus();
				}
				else if(txtAddress.getText().trim().length()==0)
				{
					JOptionPane.showMessageDialog(null, "Please Enter Customer Address","Invalid Address",JOptionPane.ERROR_MESSAGE);
					txtAddress.requestFocus();
				}
				else if(txtState.getText().trim().length()==0)
				{
					JOptionPane.showMessageDialog(null, "Please Enter Customer State","Invalid State",JOptionPane.ERROR_MESSAGE);
					txtState.requestFocus();
				}
				else if(txtCity.getText().trim().length()==0)
				{
					JOptionPane.showMessageDialog(null, "Please Enter Customer City","Invalid City",JOptionPane.ERROR_MESSAGE);
					txtCity.requestFocus();
				}
				else if(txtCountry.getText().trim().length()==0)
				{
					JOptionPane.showMessageDialog(null, "Please Enter Customer Country","Invalid Country",JOptionPane.ERROR_MESSAGE);
					txtCountry.requestFocus();
				}
				
				else if(txtPIN.getText().trim().length()==0)
				{
					JOptionPane.showMessageDialog(null, "Please Enter PIN Number","Invalid PIN",JOptionPane.ERROR_MESSAGE);
					txtPIN.requestFocus();
				}
				else if(txtMobile.getText().trim().length()==0)
				{
					JOptionPane.showMessageDialog(null, "Please Enter Customer Mobile No.","Invalid Mobile Number", JOptionPane.ERROR_MESSAGE);
					txtMobile.requestFocus();
				}
				
				
				else
				{
					try {
						String payment = null;
						if(RadioCash.isSelected())
							payment = "Cash";
						else if(RadioCreditCard.isSelected())
							payment = "Credit Card";
						else if(payment == null)
							JOptionPane.showMessageDialog(null, "Please Select Payment Option");
						
						Connection con=DBConnection.getConnection();
						java.sql.Statement stmt = con.createStatement();
						
						BookYourRoom();
						dayCount();
						
					} catch (Exception exc) {
						// TODO: handle exception
						JOptionPane.showMessageDialog(null, exc.toString());
					}
					
				}
			}

			private void BookYourRoom() {
				
				try {
					String payment = null;
					if(RadioCash.isSelected())
						payment = "Cash";
					else if(RadioCreditCard.isSelected())
						payment = "Credit Card";
					
					//int food = Integer.parseInt(txtMealCharge.getText());
					//int food_charge = food*meal;
					
					java.util.Date frDate = dateBookFrom.getDate();
					java.util.Date toDate = dateBookTo.getDate();
					
					con = DBConnection.getConnection();
					Statement stmt = con.createStatement();
					File file = chooser.getSelectedFile();
					FileInputStream fin = new FileInputStream(file);
					//PreparedStatement pre = con.prepareStatement("insert into image(id,image) value(?,?)");
					//('"+txtDue.getText()+"','"+payment+"')");
					PreparedStatement pre = con.prepareStatement("insert into roombookingdetails (`r_no`,`c_id`,`check_in`,`check_out`,`total_day`,`no_of_person`,`purpose_visit`,`meal_plan`,`meal_charge`,`room`,`r_type`,`c_fullname`,`c_son_of`,`c_address`,`c_state`,`c_city`,`c_country`,`c_pin`,`c_mobile`,`c_email`,`r_rate`,`total`,`tax`,`grand_total`,`advance`,`due`,`payment_mode`,`identity_image`)values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
					
					pre.setString(1, txtRoomNo.getText());
					pre.setString(2, txtCustomerId.getText());
					pre.setString(3, frDate.toString());
					pre.setString(4, toDate.toString());
					pre.setString(5, txtTotalDays.getText());
					pre.setString(6, txtNoOfPerson.getText());
					pre.setString(7, txtPurposeVisit.getText());
					pre.setString(8, (String) cbMealPlan.getSelectedItem());
					//pre.setString(9, txtMealCharge.getText());
					pre.setLong(9, food_charge);
					pre.setString(10, (String) txtRoom.getText());
					pre.setString(11, (String) txtRoomType.getText());
					pre.setString(12, txtFullName.getText());
					pre.setString(13, txtSonDaughter.getText());
					pre.setString(14, txtAddress.getText());
					pre.setString(15, txtState.getText());
					pre.setString(16, txtCity.getText());
					pre.setString(17, txtCountry.getText());
					pre.setString(18, txtPIN.getText());
					pre.setString(19, txtMobile.getText());
					pre.setString(20, txtEmail.getText());
					pre.setString(21, txtRoomRate.getText());
					pre.setString(22, txtTotal.getText());
					pre.setString(23, txtTax.getText());
					pre.setString(24, txtGrandTotal.getText());
					pre.setString(25, txtAdvance.getText());
					pre.setString(26, txtDue.getText());
					pre.setString(27, payment);
					pre.setBinaryStream(28, (InputStream)fin,(int)file.length());
					
					String updateQuery = "update room set r_status = 'Booked' where r_number = '"+txtRoomNo.getText()+"'";
					PreparedStatement preparedStatement = con.prepareStatement(updateQuery);
					preparedStatement.executeUpdate();
					
					if(check()==true && roomCheck()==true)
					{
						pre.executeUpdate();
						JOptionPane.showMessageDialog(null, "Your room has been booked!","Room Booking",JOptionPane.INFORMATION_MESSAGE);
					}
					else if(roomCheck() == false)
					{
						JOptionPane.showMessageDialog(null, "Room has already been booked");
					}
					else if(check()==false)
					{
						JOptionPane.showMessageDialog(null, "Please Select an Image File for Identity");
					}
					else
					{
						JOptionPane.showMessageDialog(null, "Booking Failed");
					}
					
					pre.close();
					con.close();
					
				}
				catch(Exception xc)
				{
					JOptionPane.showMessageDialog(null, xc.toString());
				}
				
			}
		});
		btnBook.setEnabled(true);
		btnBook.setForeground(Color.WHITE);
		//btnBook.setBackground(Color.LIGHT_GRAY);
		btnBook.setBackground(Color.BLACK);
		btnBook.setBounds(158, 136, 101, 34);
		PaymentsPanel.add(btnBook);
		
		JLabel lblNewLabel_4 = new JLabel("Payment Mode :*");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_4.setBounds(10, 102, 108, 14);
		PaymentsPanel.add(lblNewLabel_4);
		
	
	
	}
	
	
	private boolean check()
	{	
		String path = lblUrl.getText().toString();
		if(path!=null)
		{
			if(path.endsWith(".jpeg")||path.endsWith(".gif")||path.endsWith(".jpg")||path.endsWith(".JPEG")||path.endsWith(".GIF")||path.endsWith(".JPG"))
			{
				return true;
			}
			return false;
		}
		return false;
	}
	
	public boolean roomCheck()
	{
		try {
			con = DBConnection.getConnection();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select r_no from roombookingdetails where r_no = '"+txtRoomNo.getText()+"'");
			if(rs.next())
			{
				return false;
			}
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.toString());
		}
		return true;
	}
	
	public void dayCount()
	{
		 java.util.Date dt1=dateBookFrom.getDate();
	     java.util.Date dt2=dateBookTo.getDate();
	     fromDate=Calendar.getInstance();
	     toDate=Calendar.getInstance();
	     
	     if(dt1.after(dt2))
	     {
	    	 JOptionPane.showMessageDialog(null, "Sorry! Invalid Date");
	     }
	     else
	     {
	    	 fromDate.setTime(dt1);
	    	 toDate.setTime(dt2);
	     }
	     inc = 0;
	     
	     
	     if(fromDate.get(Calendar.DAY_OF_MONTH) > (toDate.get(Calendar.DAY_OF_MONTH)))
	     {
	    	 inc = monthDay[fromDate.get(Calendar.MONTH)-1];
	     }
	     if(inc == -1)
	     {
	    	 if(fromDate.getActualMaximum(Calendar.DAY_OF_MONTH)==29)
	    	 {
	    		 inc = 29;
	    	 }
	    	 else
	    	 {
	    		 inc = 28;
	    	 }
	     }
	     
	     if(inc != 0)
	     {
	    	 ageDays = (toDate.get(Calendar.DAY_OF_MONTH) + inc) - fromDate.get(Calendar.DAY_OF_MONTH);
	    	 inc = 1;
	     }
	     else
	     {
	    	 ageDays= toDate.get(Calendar.DAY_OF_MONTH) - fromDate.get(Calendar.DAY_OF_MONTH);
	     }
	     
	     if ((fromDate.get(Calendar.MONTH) + inc) > toDate.get(Calendar.MONTH))
	     {
	         ageMonths = (toDate.get(Calendar.MONTH) + 12) - (fromDate.get(Calendar.MONTH) + inc);
	         inc = 1;
	     }
	     else
	     {
	         ageMonths = (toDate.get(Calendar.MONTH)) - (fromDate.get(Calendar.MONTH + inc));
	         inc = 0;
         }
	     
	     ageYear = toDate.get(Calendar.YEAR) - (fromDate.get(Calendar.YEAR) + inc);
	     
	
	     	meal = ageDays*2;
	    	txtTotalDays.setText(Integer.toString(ageDays));
		   // txtMealCharge.setText(Integer.toString(ageDays));
		    lblNoOfDay.setText("x "+Integer.toString(ageDays)+" days");
		    lblMealCharge.setText("x "+Integer.toString(meal)+" times");
		    
	}
	
	
	
	public static String random(int length)
	{
		String alpha = new String("0123456789XYZ");
		int n = alpha.length();
		String result = new String();
		Random r = new Random();
		for(int i=0;i<length;i++)
			result = result+alpha.charAt(r.nextInt(n));
		return result;
	}
}

