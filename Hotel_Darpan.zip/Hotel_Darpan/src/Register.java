import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.SwingConstants;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.sql.PreparedStatement;
import java.sql.Statement;

import javax.swing.JTextField;
import javax.swing.JButton;

import com.mysql.jdbc.Connection;


public class Register extends JFrame {

	private JPanel contentPane;
	private JTextField textFieldName;
	private JTextField textFieldUsername;
	private JTextField textFieldEmail;
	private JPasswordField textFieldPassword;
	Connection con;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Register frame = new Register();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Register() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(450, 200, 364, 396);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setResizable(false);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 0, 102));
		panel.setBounds(0, 0, 359, 67);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Admin Registration");
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Century Gothic", Font.BOLD, 16));
		lblNewLabel.setBounds(0, 0, 357, 67);
		panel.add(lblNewLabel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(0, 0, 51));
		panel_1.setBounds(0, 67, 359, 301);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Fullname");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setBounds(20, 25, 82, 24);
		panel_1.add(lblNewLabel_1);
		
		textFieldName = new JTextField();
		textFieldName.setBounds(112, 24, 208, 29);
		panel_1.add(textFieldName);
		textFieldName.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Username");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_2.setForeground(new Color(255, 255, 255));
		lblNewLabel_2.setBounds(22, 75, 82, 14);
		panel_1.add(lblNewLabel_2);
		
		textFieldUsername = new JTextField();
		textFieldUsername.setColumns(10);
		textFieldUsername.setBounds(114, 64, 208, 29);
		panel_1.add(textFieldUsername);
		
		JLabel lblNewLabel_3 = new JLabel("Email");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_3.setForeground(new Color(255, 255, 255));
		lblNewLabel_3.setBounds(22, 111, 82, 24);
		panel_1.add(lblNewLabel_3);
		
		textFieldEmail = new JTextField();
		textFieldEmail.setColumns(10);
		textFieldEmail.setBounds(114, 104, 208, 29);
		panel_1.add(textFieldEmail);
		
		JLabel lblNewLabel_4 = new JLabel("Password");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_4.setForeground(new Color(255, 255, 255));
		lblNewLabel_4.setBounds(22, 146, 82, 24);
		panel_1.add(lblNewLabel_4);
		
		textFieldPassword = new JPasswordField();
		textFieldPassword.setColumns(10);
		textFieldPassword.setBounds(114, 144, 208, 29);
		panel_1.add(textFieldPassword);
		
		JButton btnRegister = new JButton("Register");
		btnRegister.setForeground(new Color(255, 255, 255));
		btnRegister.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnRegister.setBackground(new Color(0, 51, 102));
		btnRegister.setBounds(114, 184, 208, 34);
		panel_1.add(btnRegister);
		
		btnRegister.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				RegistrationProcess();
			}
		});
		
		
		
		
		JLabel lblNewLabel_5 = new JLabel("Already registered?");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_5.setForeground(new Color(255, 255, 255));
		lblNewLabel_5.setBounds(157, 222, 128, 24);
		panel_1.add(lblNewLabel_5);
		
		JButton btnGoToLogin = new JButton("Go to login");
		btnGoToLogin.setForeground(new Color(255, 255, 255));
		btnGoToLogin.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnGoToLogin.setBackground(new Color(0, 51, 102));
		btnGoToLogin.setBounds(114, 246, 206, 34);
		panel_1.add(btnGoToLogin);
		
		btnGoToLogin.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				login login = new login();
				login.setVisible(true);
				dispose();
			}
		});
		
	}
	
	public void RegistrationProcess()
	{
		String name = textFieldName.getText();
		String username = textFieldUsername.getText();
		String email = textFieldEmail.getText();
		char[] pass = textFieldPassword.getPassword();
		
		String pwd = new String(pass);
		
		if(name.equals("")||username.equals("")||email.equals("")||pwd.equals(""))
		{
			JOptionPane.showMessageDialog(null, "You can't leave any field empty !", "Registration Failed", JOptionPane.ERROR_MESSAGE);
		
		}
		else
		{
			try {
				con = (Connection) DBConnection.getConnection();
				Statement stmt = con.createStatement();
				
				PreparedStatement pre = con.prepareStatement("insert into admin(`fullname`,`username`,`email`,`password`)values(?,?,?,?)");
				
				pre.setString(1, name);
				pre.setString(2, username);
				pre.setString(3, email);
				pre.setString(4, pwd);
				
				pre.executeUpdate();
				JOptionPane.showMessageDialog(null, "Registration successful!");
				login login = new login();
				login.setVisible(true);
				dispose();
				
			} catch (Exception e) {
				// TODO: handle exception
				JOptionPane.showMessageDialog(null, e.toString());
			}
		}
		
	}

}


