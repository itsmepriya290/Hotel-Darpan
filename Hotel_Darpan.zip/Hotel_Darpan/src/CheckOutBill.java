import javax.imageio.ImageIO;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;

import java.awt.Color;

import javax.swing.JLabel;

import java.awt.Font;
import java.awt.SystemColor;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import com.mysql.jdbc.Connection;
import javax.swing.JTextField;


public class CheckOutBill extends JPanel {
	private JTable table;
	private JTable jt;
	private JTable table_1;
	
	/**
	 * Create the panel.
	 * @throws IOException 
	 */
	
	public CheckOutBill() throws IOException {
		setBorder(new LineBorder(new Color(0, 0, 0)));
		setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setLocation(0, 0);
		panel.setBackground(Color.WHITE);
		//panel.setBounds(10, 11, 300, 508);
		panel.setSize(796,739);   
		add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Hotel Darpan");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 30));
		lblNewLabel.setBounds(115, 52, 200, 37);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("INVOICE");
		lblNewLabel_1.setForeground(SystemColor.textHighlight);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 21));
		lblNewLabel_1.setBounds(557, 56, 103, 50);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_3 = new JLabel("__________________________________________________________________________________________");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_3.setBounds(10, 200, 724, 50);
		panel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Lodipur Buddha Marg, Lodipur, Patna");
		lblNewLabel_4.setToolTipText(",");
		lblNewLabel_4.setBounds(115, 101, 257, 18);
		panel.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Bihar - 800001");
		lblNewLabel_5.setBounds(115, 130, 127, 14);
		panel.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("___________________________________");
		lblNewLabel_6.setBounds(107, 75, 218, 14);
		panel.add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("Services");
		lblNewLabel_7.setForeground(Color.WHITE);
		lblNewLabel_7.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_7.setBackground(Color.WHITE);
		lblNewLabel_7.setBounds(169, 261, 85, 14);
		panel.add(lblNewLabel_7);
		
		JLabel lblNewLabel_10 = new JLabel("Unit Total");
		lblNewLabel_10.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_10.setForeground(Color.WHITE);
		lblNewLabel_10.setBounds(614, 261, 97, 14);
		panel.add(lblNewLabel_10);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.DARK_GRAY);
		panel_1.setBounds(10, 249, 724, 37);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_9 = new JLabel("Discount");
		lblNewLabel_9.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_9.setForeground(Color.WHITE);
		lblNewLabel_9.setBounds(466, 11, 77, 14);
		panel_1.add(lblNewLabel_9);
		
		JLabel lblNewLabel_8 = new JLabel("Charged Amt.");
		lblNewLabel_8.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_8.setForeground(Color.WHITE);
		lblNewLabel_8.setBounds(322, 11, 110, 14);
		panel_1.add(lblNewLabel_8);
		
		JLabel lblDate = new JLabel("Date");
		lblDate.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblDate.setForeground(Color.WHITE);
		lblDate.setBounds(36, 11, 51, 14);
		panel_1.add(lblDate);
		
		JLabel lblBillDate = new JLabel("lblBillDate");
		lblBillDate.setBounds(34, 309, 85, 14);
		panel.add(lblBillDate);
		
		JLabel lblBillService = new JLabel("lblBillService");
		lblBillService.setBounds(156, 309, 118, 14);
		panel.add(lblBillService);
		
		JLabel lblBillChargedAmt = new JLabel("lblBillChargedAmt");
		lblBillChargedAmt.setBounds(320, 309, 97, 14);
		panel.add(lblBillChargedAmt);
		
		JLabel lblBillDiscount = new JLabel("lblBillDiscount");
		lblBillDiscount.setBounds(469, 309, 78, 14);
		panel.add(lblBillDiscount);
		
		JLabel lblBillUnitTotal = new JLabel("lblBillUnitTotal");
		lblBillUnitTotal.setBounds(614, 309, 97, 14);
		panel.add(lblBillUnitTotal);
	
		
	}
}
