import java.awt.BorderLayout;
import java.awt.Dialog.ModalExclusionType;
import java.awt.Frame;
import java.awt.LayoutManager;
import java.awt.Window.Type;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JComboBox;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;


public class SelectRoom{
	private static final LayoutManager BorderLayout = null;
	private JTable table;
	Connection con;
	ResultSet rs;
	String columnName[];
	String data[][];
	int col=0,row=0;
	int i,j;
	
	JButton btnSelectRoom = new JButton("Select Room");

	/**
	 * Create the panel.
	 */
	public SelectRoom() {
		JFrame f = new JFrame();
		f.setTitle("Select Room");
		f.setBounds(100, 100, 480, 300);
		f.getContentPane().setLayout(BorderLayout);
		f.getContentPane().setLayout(new BorderLayout(0, 0));
		btnSelectRoom.setBackground(Color.BLACK);
		btnSelectRoom.setForeground(Color.WHITE);
		
		btnSelectRoom.setSize(250, 50);
		
		table = new JTable();
		table.setBackground(Color.LIGHT_GRAY);
		
		
		f.getContentPane().add(table);  
		
		try{
			con = DBConnection.getConnection();
			Statement stmt = con.createStatement();
			rs = stmt.executeQuery("select r_number,r_ac_nonac,r_type,r_rate,r_status from room");
			ResultSetMetaData rsm = rs.getMetaData();
			col = rsm.getColumnCount();
			columnName = new String[col];
			int id = 1;
			for (i = 0; i < columnName.length; i++) {
				//columnName[i] = rsm.getColumnName(i+1);	
				columnName[0] = "<html><b>Room No.</b></html>";
				columnName[1] = "<html><b>AC or Non-AC</b></html>";
				columnName[2] = "<html><b>Room Type</b></html>";
				columnName[3] = "<html><b>Room Rate</b></html>";
				columnName[4] = "<html><b>Status</b></html>";
			}
			while (rs.next())row++;
			rs = stmt.executeQuery("select r_number,r_ac_nonac,r_type,r_rate,r_status from room");
			data = new String[row][col];
			for (i = 0; rs.next(); i++) {
				for (j = 0; j<col; j++)
				{
					data[i][j] = rs.getString(j+1);
					
				}
			}
			table = new JTable(data, columnName);
		}catch(Exception e)
		{	
			JOptionPane.showMessageDialog(null, e.toString());
		}
		
		
		
		btnSelectRoom.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int row = table.getSelectedRow();
				int column = table.getColumnCount();
				for(int i = 0;i<column;i++)
				{
					//JOptionPane.showMessageDialog(null, table.getValueAt(row, i));
					String dt = (String)table.getValueAt(row, i);
					System.out.println(table.getValueAt(row, i));
				}
				
			}
		});
		
		
		
		
		JPanel p = new  JPanel();
		
		p.add(btnSelectRoom);
		f.getContentPane().add(p,"South");
		
		JScrollPane tableContainer = new JScrollPane(table);
		f.getContentPane().add(tableContainer);
		f.setVisible(true);
		
		DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
		centerRenderer.setHorizontalAlignment(JLabel.CENTER);
		for(int c = 0;c<col;c++)
		{
			table.getColumnModel().getColumn(c).setCellRenderer(centerRenderer);
			
		}
	}

	private void getRoomIdForDelete(JComboBox cbDeleteRoom) {
		// TODO Auto-generated method stub
		try {
			Connection con = DBConnection.getConnection();
			Statement stmt = con.createStatement();
			
			ResultSet rs = stmt.executeQuery("select * from room");
			while(rs.next())
			{
				cbDeleteRoom.addItem(rs.getString(2));
			}
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
		
	}
}
