import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.LayoutManager;
import java.awt.SystemColor;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.JTextPane;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JRadioButton;

import com.toedter.calendar.JDateChooser;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.Calendar;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.UIManager;


public class FunctionBooking extends JPanel {
	private JTextField txt_no_of_person;
	private JTextField txt_totaldays;
	private JTextField txt_purpose_of_booking;
	private JTextField txt_fullname;
	private JTextField txt_son_daughterof;
	private JTextField txt_address;
	private JTextField txt_state;
	private JTextField txt_city;
	private JTextField txt_country;
	private JTextField txt_pin;
	private JTextField txt_mobileno;
	private JTextField txt_email;
	private JTextField txt_total_days;
	private JTextField txt_hall_rate;
	private JTextField txt_total;
	private JTextField txt_tax;
	private JTextField txt_grandtotal;
	private JTextField txt_advance;
	private JTextField txt_due;
	private JTextField txt_Customer_Id;
	private JTextField txtHallType;
	private JTextField txtHallNo;
	JDateChooser dateCheckIn = new JDateChooser();
	JDateChooser dateCheckOut = new JDateChooser();
	int monthDay[] = { 31, -1, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
    int ageDays;int ageMonths;int ageYear;
    Calendar fromDate;Calendar toDate;
    int inc;
    private JLabel lblURL = new JLabel("New label");
    private JButton btnBook = new JButton("Book");
    private JButton btnSelectHall = new JButton("Add Hall");
    private JRadioButton RadioCash = new JRadioButton("Cash");
    private JRadioButton RadioCredit = new JRadioButton("Credit card");
    private JRadioButton RadioCheque = new JRadioButton("Cheque");
    
    JButton btnSelectH = new JButton("Select Hall");
    JFileChooser chooser = new JFileChooser();
    private JTable table;
	Connection con;
	ResultSet rs;
	
	String columnName[];
	String columnName2[];
	String data[][];
	int col=0,row=0;
    
	int i,j;
	JLabel lblUrl;
	JFrame fr = new JFrame();

	/**
	 * Create the panel.
	 */
	public FunctionBooking() {
		setVisible(true);
		//setSize(500, 500);
		setBackground(Color.LIGHT_GRAY);
		setLayout(null);
		Border a = BorderFactory.createTitledBorder(null, "<html><font color='blue'><i><u>Booking Details</u></i></font></html>");
		Border b = BorderFactory.createTitledBorder(null, "<html><font color='blue'><i><u>Customer Details</u></i></font></html>");
		Border c = BorderFactory.createTitledBorder(null, "<html><font color='blue'><i><u>Tariff Calculation</u></i></font></html>");
		Border d = BorderFactory.createTitledBorder(null, "<html><font color='blue'><i><u>Pay</u></i></font></html>");
		Border e = BorderFactory.createTitledBorder(null, "<html><font color='blue'><i><u>Payment Mode</u></i></font></html>");
		Border f = BorderFactory.createTitledBorder(null, "<html><font color='blue'><i><u>Hall Option</u></i></font></html>");
		
		JPanel Booking_Details = new JPanel();
		Booking_Details.setBounds(0, 69, 372, 356);
		add(Booking_Details);
		Booking_Details.setBorder(a);
		Booking_Details.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Check In :");
		lblNewLabel.setBounds(17, 78, 99, 14);
		Booking_Details.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Check out:");
		lblNewLabel_1.setBounds(17, 117, 99, 14);
		Booking_Details.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Total Days:");
		lblNewLabel_2.setBounds(17, 151, 99, 14);
		Booking_Details.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("No. of persons:");
		lblNewLabel_3.setBounds(17, 191, 87, 23);
		Booking_Details.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Purpose of booking:");
		lblNewLabel_4.setBounds(17, 239, 113, 23);
		Booking_Details.add(lblNewLabel_4);
		
		txt_no_of_person = new JTextField();
		txt_no_of_person.setBounds(142, 190, 148, 30);
		Booking_Details.add(txt_no_of_person);
		txt_no_of_person.setColumns(10);
		
		txt_totaldays = new JTextField();
		txt_totaldays.setFont(new Font("Tahoma", Font.BOLD, 12));
		txt_totaldays.setEditable(false);
		txt_totaldays.setBounds(142, 143, 148, 30);
		Booking_Details.add(txt_totaldays);
		txt_totaldays.setColumns(10);
		
		txt_purpose_of_booking = new JTextField();
		txt_purpose_of_booking.setBounds(142, 235, 148, 27);
		Booking_Details.add(txt_purpose_of_booking);
		txt_purpose_of_booking.setColumns(10);
		
		JLabel label = new JLabel("");
		label.setBounds(173, 297, 46, 14);
		Booking_Details.add(label);
		
		
		dateCheckIn.setDateFormatString("dd-MM-yyyy");
		dateCheckIn.setBounds(142, 78, 107, 20);
		Booking_Details.add(dateCheckIn);
		dateCheckIn.setDate(Calendar.getInstance().getTime());
		
		dateCheckIn.getCalendarButton().addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				//dayCount();
			}
		});
		
		
		dateCheckOut.setDateFormatString("dd-MM-yyyy");
		dateCheckOut.setBounds(142, 111, 107, 20);
		Booking_Details.add(dateCheckOut);
		dateCheckOut.setDate(Calendar.getInstance().getTime());
		
		dateCheckOut.getCalendarButton().addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				//dayCount();
			}
		});
		
		JButton btnSelectDate = new JButton("");
		btnSelectDate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dayCount();
			}
		});
		
		btnSelectDate.setHorizontalAlignment(SwingConstants.LEADING);
		btnSelectDate.setIcon(new ImageIcon("./images\\ic_action_accept.png"));
		btnSelectDate.setForeground(Color.WHITE);
		btnSelectDate.setBackground(Color.BLACK);
		btnSelectDate.setBounds(255, 109, 54, 23);
		Booking_Details.add(btnSelectDate);
		
		JLabel lblHallType = new JLabel("Hall Type:");
		lblHallType.setBounds(17, 291, 66, 14);
		Booking_Details.add(lblHallType);
		
		txtHallType = new JTextField();
		txtHallType.setFont(new Font("Tahoma", Font.BOLD, 12));
		txtHallType.setEditable(false);
		txtHallType.setBounds(145, 282, 143, 30);
		Booking_Details.add(txtHallType);
		txtHallType.setColumns(10);
		
		JLabel lblNewLabel_24 = new JLabel("Hall No.");
		lblNewLabel_24.setBounds(17, 36, 66, 26);
		Booking_Details.add(lblNewLabel_24);
		
		txtHallNo = new JTextField();
		txtHallNo.setFont(new Font("Tahoma", Font.BOLD, 12));
		txtHallNo.setEditable(false);
		txtHallNo.setBounds(143, 36, 72, 23);
		//textField.setBounds(142, 31, 107, 23);
		Booking_Details.add(txtHallNo);
		txtHallNo.setColumns(10);
		
		//JButton btnSelectHall = new JButton("Add Hall");
		btnSelectHall.setForeground(Color.WHITE);
		btnSelectHall.setBackground(Color.BLACK);
		btnSelectHall.setHorizontalAlignment(SwingConstants.LEADING);
		btnSelectHall.setIcon(new ImageIcon("./images\\ic_action_new.png"));
		btnSelectHall.setBounds(227, 33, 136, 30);
		Booking_Details.add(btnSelectHall);
		
		btnSelectHall.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				LayoutManager BorderLayout = null;
				
				fr.setTitle("Select");
				fr.setBounds(500, 220, 480, 300);
				fr.getContentPane().setLayout(new BorderLayout(0, 0));
				table = new JTable();
				table.setBackground(Color.LIGHT_GRAY);
				
				
				fr.getContentPane().add(table);  
				
				try{
					con = DBConnection.getConnection();
					Statement stmt = con.createStatement();
					rs = stmt.executeQuery("select h_number,h_ac_nonac,h_rate,h_status from hall");
					ResultSetMetaData rsm = rs.getMetaData();
					col = rsm.getColumnCount();
					columnName = new String[col];
					//for (i = 0; i < columnName.length; i++) {
						//columnName[i] = rsm.getColumnName(i+1);	
						columnName[0] = "<html><b>Hall No.</b></html>";
						columnName[1] = "<html><b>AC or Non-AC</b></html>";
						columnName[2] = "<html><b>Hall Charge</b></html>";
						columnName[3] = "<html><b>Status</b></html>";
					
					//}
					while (rs.next())row++;
					rs = stmt.executeQuery("select h_number,h_ac_nonac,h_rate,h_status from hall");
					data = new String[row][col];
					for (i = 0; rs.next(); i++) {
						for (j = 0; j<col; j++)
						{
							data[i][j] = rs.getString(j+1);
						}
					}
					table = new JTable(data, columnName);
				}catch(Exception exc)
				{	
					JOptionPane.showMessageDialog(null, exc.toString());
				}
				JPanel p = new  JPanel();
				p.setBackground(Color.ORANGE);
				p.add(btnSelectH);
				fr.getContentPane().add(p,"South");
				JScrollPane tableContainer = new JScrollPane(table);
				fr.getContentPane().add(tableContainer);
				fr.setVisible(true);
				fr.setResizable(false);
				DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
				centerRenderer.setHorizontalAlignment(JLabel.CENTER);
				for(int c = 0;c<col;c++)
				{
					table.getColumnModel().getColumn(c).setCellRenderer(centerRenderer);
					
				}
				
			}
		});
		
		btnSelectH.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				try{
					int row = table.getSelectedRow();
					int column = table.getColumnCount();
					for(int i = 0;i<4;i++)
					{
						//Object dt = table.getValueAt(row, i);
						txtHallNo.setText((String) table.getValueAt(row, 0));
						txtHallType.setText((String) table.getValueAt(row, 1));
						//txtRoomType.setText((String) table.getValueAt(row, 2));
						txt_hall_rate.setText((String) table.getValueAt(row, 2));
					}
				}
				catch(Exception ex){
					JOptionPane.showMessageDialog(null, ex.toString());
				}
				fr.dispose();
			}
		});
		
		
		
		JPanel Customer_details = new JPanel();
		Customer_details.setBounds(368, 69, 358, 419);
		add(Customer_details);
		Customer_details.setBorder(b);
		Customer_details.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(0, 0, 10, 10);
		Customer_details.add(panel_1);
		
		JLabel lblNewLabel_6 = new JLabel("Full Name:*");
		lblNewLabel_6.setBounds(8, 47, 93, 14);
		Customer_details.add(lblNewLabel_6);
		
		txt_fullname = new JTextField();
		txt_fullname.setBounds(132, 47, 190, 23);
		Customer_details.add(txt_fullname);
		txt_fullname.setColumns(10);
		
		JLabel lblNewLabel_7 = new JLabel("Son/daughter of:");
		lblNewLabel_7.setBounds(10, 70, 106, 23);
		Customer_details.add(lblNewLabel_7);
		
		txt_son_daughterof = new JTextField();
		txt_son_daughterof.setBounds(132, 74, 190, 29);
		Customer_details.add(txt_son_daughterof);
		txt_son_daughterof.setColumns(10);
		
		JLabel lblNewLabel_8 = new JLabel("Address:*");
		lblNewLabel_8.setBounds(10, 126, 79, 23);
		Customer_details.add(lblNewLabel_8);
		
		txt_address = new JTextField();
		txt_address.setBounds(133, 114, 190, 69);
		Customer_details.add(txt_address);
		txt_address.setColumns(10);
		
		JLabel lblNewLabel_9 = new JLabel("State:*");
		lblNewLabel_9.setBounds(10, 203, 46, 14);
		Customer_details.add(lblNewLabel_9);
		
		txt_state = new JTextField();
		txt_state.setBounds(132, 199, 70, 23);
		Customer_details.add(txt_state);
		txt_state.setColumns(10);
		
		JLabel lblNewLabel_10 = new JLabel("City:*");
		lblNewLabel_10.setBounds(218, 199, 29, 14);
		Customer_details.add(lblNewLabel_10);
		
		txt_city = new JTextField();
		txt_city.setBounds(257, 199, 71, 23);
		Customer_details.add(txt_city);
		txt_city.setColumns(10);
		
		JLabel lblNewLabel_11 = new JLabel("Country:*");
		lblNewLabel_11.setBounds(10, 231, 64, 14);
		Customer_details.add(lblNewLabel_11);
		
		JLabel lblNewLabel_12 = new JLabel("Pin:*");
		lblNewLabel_12.setBounds(218, 239, 29, 14);
		Customer_details.add(lblNewLabel_12);
		
		txt_country = new JTextField();
		txt_country.setBounds(132, 233, 70, 22);
		Customer_details.add(txt_country);
		txt_country.setColumns(10);
		
		txt_pin = new JTextField();
		txt_pin.setBounds(257, 234, 71, 23);
		Customer_details.add(txt_pin);
		txt_pin.setColumns(10);
		
		JLabel lblNewLabel_13 = new JLabel("Mobile No.:");
		lblNewLabel_13.setBounds(10, 274, 64, 14);
		Customer_details.add(lblNewLabel_13);
		
		txt_mobileno = new JTextField();
		txt_mobileno.setBounds(132, 268, 194, 23);
		Customer_details.add(txt_mobileno);
		txt_mobileno.setColumns(10);
		
		JLabel lblNewLabel_14 = new JLabel("Email:");
		lblNewLabel_14.setBounds(10, 306, 46, 14);
		Customer_details.add(lblNewLabel_14);
		
		txt_email = new JTextField();
		txt_email.setBounds(133, 304, 193, 23);
		Customer_details.add(txt_email);
		txt_email.setColumns(10);
		
		JLabel Customer_id = new JLabel("Customer ID:");
		Customer_id.setBounds(9, 21, 80, 14);
		Customer_details.add(Customer_id);
		
		txt_Customer_Id = new JTextField();
		txt_Customer_Id.setFont(new Font("Tahoma", Font.BOLD, 14));
		txt_Customer_Id.setForeground(new Color(128, 0, 0));
		txt_Customer_Id.setEditable(false);
		txt_Customer_Id.setBounds(132, 22, 190, 20);
		Customer_details.add(txt_Customer_Id);
		txt_Customer_Id.setColumns(10);
		txt_Customer_Id.setText("C"+random(3));
		
		JLabel lblNewLabel_23 = new JLabel("Identity Type:");
		lblNewLabel_23.setBounds(8, 345, 86, 14);
		Customer_details.add(lblNewLabel_23);
		
		//JLabel lblURL = new JLabel("New label");
		lblURL.setBounds(132, 390, 194, 14);
		Customer_details.add(lblURL);
		
		JButton btnBrowse = new JButton("Browse");
		btnBrowse.setBackground(Color.BLACK);
		btnBrowse.setForeground(Color.WHITE);
		btnBrowse.setHorizontalAlignment(SwingConstants.LEADING);
		btnBrowse.setIcon(new ImageIcon("./images\\ic_action_picture.png"));
		btnBrowse.setBounds(132, 338, 115, 30);
		Customer_details.add(btnBrowse);
		btnBrowse.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				try{	
					chooser.setMultiSelectionEnabled(false);
					chooser.setVisible(true);
					File file = chooser.getSelectedFile();
					chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
					chooser.setAcceptAllFileFilterUsed(false);
					int rVal = chooser.showOpenDialog(null);
					if(rVal == JFileChooser.APPROVE_OPTION)
					{
						lblURL.setText(chooser.getSelectedFile().toString());
					}
				}
				catch(Exception ex){
					JOptionPane.showMessageDialog(null, ex.toString());
				}
			}
		});
		
		JLabel NewLabel_url = new JLabel("URL:");
		NewLabel_url.setBounds(8, 390, 46, 14);
		Customer_details.add(NewLabel_url);
		
		
		
		JPanel TriffCalculation = new JPanel();
		TriffCalculation.setBounds(724, 69, 298, 419);
		add(TriffCalculation);
		TriffCalculation.setLayout(null);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBounds(2, 0, 277, 235);
		TriffCalculation.add(panel_2);
		panel_2.setLayout(null);
		panel_2.setBorder(c);
		
		JLabel lblNewLabel_15 = new JLabel("No. of days:");
		lblNewLabel_15.setBounds(21, 22, 80, 14);
		panel_2.add(lblNewLabel_15);
		
		txt_total_days = new JTextField();
		txt_total_days.setEditable(false);
		txt_total_days.setBounds(116, 19, 143, 20);
		panel_2.add(txt_total_days);
		txt_total_days.setColumns(10);
		
		JLabel lblNewLabel_16 = new JLabel("Hall Rate:");
		lblNewLabel_16.setBounds(21, 56, 61, 23);
		panel_2.add(lblNewLabel_16);
		
		txt_hall_rate = new JTextField();
		txt_hall_rate.setEditable(false);
		txt_hall_rate.setBounds(115, 59, 144, 20);
		panel_2.add(txt_hall_rate);
		txt_hall_rate.setColumns(10);
		
		JLabel lblNewLabel_17 = new JLabel("Total:");
		lblNewLabel_17.setBounds(21, 99, 61, 14);
		panel_2.add(lblNewLabel_17);
		
		txt_total = new JTextField();
		txt_total.setEditable(false);
		txt_total.setBounds(116, 96, 143, 20);
		panel_2.add(txt_total);
		txt_total.setColumns(10);
		
		JLabel lblNewLabel_18 = new JLabel("Tax:");
		lblNewLabel_18.setBounds(21, 140, 46, 14);
		panel_2.add(lblNewLabel_18);
		
		txt_tax = new JTextField();
		txt_tax.setEditable(false);
		txt_tax.setBounds(116, 137, 86, 20);
		panel_2.add(txt_tax);
		txt_tax.setColumns(10);
		
		JLabel lblNewLabel_19 = new JLabel(" 10% of tax");
		lblNewLabel_19.setBounds(205, 140, 74, 14);
		panel_2.add(lblNewLabel_19);
		
		JLabel lblNewLabel_20 = new JLabel("Grand Total:");
		lblNewLabel_20.setBounds(10, 184, 72, 14);
		panel_2.add(lblNewLabel_20);
		
		txt_grandtotal = new JTextField();
		txt_grandtotal.setEditable(false);
		txt_grandtotal.setBounds(116, 177, 143, 33);
		panel_2.add(txt_grandtotal);
		txt_grandtotal.setColumns(10);
		
		JPanel Payments = new JPanel();
		Payments.setBounds(2, 242, 277, 177);
		TriffCalculation.add(Payments);
		Payments.setLayout(null);
		Payments.setBorder(e);
		
		JLabel lblNewLabel_21 = new JLabel("Advance:");
		lblNewLabel_21.setBounds(16, 37, 69, 25);
		Payments.add(lblNewLabel_21);
		
		txt_advance = new JTextField();
		txt_advance.setBounds(117, 39, 142, 25);
		Payments.add(txt_advance);
		txt_advance.setColumns(10);
		
		JLabel lblNewLabel_22 = new JLabel("Due:");
		lblNewLabel_22.setBounds(16, 75, 46, 27);
		Payments.add(lblNewLabel_22);
		
		txt_due = new JTextField();
		txt_due.setEditable(false);
		txt_due.setBounds(117, 77, 142, 25);
		Payments.add(txt_due);
		txt_due.setColumns(10);
		
		JPanel PaymentMode = new JPanel();
		PaymentMode.setBounds(0, 425, 372, 65);
		add(PaymentMode);
		PaymentMode.setLayout(null);
		
		PaymentMode.setBorder(e);
		
		//JRadioButton RadioCheque = new JRadioButton("Cheque");
		RadioCheque.setBounds(30, 22, 80, 23);
		PaymentMode.add(RadioCheque);
		
		//JRadioButton RadioCash = new JRadioButton("Cash");
		RadioCash.setBounds(123, 20, 68, 29);
		PaymentMode.add(RadioCash);
		
		//JRadioButton RadioCredit = new JRadioButton("Credit card");
		RadioCredit.setBounds(210, 25, 102, 25);
		PaymentMode.add(RadioCredit);
		
		JButton btnCalculate = new JButton("Calculate");
		btnCalculate.setHorizontalAlignment(SwingConstants.LEFT);
		btnCalculate.setIcon(new ImageIcon("./images\\ic_action_add_to_queue.png"));
		btnCalculate.setBackground(Color.BLACK);
		btnCalculate.setForeground(Color.WHITE);
		btnCalculate.setBounds(10, 127, 126, 34);
		Payments.add(btnCalculate);
		
		btnCalculate.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				try {
					if(txt_advance.getText().trim().length()==0)
					{
						JOptionPane.showMessageDialog(null, "Advance Payment Must !");
						txt_advance.requestFocus();
					}
					else
					{
						String due = txt_due.getText();
						int d = Integer.parseInt(txt_total_days.getText());
						double r = Integer.parseInt(txt_hall_rate.getText());
						double ad = Integer.parseInt(txt_advance.getText());
						double tt = d * r;
						double total=tt;
						double tax = r/10;
						
						txt_tax.setText(""+tax);
						txt_grandtotal.setText(""+(tt+tax));
						txt_due.setText(""+((tt+tax)-ad));
						txt_total.setText(""+total);
						
					}
				} catch (Exception e2) {
					JOptionPane.showMessageDialog(null, e2.toString());
				}
				
			}
		});
		
		//JButton btnBook = new JButton("Book");
		btnBook.setHorizontalAlignment(SwingConstants.LEFT);
		btnBook.setIcon(new ImageIcon("./images\\ic_action_book.png"));
		btnBook.setForeground(Color.WHITE);
		btnBook.setBackground(Color.BLACK);
		btnBook.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				/*try {
					Connection con=DBConnection.getConnection();
					java.sql.Statement stmt = con.createStatement();
					String sql ="insert into func_booking (c_id,check_in,check_out,`total_days`,`no_of_persons`,`purpose_booking`,`meal_plan`)values('"+txt_Customer_Id.getText()+"','"+dateCheckIn.getDate()+"''"+dateCheckOut.getDate()+"','"+txt_totaldays.getText()+"','"+txt_no_of_person.getText()+"','"+txt_purpose_of_booking.getText()+"','"+ cb_mealplan.getSelectedItem()+"')";
				stmt.execute(sql);
				} catch (Exception e2) {
					
					// TODO: handle exception
					JOptionPane.showMessageDialog(null, e2.toString());
				}*/
				
				if(txtHallNo.getText().trim().length()==0)
				{
					JOptionPane.showMessageDialog(null, "Please Select Hall","Invalid Days Count",JOptionPane.ERROR_MESSAGE);
					btnSelectHall.requestFocus();	
				}
				
				else if(txt_totaldays.getText().trim().length()==0)
				{
					JOptionPane.showMessageDialog(null, "Please Enter Total Days","Invalid Days Count",JOptionPane.ERROR_MESSAGE);
					txt_totaldays.requestFocus();	
				}
				
				else if(txt_no_of_person.getText().trim().length()==0)
				{
					JOptionPane.showMessageDialog(null, "Please Enter No. Of Person","Invalid Person Count",JOptionPane.ERROR_MESSAGE);
					txt_no_of_person.requestFocus();
					
				}
				else if(txt_purpose_of_booking.getText().trim().length()==0)
				{
					JOptionPane.showMessageDialog(null, "Please Enter Purpose Of Visit","Invalid Visiting Detail",JOptionPane.ERROR_MESSAGE);
					txt_purpose_of_booking.requestFocus();
				}
				/*else if(cb_mealplan.getSelectedItem().equals("Select Meal Plan"))
				{
					JOptionPane.showMessageDialog(null, "Please Select Meal Plan","Invalid Meal Plan",JOptionPane.ERROR_MESSAGE);
					cb_mealplan.requestFocus();
				}*/
				else if(txtHallType.getText().trim().equals(""))
				{
					JOptionPane.showMessageDialog(null, "Please Select Hall","Invalid Room",JOptionPane.ERROR_MESSAGE);
					txtHallType.requestFocus();
				}
				/*else if(txtRoomType.getText().equals("Select Room Type"))
				{
					JOptionPane.showMessageDialog(null, "Please Select Room Type","Invalid Room Type",JOptionPane.ERROR_MESSAGE);
					txtRoomType.requestFocus();
				}*/
				else if(txt_Customer_Id.getText().trim().length()==0)
				{
					JOptionPane.showMessageDialog(null, "Please Enter Customer-ID","Invalid Customer ID",JOptionPane.ERROR_MESSAGE);
					txt_Customer_Id.requestFocus();
				}
				else if(txt_fullname.getText().trim().length()==0)
				{
					JOptionPane.showMessageDialog(null, "Please Enter Customer Fullname","Invalid Customer Name",JOptionPane.ERROR_MESSAGE);
					txt_fullname.requestFocus();
				}
				else if(txt_son_daughterof.getText().trim().length()==0)
				{
					JOptionPane.showMessageDialog(null, "Please Enter Son/Daughter Of","Invalid",JOptionPane.ERROR_MESSAGE);
					txt_son_daughterof.requestFocus();
				}
				else if(txt_address.getText().trim().length()==0)
				{
					JOptionPane.showMessageDialog(null, "Please Enter Customer Address","Invalid Address",JOptionPane.ERROR_MESSAGE);
					txt_address.requestFocus();
				}
				else if(txt_state.getText().trim().length()==0)
				{
					JOptionPane.showMessageDialog(null, "Please Enter State","Invalid State",JOptionPane.ERROR_MESSAGE);
					txt_state.requestFocus();
				}
				else if(txt_city.getText().trim().length()==0)
				{
					JOptionPane.showMessageDialog(null, "Please Enter City","Invalid City",JOptionPane.ERROR_MESSAGE);
					txt_city.requestFocus();
				}
				else if(txt_country.getText().trim().length()==0)
				{
					JOptionPane.showMessageDialog(null, "Please Enter Country","Invalid Country",JOptionPane.ERROR_MESSAGE);
					txt_country.requestFocus();
				}
				
				else if(txt_pin.getText().trim().length()==0)
				{
					JOptionPane.showMessageDialog(null, "Please Enter PIN Number","Invalid PIN",JOptionPane.ERROR_MESSAGE);
					txt_pin.requestFocus();
				}
				else if(txt_mobileno.getText().trim().length()==0)
				{
					JOptionPane.showMessageDialog(null, "Please Enter Customer Mobile No.","Invalid Mobile Number", JOptionPane.ERROR_MESSAGE);
					txt_mobileno.requestFocus();
				}
				else if(txt_email.getText().trim().length()==0)
				{
					JOptionPane.showMessageDialog(null, "Please Enter Email ID.","Invalid Mobile Number", JOptionPane.ERROR_MESSAGE);
					txt_email.requestFocus();
				}
				
				
				else
				{
					try {
						String payment = null;
						
						if(RadioCash.isSelected())
							payment = "Cash";
						else if(RadioCredit.isSelected())
							payment = "Credit Card";
						else if(RadioCheque.isSelected())
							payment = "Cheque";
						else if(payment == null)
							JOptionPane.showMessageDialog(null, "Please Select Payment Option");
						
						Connection con=DBConnection.getConnection();
						java.sql.Statement stmt = con.createStatement();
						
						BookYourRoom();
						//dayCount();
						
					} catch (Exception exc) {
						// TODO: handle exception
						JOptionPane.showMessageDialog(null, exc.toString());
					}
					
				}
			}

			private void BookYourRoom() 
			{
				try {
					String payment = null;
					if(RadioCash.isSelected())
						payment = "Cash";
					else if(RadioCredit.isSelected())
						payment = "Credit Card";
					else if(RadioCheque.isSelected())
						payment = "Cheque";
					
					//int food = Integer.parseInt(txtMealCharge.getText());
					//int food_charge = food*meal;
					
					java.util.Date frDate = dateCheckIn.getDate();
					java.util.Date toDate = dateCheckOut.getDate();
					
					con = DBConnection.getConnection();
					Statement stmt = con.createStatement();
					File file = chooser.getSelectedFile();
					FileInputStream fin = new FileInputStream(file);
					//PreparedStatement pre = con.prepareStatement("insert into image(id,image) value(?,?)");
					//('"+txtDue.getText()+"','"+payment+"')");
					PreparedStatement pre = con.prepareStatement("insert into func_booking(`h_no`,`c_id`,`check_in`,`check_out`,`total_days`,`no_of_person`,`purpose_booking`,`h_type`,`c_fullname`,`c_son_of`,`c_address`,`c_state`,`c_city`,`c_country`,`c_pin`,`c_mobile`,`c_email`,`h_rate`,`total`,`tax`,`grand_total`,`advance`,`due`,`payment_mode`,`identity_image`,`meal_plan`,`r_type`)values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
					
					pre.setString(1, txtHallNo.getText());
					pre.setString(2, txt_Customer_Id.getText());
					pre.setString(3, frDate.toString());
					pre.setString(4, toDate.toString());
					pre.setString(5, txt_total_days.getText());
					pre.setString(6, txt_no_of_person.getText());
					pre.setString(7, txt_purpose_of_booking.getText());
					//pre.setString(8, (String) cbMealPlan.getSelectedItem());
					//pre.setString(9, txtMealCharge.getText());
					//pre.setLong(9, food_charge);
					//pre.setString(10, (String) txtRoom.getText());
					pre.setString(8, (String) txtHallType.getText());
					pre.setString(9, txt_fullname.getText());
					pre.setString(10, txt_son_daughterof.getText());
					pre.setString(11, txt_address.getText());
					pre.setString(12, txt_state.getText());
					pre.setString(13, txt_city.getText());
					pre.setString(14, txt_country.getText());
					pre.setString(15, txt_pin.getText());
					pre.setString(16, txt_mobileno.getText());
					pre.setString(17, txt_email.getText());
					pre.setString(18, txt_hall_rate.getText());
					pre.setString(19, txt_total.getText());
					pre.setString(20, txt_tax.getText());
					pre.setString(21, txt_grandtotal.getText());
					pre.setString(22, txt_advance.getText());
					pre.setString(23, txt_due.getText());
					pre.setString(24, payment);
					pre.setBinaryStream(25, (InputStream)fin,(int)file.length());
					pre.setString(26, "NONE");
					pre.setString(27, "NA");
					
					String updateQuery = "update hall set h_status = 'Booked' where h_number = '"+txtHallNo.getText()+"'";
					PreparedStatement preparedStatement = con.prepareStatement(updateQuery);
					
					
					if(check()==true && hallCheck()==true)
					{
						pre.executeUpdate();
						preparedStatement.executeUpdate();
						JOptionPane.showMessageDialog(null, "Your hall has been booked!","Function Booking",JOptionPane.INFORMATION_MESSAGE);
					}
					else if(hallCheck() == false)
					{
						JOptionPane.showMessageDialog(null, "Hall has already been booked");
					}
					else if(check()==false)
					{
						JOptionPane.showMessageDialog(null, "Please Select an Image File for Identity");
					}
					else
					{
						JOptionPane.showMessageDialog(null, "Booking Failed");
					}
					
					pre.close();
					con.close();
					
				}
				catch(Exception xc)
				{
					JOptionPane.showMessageDialog(null, xc.toString());
				}
			}

			private boolean hallCheck() {
				try {
					con = DBConnection.getConnection();
					Statement stmt = con.createStatement();
					ResultSet rs = stmt.executeQuery("select h_no from func_booking where h_no = '"+txtHallNo.getText()+"'");
					if(rs.next())
					{
						return false;
					}
				} catch (Exception e) {
					JOptionPane.showMessageDialog(null, e.toString());
				}
				return true;
			}

			private boolean check() {
				String path = lblURL.getText().toString();
				if(path!=null)
				{
					if(path.endsWith(".jpeg")||path.endsWith(".gif")||path.endsWith(".jpg")||path.endsWith(".JPEG")||path.endsWith(".GIF")||path.endsWith(".JPG"))
					{
						return true;
					}
					return false;
				}
				return false;
			}
		});
		
		btnBook.setBounds(146, 127, 113, 34);
		Payments.add(btnBook);
		
		JPanel HallOptionPanel = new JPanel();
		HallOptionPanel.setBorder(f);
		HallOptionPanel.setBounds(0, 488, 1009, 116);
		
		add(HallOptionPanel);
		
		final JTable table = new JTable();
		table.setBackground(Color.LIGHT_GRAY);
		table.setBounds(1, 26, 995, 0);
		HallOptionPanel.add(table);
		try{
			
			
			Connection con = DBConnection.getConnection();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select h_number,h_ac_nonac,h_rate,h_status from hall");
			//String st = rs.getString(5);
			ResultSetMetaData rsm = rs.getMetaData();
			col = rsm.getColumnCount();
			
			String columnName[] = {"Hall No","AC/Non-AC","Hall Charge","Availability"};
			//String r_status = null;
			DefaultTableModel tableModel = new DefaultTableModel(columnName,0);
			
			columnName2 = new String[col];
			int id = 1;
			for (int i = 0; i < columnName.length; i++) {
				columnName[i] = rsm.getColumnName(i+1);	
				//columnName[0] = "<html><b>Serial No.</b></html>";
				columnName[0] = "<html><b>Hall Number</b></html>";
				columnName[1] = "<html><b>AC or Non-AC</b></html>";
				columnName[2] = "<html><b>Hall Charge</b></html>";
				//columnName[3] = "<html><b>Hall Charge</b></html>";
				columnName[3] = "<html><b>Availability</b></html>";
			}
			while (rs.next())
			{
				//String avl = "Available";
				String h_number = rs.getString("h_number");
			    String h_ac_nonac = rs.getString("h_ac_nonac");
			    String h_rate = rs.getString("h_rate");
			    String h_status = rs.getString("h_status");
			   // String r_status = rs.getString("r_status");
			    String[] data = {h_number,h_ac_nonac,h_rate,h_status} ;
			    tableModel.addRow(data);
			}
			
		
			table.setModel(tableModel);
			table.setEnabled(false);
			
			
		}catch(Exception exc)
		{	
			JOptionPane.showMessageDialog(null, exc.toString());
		}
		table.setVisible(true);
		HallOptionPanel.setLayout(null);
		JScrollPane tableContainer = new JScrollPane(table);
		tableContainer.setBounds(6, 16, 997, 93);
		HallOptionPanel.add(tableContainer);
		
		JButton btnRefresh = new JButton("Refresh");
		btnRefresh.setForeground(Color.WHITE);
		btnRefresh.setBackground(Color.BLACK);
		btnRefresh.setBounds(79, -4, 89, 23);
		
		btnRefresh.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				
				try{
					Connection con = DBConnection.getConnection();
					Statement stmt = con.createStatement();
					ResultSet rs = stmt.executeQuery("select h_number,h_ac_nonac,h_rate,h_status from hall");
					//String st = rs.getString(5);
					ResultSetMetaData rsm = rs.getMetaData();
					col = rsm.getColumnCount();
					
					String columnName[] = {"Hall No","AC/Non-AC","Hall Charge","Availability"};
					//String r_status = null;
					DefaultTableModel tableModel = new DefaultTableModel(columnName,0);
					
					columnName2 = new String[col];
					int id = 1;
					for (int i = 0; i < columnName.length; i++) {
						columnName[i] = rsm.getColumnName(i+1);	
						//columnName[0] = "<html><b>Serial No.</b></html>";
						columnName[0] = "<html><b>Hall Number</b></html>";
						columnName[1] = "<html><b>AC or Non-AC</b></html>";
						columnName[2] = "<html><b>Hall Charge</b></html>";
						//columnName[3] = "<html><b>Hall Charge</b></html>";
						columnName[3] = "<html><b>Availability</b></html>";
					}
					while (rs.next())
					{
						//String avl = "Available";
						String h_number = rs.getString("h_number");
					    String h_ac_nonac = rs.getString("h_ac_nonac");
					    String h_rate = rs.getString("h_rate");
					    String h_status = rs.getString("h_status");
					   // String r_status = rs.getString("r_status");
					    String[] data = {h_number,h_ac_nonac,h_rate,h_status} ;
					    tableModel.addRow(data);
					}
					
				
					table.setModel(tableModel);
					table.setEnabled(false);
					
				}catch(Exception exc)
				{	
					JOptionPane.showMessageDialog(null, exc.toString());
				}
			}
		});
	
		
		
		
		HallOptionPanel.add(btnRefresh);
		setVisible(true);
		DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
		centerRenderer.setHorizontalAlignment(JLabel.CENTER);
		for(int m = 0;m<col;m++)
		{
			table.getColumnModel().getColumn(m).setCellRenderer(centerRenderer);
			
		}		
	}
	
	public void dayCount()
	{
		 java.util.Date dt1=dateCheckIn.getDate();
	     java.util.Date dt2=dateCheckOut.getDate();
	     fromDate=Calendar.getInstance();
	     toDate=Calendar.getInstance();
	     
	     if(dt1.after(dt2))
	     {
	    	 JOptionPane.showMessageDialog(null, "Sorry! Invalid Date");
	     }
	     else
	     {
	    	 fromDate.setTime(dt1);
	    	 toDate.setTime(dt2);
	     }
	     inc = 0;
	     
	     
	     if(fromDate.get(Calendar.DAY_OF_MONTH) > (toDate.get(Calendar.DAY_OF_MONTH)))
	     {
	    	 inc = monthDay[fromDate.get(Calendar.MONTH)-1];
	     }
	     if(inc == -1)
	     {
	    	 if(fromDate.getActualMaximum(Calendar.DAY_OF_MONTH)==29)
	    	 {
	    		 inc = 29;
	    	 }
	    	 else
	    	 {
	    		 inc = 28;
	    	 }
	     }
	     
	     if(inc != 0)
	     {
	    	 ageDays = (toDate.get(Calendar.DAY_OF_MONTH) + inc) - fromDate.get(Calendar.DAY_OF_MONTH);
	    	 inc = 1;
	     }
	     else
	     {
	    	 ageDays= toDate.get(Calendar.DAY_OF_MONTH) - fromDate.get(Calendar.DAY_OF_MONTH);
	     }
	     if ((fromDate.get(Calendar.MONTH) + inc) > toDate.get(Calendar.MONTH))
	     {
	         ageMonths = (toDate.get(Calendar.MONTH) + 12) - (fromDate.get(Calendar.MONTH) + inc);
	         inc = 1;
	     }
	     else
	     {
	         ageMonths = (toDate.get(Calendar.MONTH)) - (fromDate.get(Calendar.MONTH + inc));
	         inc = 0; 
         }
	     ageYear = toDate.get(Calendar.YEAR) - (fromDate.get(Calendar.YEAR) + inc);
	
	     	int m = ageDays*2;
	    	txt_totaldays.setText(Integer.toString(ageDays));
		    txt_total_days.setText(Integer.toString(ageDays));
		    //lblMealCharge.setText("x "+Integer.toString(m)+" times");
		    //lblHallRate.setText("x "+Integer.toString(ageDays)+" days");
	}
	
	public static String random(int length)
	{
		String alpha = new String("0123456789XYZ");
		int n = alpha.length();
		String result = new String();
		Random r = new Random();
		for(int i=0;i<length;i++)
			result = result+alpha.charAt(r.nextInt(n));
		return result;
	}
}
