import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JTextField;

import java.awt.Color;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;


public class CustomerDetailFrame extends JFrame {

	private JPanel contentPane2;
	String rNumber = null;
	
	Connection con;
	Statement stmt;
	ResultSet rs;

	/**
	 * Launch the application.
	 *
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CustomerDetailFrame frame = new CustomerDetailFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}*/

	/**
	 * Create the frame.
	 */
	public CustomerDetailFrame() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(64, 157, 267, 77);
		getContentPane().add(panel);
		
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				hide();
				mainPage mp = new mainPage();
				mp.setEnabled(true);
			}
		});
		
		
		rNumber = JOptionPane.showInputDialog(null, "Please Enter Room Number", "Get Room Details", JOptionPane.QUESTION_MESSAGE);
		if(rNumber.trim().equals(""))
		{
			JOptionPane.showMessageDialog(null, "Please Enter Room Number","Invalid Room Number", JOptionPane.ERROR_MESSAGE);
		}
		else
		{
		setResizable(false);
		setTitle("Customer Detail");
		setBounds(350, 150, 722, 410);
		contentPane2 = new JPanel();
		contentPane2.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane2);
		contentPane2.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Customer ID ");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel.setBounds(10, 13, 98, 23);
		contentPane2.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Customer Name");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1.setBounds(367, 17, 120, 23);
		contentPane2.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Room No.");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_2.setBounds(10, 50, 76, 17);
		contentPane2.add(lblNewLabel_2);
		
		JLabel lblNewLabel_4 = new JLabel("Room Rate");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_4.setBounds(10, 114, 84, 17);
		contentPane2.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Check In Date");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_5.setBounds(8, 141, 98, 23);
		contentPane2.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("Check Out Date");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_6.setBounds(10, 177, 114, 23);
		contentPane2.add(lblNewLabel_6);
		
		JLabel lblCheckIn = new JLabel("Label Check In");
		lblCheckIn.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblCheckIn.setForeground(new Color(0, 128, 128));
		lblCheckIn.setBounds(150, 146, 161, 17);
		contentPane2.add(lblCheckIn);
		
		JLabel lblNewLabel_8 = new JLabel("No. of Days");
		lblNewLabel_8.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_8.setBounds(10, 213, 98, 17);
		contentPane2.add(lblNewLabel_8);
		
		JLabel lblNewLabel_9 = new JLabel("No. of Person");
		lblNewLabel_9.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_9.setBounds(11, 251, 98, 14);
		contentPane2.add(lblNewLabel_9);
		
		JLabel lblNewLabel_10 = new JLabel("Purpose of Visit");
		lblNewLabel_10.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_10.setBounds(9, 291, 114, 14);
		contentPane2.add(lblNewLabel_10);
		
		JLabel lblNewLabel_11 = new JLabel("Room");
		lblNewLabel_11.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_11.setBounds(10, 84, 55, 14);
		contentPane2.add(lblNewLabel_11);
		
		JLabel lblACNON = new JLabel("New label");
		lblACNON.setForeground(new Color(0, 128, 128));
		lblACNON.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblACNON.setBounds(241, 85, 68, 14);
		contentPane2.add(lblACNON);
		
		JLabel lblNewLabel_13 = new JLabel("Meal Plan");
		lblNewLabel_13.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_13.setBounds(10, 330, 68, 14);
		contentPane2.add(lblNewLabel_13);
		
		JLabel lblMeal = new JLabel("New label");
		lblMeal.setForeground(new Color(0, 128, 128));
		lblMeal.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblMeal.setBounds(151, 329, 79, 14);
		contentPane2.add(lblMeal);
		
		JLabel lblNewLabel_16 = new JLabel("Total Cost");
		lblNewLabel_16.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_16.setBounds(397, 231, 76, 14);
		contentPane2.add(lblNewLabel_16);
		
		JLabel lblTotal = new JLabel("New label");
		lblTotal.setForeground(new Color(0, 128, 128));
		lblTotal.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		lblTotal.setBounds(515, 229, 128, 14);
		contentPane2.add(lblTotal);
		
		JLabel lblNewLabel_18 = new JLabel("Adv. Payment");
		lblNewLabel_18.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_18.setBounds(397, 265, 100, 14);
		contentPane2.add(lblNewLabel_18);
		
		JLabel lblAdvPay = new JLabel("New label");
		lblAdvPay.setForeground(new Color(0, 128, 128));
		lblAdvPay.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		lblAdvPay.setBounds(515, 265, 128, 14);
		contentPane2.add(lblAdvPay);
		
		JLabel lblNewLabel_15 = new JLabel("Total Dues");
		lblNewLabel_15.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_15.setBounds(397, 323, 84, 14);
		contentPane2.add(lblNewLabel_15);
		
		JLabel lblDues = new JLabel("New label");
		lblDues.setForeground(new Color(0, 128, 128));
		lblDues.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		lblDues.setBounds(515, 323, 128, 14);
		contentPane2.add(lblDues);
		
		JLabel lblCustID = new JLabel("New label");
		lblCustID.setForeground(new Color(0, 128, 0));
		lblCustID.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblCustID.setBounds(151, 14, 98, 23);
		contentPane2.add(lblCustID);
		
		JLabel lblCustomerName = new JLabel("New label");
		lblCustomerName.setForeground(new Color(0, 128, 128));
		lblCustomerName.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblCustomerName.setBounds(515, 19, 150, 17);
		contentPane2.add(lblCustomerName);
		
		JLabel lblRType = new JLabel("New label");
		lblRType.setForeground(new Color(0, 128, 128));
		lblRType.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblRType.setBounds(149, 87, 82, 14);
		contentPane2.add(lblRType);
		
		JLabel lblRoomRate = new JLabel("New label");
		lblRoomRate.setForeground(new Color(0, 128, 128));
		lblRoomRate.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblRoomRate.setBounds(149, 117, 98, 14);
		contentPane2.add(lblRoomRate);
		
		JLabel lblDivider = new JLabel("____________________");
		lblDivider.setForeground(Color.BLUE);
		lblDivider.setBounds(515, 301, 161, 14);
		contentPane2.add(lblDivider);
		
		JLabel lblRmNo = new JLabel("New label");
		lblRmNo.setForeground(new Color(0, 128, 128));
		lblRmNo.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblRmNo.setBounds(151, 56, 128, 14);
		contentPane2.add(lblRmNo);
		
		JLabel lblNewLabel_3 = new JLabel("____________________");
		lblNewLabel_3.setForeground(new Color(0, 0, 255));
		lblNewLabel_3.setBounds(515, 339, 161, 14);
		contentPane2.add(lblNewLabel_3);
		
		JLabel lblNewLabel_7 = new JLabel("Identity");
		lblNewLabel_7.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_7.setBounds(377, 61, 68, 14);
		contentPane2.add(lblNewLabel_7);
		
		JLabel lblIdentity = new JLabel("New label");
		lblIdentity.setBounds(455, 57, 231, 163);
		contentPane2.add(lblIdentity);
		
		JLabel lblCheckOut = new JLabel("New label");
		lblCheckOut.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblCheckOut.setForeground(new Color(0, 128, 128));
		lblCheckOut.setBounds(151, 183, 161, 14);
		contentPane2.add(lblCheckOut);
		
		JLabel lblNoOfDays = new JLabel("New label");
		lblNoOfDays.setForeground(new Color(0, 128, 128));
		lblNoOfDays.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNoOfDays.setBounds(151, 216, 161, 14);
		contentPane2.add(lblNoOfDays);
		
		JLabel lblNoOfPerson = new JLabel("New label");
		lblNoOfPerson.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNoOfPerson.setForeground(new Color(0, 128, 128));
		lblNoOfPerson.setBounds(151, 253, 161, 14);
		contentPane2.add(lblNoOfPerson);
		
		JLabel lblPurposeOfVisit = new JLabel("New label");
		lblPurposeOfVisit.setForeground(new Color(0, 128, 128));
		lblPurposeOfVisit.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblPurposeOfVisit.setBounds(151, 293, 160, 14);
		contentPane2.add(lblPurposeOfVisit);
		
		
		try {
			Boolean b = true;
			Connection con = DBConnection.getConnection();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from roombookingdetails where r_no = "+rNumber+"");
			//ResultSet rs_hall = stmt.executeQuery("select * from func_booking where h_no = "+rNumber+"");
			
				if(rs.next())
				{
					lblCustID.setText(rs.getString("c_id"));
					lblCustomerName.setText(rs.getString("c_fullname"));
					lblRType.setText(rs.getString("r_type"));
					lblRmNo.setText(rs.getString("r_no"));
					lblACNON.setText(rs.getString("room"));
					lblRoomRate.setText("Rs. "+rs.getString("r_rate"));
					lblCheckIn.setText(rs.getString("check_in"));
					lblCheckOut.setText(rs.getString("check_out"));
					lblNoOfDays.setText(rs.getString("total_day"));
					lblNoOfPerson.setText(rs.getString("no_of_person"));
					lblPurposeOfVisit.setText(rs.getString("purpose_visit"));
					lblMeal.setText(rs.getString("meal_plan"));
					lblTotal.setText("Rs. "+rs.getString("grand_total"));
					lblAdvPay.setText("Rs. "+rs.getString("advance"));
					
					lblDues.setText("Rs. "+rs.getString("due"));
					lblIdentity.setIcon(new ImageIcon(rs.getBytes("identity_image")));
				}
				else
				{
					JOptionPane.showMessageDialog(null, "Room has not been booked yet");
					b = false;
				}
				
				
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, e.toString());
			}	
		}
	}
}
