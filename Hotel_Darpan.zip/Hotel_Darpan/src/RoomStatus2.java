import java.awt.BorderLayout;
import java.awt.Dialog.ModalExclusionType;
import java.awt.LayoutManager;
import java.awt.Window.Type;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JComboBox;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;


public class RoomStatus2 extends JPanel {
	private static final LayoutManager BorderLayout = null;
	private JTable table;
	Connection con;
	ResultSet rs;
	String columnName[];
	String data[][];
	int col=0,row=0;
	
	private JButton btnDeleteRoom = new JButton("Delete");
	private JComboBox cbDeleteRoom = new JComboBox();

	/**
	 * Create the panel.
	 */
	public RoomStatus2() {
		setLayout(BorderLayout);
		setLayout(new BorderLayout(0, 0));
		
		table = new JTable();
		table.setBackground(Color.LIGHT_GRAY);
		table.setBounds(63, 243, 250, -160);
		add(table);
		
		try{
			con = DBConnection.getConnection();
			Statement stmt = con.createStatement();
			rs = stmt.executeQuery("select r_number,r_type,r_ac_nonac,r_rate from room");
			ResultSetMetaData rsm = rs.getMetaData();
			col = rsm.getColumnCount();
			columnName = new String[col];
			int id = 1;
			for (int i = 0; i < columnName.length; i++) {
				//columnName[i] = rsm.getColumnName(i+1);	
				//columnName[0] = "<html><b>Serial No.</b></html>";
				columnName[0] = "<html><b>Room Number</b></html>";
				columnName[1] = "<html><b>Room Type</b></html>";
				columnName[2] = "<html><b>AC / Non-AC</b></html>";
				columnName[3] = "<html><b>Room Rate</b></html>";
				//columnName[4] = "Status";
			}
			while (rs.next())row++;
			rs = stmt.executeQuery("select r_number,r_type,r_ac_nonac,r_rate from room");
			data = new String[row][col];
			for (int i = 0; rs.next(); i++) {
				for (int j = 0; j<col; j++)
				{
					data[i][j] = rs.getString(j+1);
					
				}
			}
			table = new JTable(data, columnName);
		}catch(Exception e)
		{	
			
		}
		
		JPanel p = new  JPanel();
		
		JLabel lblDeleteRoom = new JLabel("Delete Room ");
		lblDeleteRoom.setFont(new Font("Tahoma", Font.BOLD, 12));
		p.add(lblDeleteRoom);
		
		//JComboBox cbDeleteRoom = new JComboBox();
		p.add(cbDeleteRoom);
		getRoomIdForDelete(cbDeleteRoom);
		btnDeleteRoom.setBackground(Color.BLACK);
		btnDeleteRoom.setForeground(Color.WHITE);
		btnDeleteRoom.setIcon(new ImageIcon("D:\\Java Workspace\\Hotel_Darpan\\images\\ic_action_delete.png"));
		btnDeleteRoom.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String str = null;
					Connection con = DBConnection.getConnection();
					String sql = "delete from room where r_number = '"+cbDeleteRoom.getSelectedItem()+"'";
					PreparedStatement pstmt = con.prepareStatement(sql);
					
					//int dialog = JOptionPane.YES_NO_OPTION; 
					int dialog = JOptionPane.showConfirmDialog(null, "Do you want to delete this room ?","Warning", JOptionPane.YES_NO_OPTION);
					if(dialog == JOptionPane.YES_OPTION)
					{
						pstmt.execute();
						JOptionPane.showMessageDialog(null, "Deleted Successfully !", "Success", JOptionPane.INFORMATION_MESSAGE);
						
					}
					else
					{
						
					}
					
				} 
				
				catch (Exception e2) {
					// TODO: handle exception
					JOptionPane.showMessageDialog(null, e2.toString());
				}
			}
		});
		p.add(btnDeleteRoom);
		add(p,"South");
		
		JScrollPane tableContainer = new JScrollPane(table);
		add(tableContainer);
		
		DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
		centerRenderer.setHorizontalAlignment(JLabel.CENTER);
		for(int c = 0;c<col;c++)
		{
			table.getColumnModel().getColumn(c).setCellRenderer(centerRenderer);
			
		}
	}

	private void getRoomIdForDelete(JComboBox cbDeleteRoom) {
		// TODO Auto-generated method stub
		try {
			Connection con = DBConnection.getConnection();
			Statement stmt = con.createStatement();
			
			ResultSet rs = stmt.executeQuery("select * from room");
			cbDeleteRoom.addItem("Please Select a Room Number");
			while(rs.next())
			{
				cbDeleteRoom.addItem(rs.getString(2));
			}
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
		
	}
	
	public void getTable()
	{
		try{
			con = DBConnection.getConnection();
			Statement stmt = con.createStatement();
			rs = stmt.executeQuery("select r_number,r_type,r_ac_nonac,r_rate from room");
			ResultSetMetaData rsm = rs.getMetaData();
			col = rsm.getColumnCount();
			columnName = new String[col];
			int id = 1;
			for (int i = 0; i < columnName.length; i++) {
				//columnName[i] = rsm.getColumnName(i+1);	
				//columnName[0] = "<html><b>Serial No.</b></html>";
				columnName[0] = "<html><b>Room Number</b></html>";
				columnName[1] = "<html><b>Room Type</b></html>";
				columnName[2] = "<html><b>AC / Non-AC</b></html>";
				columnName[3] = "<html><b>Room Rate</b></html>";
				//columnName[4] = "Status";
			}
			while (rs.next())row++;
			rs = stmt.executeQuery("select r_number,r_type,r_ac_nonac,r_rate from room");
			data = new String[row][col];
			for (int i = 0; rs.next(); i++) {
				for (int j = 0; j<col; j++)
				{
					data[i][j] = rs.getString(j+1);
					
				}
			}
			table = new JTable(data, columnName);
		}catch(Exception e)
		{	
			
		}
	}
}
