import java.awt.BorderLayout;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.ItemSelectable;
import java.awt.Toolkit;

import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.BevelBorder;
import javax.swing.border.TitledBorder;

import java.awt.Color;
import java.awt.FlowLayout;

import javax.swing.JLabel;

import java.awt.Font;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.BorderFactory;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JSplitPane;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.plaf.basic.BasicTabbedPaneUI.TabbedPaneLayout;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.JMenuBar;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.JMenu;
import javax.swing.JTabbedPane;
import javax.swing.border.LineBorder;
import javax.swing.UIManager;
import javax.swing.SwingConstants;

import com.mysql.jdbc.PreparedStatement;

import java.awt.Window.Type;


public class CustomerScreenFrame extends JFrame {
	

	private JPanel contentPane;
	
	private JPanel contentPane2;
	
	private JTextField txtCustomerName;
	private JTextField txtRmNo;
	private JTextField txtRmRate;
	private JTextField txtCheckOut;
	private JTextField txtDays;
	private JTextField txtPerson;
	private JTextField txtPurpose;
	private JLabel lblMyAccount = new JLabel("<html><u>My Account</u></html>");
	private JLabel lblLogout = new JLabel("<html><u><marquee>Logout</marquee></u></html>");

	/**
	 * Launch the application.
	*
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					mainPage frame = new mainPage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}*/

	/**
	 * Create the frame.
	 */
	public CustomerScreenFrame() {
		setTitle("Hotel Darpan");
		setBackground(Color.ORANGE);
		setResizable(false);
		setBounds(200, 50, 1020, 650);
		contentPane = new JPanel();
		contentPane.setLocation(-20, 0);
		contentPane.setBorder(new EmptyBorder(0, 0, 0, 0));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		JEditorPane htmlPane = new JEditorPane();
		
	
		panel.setBackground(Color.DARK_GRAY);
		panel.setBounds(0, 24, 1010, 70);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblHotelDarpan = new JLabel("Hotel Darpan");
		lblHotelDarpan.setFont(new Font("Sylfaen", Font.BOLD, 28));
		lblHotelDarpan.setForeground(SystemColor.textHighlight);
		lblHotelDarpan.setBounds(10, 14, 198, 27);
		panel.add(lblHotelDarpan);
		
		JLabel lblAdminPanel = new JLabel("Room Assistant Page");
		lblAdminPanel.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblAdminPanel.setForeground(SystemColor.inactiveCaptionBorder);
		lblAdminPanel.setBounds(12, 42, 196, 17);
		panel.add(lblAdminPanel);
		
		JLabel lblWelcome = new JLabel("Welcome Customer");
		lblWelcome.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblWelcome.setForeground(SystemColor.text);
		lblWelcome.setBounds(567, 14, 175, 27);
		panel.add(lblWelcome);
		
		
		
		lblMyAccount.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblMyAccount.setForeground(SystemColor.activeCaption);
		lblMyAccount.setBounds(831, 19, 78, 14);
		panel.add(lblMyAccount);
		
		lblMyAccount.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				lblMyAccount.setCursor(new Cursor(Cursor.HAND_CURSOR));
				lblMyAccount.setForeground(Color.WHITE);
				//super.mouseEntered(e);
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblMyAccount.setForeground(SystemColor.activeCaption);
			}
			@Override
			public void mousePressed(MouseEvent e) {
				try{
					MyAccount ac = new MyAccount();
					ac.setVisible(true);
				}
				catch(Exception exc){
					exc.printStackTrace();
				}
			}
			
		});
		
		
		lblLogout.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblLogout.setForeground(SystemColor.activeCaption);
		lblLogout.setBounds(933, 18, 46, 14);
		lblLogout.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				lblLogout.setCursor(new Cursor(Cursor.HAND_CURSOR));
				lblLogout.setForeground(Color.WHITE);
			}
			@Override
			public void mousePressed(MouseEvent e) {
				login l = new login();
				l.setVisible(true);
				setVisible(false);
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblLogout.setForeground(SystemColor.activeCaption);
			}
			
		});
		
		
		panel.add(lblLogout);
		
		JLabel label = new JLabel("|");
		label.setForeground(SystemColor.text);
		label.setFont(new Font("Tahoma", Font.BOLD, 12));
		label.setBounds(813, 18, 10, 14);
		panel.add(label);
		
		JLabel label_1 = new JLabel("|");
		label_1.setForeground(SystemColor.text);
		label_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		label_1.setBounds(912, 17, 10, 14);
		panel.add(label_1);
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(0, -1, 1010, 623);
		JPanel t2 = new JPanel();
		
		
		
		CustomerBookedRoomDetails room = new CustomerBookedRoomDetails();
		room.setBackground(Color.ORANGE);
		JPanel t3 = new JPanel();
		JPanel t4 = new JPanel();
		t2.setBackground(Color.RED);
		room.setBackground(Color.LIGHT_GRAY);
		t3.setBackground(Color.LIGHT_GRAY);
		t4.setBackground(Color.GREEN);
		t2.setLayout(null);
		tabbedPane.add("Room Booking",room);
		
		FunctionBooking fcb = new FunctionBooking();
		tabbedPane.add("Function Booking", fcb);
		
		EmployeeDetails emp = new EmployeeDetails();
		tabbedPane.add("Employee Details", emp);
		
		contentPane.add(tabbedPane);
	}
}
