import java.awt.BorderLayout;
import java.awt.Dialog.ModalExclusionType;
import java.awt.LayoutManager;
import java.awt.Window.Type;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JComboBox;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class CheckedInList extends JPanel {
	private static final LayoutManager BorderLayout = null;
	private JTable table;
	Connection con;
	ResultSet rs;
	String columnName[];
	String data[][];
	int col=0,row=0;
	
	JButton btnDeleteCustomer = new JButton("Delete");

	/**
	 * Create the panel.
	 */
	public CheckedInList() {
		setLayout(BorderLayout);
		setLayout(new BorderLayout(0, 0));
		
		table = new JTable();
		table.setBackground(Color.LIGHT_GRAY);
		table.setBounds(63, 243, 250, -160);
		add(table);
		
		try{
			con = DBConnection.getConnection();
			Statement stmt = con.createStatement();
			rs = stmt.executeQuery("select c_id,c_fullname,r_no,check_in,total_day,no_of_person,purpose_visit,"
					+ "room,r_type,c_mobile from roombookingdetails");
			ResultSetMetaData rsm = rs.getMetaData();
			col = rsm.getColumnCount();
			columnName = new String[col];
			int id = 1;
			for (int i = 0; i < columnName.length; i++) {
				columnName[0] = "<html><b>Cust. ID</b></html>";
				columnName[1] = "<html><b>Cust. Name</b></html>";
				columnName[2] = "<html><b>Room No.</b></html>";
				columnName[3] = "<html><b>Check In</b></html>";
				columnName[4] = "<html><b>Total Day</b></html>";
				columnName[5] = "<html><b>Person</b></html>";
				columnName[6] = "<html><b>Purpose</b></html>";
				columnName[7] = "<html><b>Room</b></html>";
				columnName[8] = "<html><b>Room Type</b></html>";
				columnName[9] = "<html><b>Mobile No.</b></html>";
				
			}
			while (rs.next())row++;
			rs = stmt.executeQuery("select c_id,c_fullname,r_no,check_in,total_day,no_of_person,purpose_visit,"
					+ "room,r_type,c_mobile from roombookingdetails");
			data = new String[row][col];
			for (int i = 0; rs.next(); i++) {
				for (int j = 0; j<col; j++)
				{
					data[i][j] = rs.getString(j+1);
				}
			}
			table = new JTable(data, columnName);
		}catch(Exception e)
		{	
			
		}
		
		
		JScrollPane tableContainer = new JScrollPane(table,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		
		add(tableContainer);
		setVisible(true);
		
		DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
		centerRenderer.setHorizontalAlignment(JLabel.CENTER);
		for(int c = 0;c<col;c++)
		{
			table.getColumnModel().getColumn(c).setCellRenderer(centerRenderer);
			
		}
	}
}
