import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import java.awt.Dialog.ModalExclusionType;
import java.awt.Window.Type;
import javax.swing.border.LineBorder;
import java.awt.Color;


public class RoomStatus implements ActionListener {
	JTable table;
	Connection con;
	ResultSet rs;
	String columnName[];
	String data[][];
	int col=0,row=0;
	public RoomStatus() {
		try{
			con = DBConnection.getConnection();
			Statement stmt = con.createStatement();
			rs = stmt.executeQuery("select * from room");
			ResultSetMetaData rsm = rs.getMetaData();
			col = rsm.getColumnCount();
			columnName = new String[col];
			for (int i = 0; i < columnName.length; i++) {
				//columnName[i] = rsm.getColumnName(i+1);	
				columnName[0] = "ID";
				columnName[1] = "Room Number";
				columnName[2] = "Room Type";
				columnName[3] = "Room Rate";
				columnName[4] = "Status";
			}
			while (rs.next())row++;
			rs = stmt.executeQuery("select * from room");
			data = new String[row][col];
			for (int i = 0; rs.next(); i++) {
				for (int j = 0; j<col; j++)
				{
					data[i][j]=rs.getString(j+1);
					
				}
				//System.out.println();
			}
			table = new JTable(data, columnName);
			table.setEnabled(false);
		}catch(Exception e)
		{	
			
		}
		JFrame f = new JFrame();
		f.setTitle("Room Status");
		f.setType(Type.UTILITY);
		f.setModalExclusionType(ModalExclusionType.APPLICATION_EXCLUDE);
		f.getContentPane().add(new JScrollPane(table));
		f.setSize(616, 273);
		f.setBounds(370, 140, 725, 273);
		f.setVisible(true);
		
	}
	
	public void actionPerformed(ActionEvent e) {
		JOptionPane.showMessageDialog(null, "Sending Request.....Please Wait");
		
	}
}

