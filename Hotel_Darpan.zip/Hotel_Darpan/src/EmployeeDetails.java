import java.awt.BorderLayout;
import java.awt.Dialog.ModalExclusionType;
import java.awt.LayoutManager;
import java.awt.Window.Type;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import java.awt.Color;

import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JComboBox;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.SwingConstants;


public class EmployeeDetails extends JPanel {
	private static final LayoutManager BorderLayout = null;
	private JTable table;
	Connection con;
	ResultSet rs;
	String columnName[];
	String data[][];
	int col=0,row=0;
	private JTextField txtSearch;
	private JComboBox cbPost;
	private JComboBox cbSearchBy = new JComboBox();

	/**
	 * Create the panel.
	 */
	public EmployeeDetails() {
		setBackground(Color.ORANGE);
		setLayout(BorderLayout);
		setBounds(10, 10, 718, 500);
		setLayout(null);
		table = new JTable();
		table.setBounds(0, 0, 0, 0);
		table.setBackground(Color.LIGHT_GRAY);
		//table.setBounds(63, 13, 250, 160);
		add(table);
		
		try{
			con = DBConnection.getConnection();
			Statement stmt = con.createStatement();
			rs = stmt.executeQuery("select * from employee");
			ResultSetMetaData rsm = rs.getMetaData();
			col = rsm.getColumnCount();
			columnName = new String[col];
			int id = 1;
			for (int i = 0; i < columnName.length; i++) {
				//columnName[i] = rsm.getColumnName(i+1);	
				columnName[0] = "<html><b>Serial No.</b></html>";
				columnName[1] = "<html><b>Emp. ID</b></html>";
				columnName[2] = "<html><b>Name</b></html>";
				columnName[3] = "<html><b>Age</b></html>";
				columnName[4] = "<html><b>Address</b></html>";
				columnName[5] = "<html><b>Salary</b></html>";
				columnName[6] = "<html><b>Designation</b></html>";
				
			}
			while (rs.next())row++;
			rs = stmt.executeQuery("select * from employee");
			data = new String[row][col];
			for (int i = 0; rs.next(); i++) {
				for (int j = 0; j<col; j++)
				{
					data[i][j] = "<html><span style='text-align:centre;'>"+rs.getString(j+1)+"</span></html>";
				}
			}
			
			
			table = new JTable(data, columnName);
			table.setEnabled(false);
		}catch(Exception e)
		{	
			
		}
		
		JScrollPane tableContainer = new JScrollPane(table);
		tableContainer.setBounds(20, 131, 970, 449);
		add(tableContainer);
		tableContainer.setBackground(Color.GREEN);
		
		DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
		centerRenderer.setHorizontalAlignment(JLabel.CENTER);
		for(int c = 0;c<col;c++)
		{
			table.getColumnModel().getColumn(c).setCellRenderer(centerRenderer);
			
		}
		
		JLabel lblNewLabel = new JLabel("Search By : ");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel.setBounds(18, 88, 76, 20);
		add(lblNewLabel);
		
		//JComboBox cbSearchBy = new JComboBox();
		cbSearchBy.setFont(new Font("Tahoma", Font.PLAIN, 12));
		cbSearchBy.setBounds(95, 82, 86, 27);
		cbSearchBy.addItem("Emp. ID");
		cbSearchBy.addItem("Emp. Name");
		cbSearchBy.addItem("Emp. Post");
		add(cbSearchBy);
		cbSearchBy.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				cbPost = new JComboBox();
				if(cbSearchBy.getSelectedItem().equals("Emp. Post"))
				{
					txtSearch.hide();
					cbPost.addItem("Staff");
					cbPost.addItem("Receptionist");
					cbPost.addItem("Dustcleaner");
					cbPost.addItem("Cooker");
					cbPost.setBounds(194, 82, 113, 26);
					add(cbPost);
					cbPost.setVisible(true);
				}
				else
				{
					cbPost.setVisible(false);
					txtSearch.setVisible(true);
				}
			}
		});
		
		
		JLabel lblNewLabel_1 = new JLabel("Employees Details");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_1.setBounds(426, 95, 162, 32);
		add(lblNewLabel_1);
		
		txtSearch = new JTextField();
		txtSearch.setFont(new Font("Tahoma", Font.PLAIN, 11));
		txtSearch.setBounds(194, 82, 113, 26);
		add(txtSearch);
		txtSearch.setColumns(10);
		
		JButton btnSearchEmp = new JButton();
		btnSearchEmp.setHorizontalAlignment(SwingConstants.LEFT);
		btnSearchEmp.setBackground(Color.BLACK);
		btnSearchEmp.setForeground(Color.WHITE);
		btnSearchEmp.setIcon(new ImageIcon("./images\\ic_action_search.png"));
		
		btnSearchEmp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(txtSearch.getText().trim().equals(""))
				{
					JOptionPane.showMessageDialog(null, "Can't search blank field");
				}
				else if(cbSearchBy.getSelectedItem()=="Emp. ID")
				{
					String id = txtSearch.getText();
					try {
							con = DBConnection.getConnection();
							Statement stmt = con.createStatement();
							rs = stmt.executeQuery("select * from employee where e_id = '"+id+"'");
							ResultSetMetaData rsm = rs.getMetaData();
							col = rsm.getColumnCount();
							columnName = new String[col];
							for (int i = 0; i < columnName.length; i++) 
							{
								//columnName[i] = rsm.getColumnName(i+1);	
								columnName[0] = "<html><b>Serial No.</b></html>";
								columnName[1] = "<html><b>Emp. ID</b></html>";
								columnName[2] = "<html><b>Name</b></html>";
								columnName[3] = "<html><b>Age</b></html>";
								columnName[4] = "<html><b>Address</b></html>";
								columnName[5] = "<html><b>Salary</b></html>";
								columnName[6] = "<html><b>Designation</b></html>";
								
							}
							while (rs.next())row++;
							rs = stmt.executeQuery("select * from employee where e_id = '"+id+"'");
							data = new String[row][col];
							for (int i = 0; rs.next(); i++) 
							{
								for (int j = 0; j<col; j++)
								{
									data[i][j] = "<html><span style='text-align:centre;'>"+rs.getString(j+1)+"</span></html>";
								}
							}
						
							table = new JTable(data, columnName);
						}catch(Exception exc)
						{	
							JOptionPane.showMessageDialog(null, exc.toString());
						}
					}
				else if (cbSearchBy.getSelectedItem()=="Emp. Name") 
				{
					String name = txtSearch.getText();
					try {
						con = DBConnection.getConnection();
						Statement stmt = con.createStatement();
						rs = stmt.executeQuery("select * from employee where e_name = '"+name+"'");
						ResultSetMetaData rsm = rs.getMetaData();
						col = rsm.getColumnCount();
						columnName = new String[col];
						for (int i = 0; i < columnName.length; i++) 
						{
							//columnName[i] = rsm.getColumnName(i+1);	
							columnName[0] = "<html><b>Serial No.</b></html>";
							columnName[1] = "<html><b>Emp. ID</b></html>";
							columnName[2] = "<html><b>Name</b></html>";
							columnName[3] = "<html><b>Age</b></html>";
							columnName[4] = "<html><b>Address</b></html>";
							columnName[5] = "<html><b>Salary</b></html>";
							columnName[6] = "<html><b>Designation</b></html>";
							
						}
						while (rs.next())
						{
							row++;
						
							rs = stmt.executeQuery("select * from employee where e_name = '"+name+"'");
							data = new String[row][col];
							for (int i = 0; rs.next(); i++) 
							{
								for (int j = 0; j<col; j++)
								{
									data[i][j] = "<html><span style='text-align:centre;'>"+rs.getString(j+1)+"</span></html>";
								}
							}
						}
					
						table = new JTable(data, columnName);
					}catch(Exception exc)
					{	
						JOptionPane.showMessageDialog(null, exc.toString());
					}
					
				}
				
				else if (cbSearchBy.getSelectedItem() == "Emp. Post") 
				{
					String post = (String)cbPost.getSelectedItem();
					try {
						con = DBConnection.getConnection();
						Statement stmt = con.createStatement();
						rs = stmt.executeQuery("select * from employee where e_post = '"+post+"'");
						ResultSetMetaData rsm = rs.getMetaData();
						col = rsm.getColumnCount();
						columnName = new String[col];
						for (int i = 0; i < columnName.length; i++) 
						{
							//columnName[i] = rsm.getColumnName(i+1);	
							columnName[0] = "<html><b>Serial No.</b></html>";
							columnName[1] = "<html><b>Emp. ID</b></html>";
							columnName[2] = "<html><b>Name</b></html>";
							columnName[3] = "<html><b>Age</b></html>";
							columnName[4] = "<html><b>Address</b></html>";
							columnName[5] = "<html><b>Salary</b></html>";
							columnName[6] = "<html><b>Designation</b></html>";
							
						}
						while (rs.next())row++;
						rs = stmt.executeQuery("select * from employee where e_post = '"+post+"'");
						data = new String[row][col];
						for (int i = 0; rs.next(); i++) 
						{
							for (int j = 0; j<col; j++)
							{
								data[i][j] = "<html><span style='text-align:centre;'>"+rs.getString(j+1)+"</span></html>";
							}
						}
					
						table = new JTable(data, columnName);
					}catch(Exception exc)
					{	
						JOptionPane.showMessageDialog(null, exc.toString());
					}
					
				}
				JScrollPane tableContainer = new JScrollPane(table);
				tableContainer.setBounds(20, 131, 970, 449);
				add(tableContainer);
				tableContainer.setBackground(Color.GREEN);
				
				DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
				centerRenderer.setHorizontalAlignment(JLabel.CENTER);
				
			}
			
		});
		
		
		btnSearchEmp.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnSearchEmp.setBounds(317, 82, 78, 27);
		add(btnSearchEmp);
	}
}

